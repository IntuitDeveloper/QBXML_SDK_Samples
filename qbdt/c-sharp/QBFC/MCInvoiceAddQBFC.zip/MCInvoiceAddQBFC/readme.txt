This sample is a simple C++ desktop application that adds the invoice by using QBFC2 COM dll. 

Running the sample
------------------

Before running MCInvoiceAddQBFC.exe, make sure that QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open MCInvoiceAddQBFC.sln in Microsoft Visual Studio and build the solution.
