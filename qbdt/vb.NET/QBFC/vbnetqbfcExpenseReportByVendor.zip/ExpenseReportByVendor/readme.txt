This sample is a simple VB.NET desktop application that is used to create Expense Report by Vendor by using QBFC2 COM dll. 

Running the sample
------------------

Before running ExpenseReport.exe, make sure that .NET runtime is installed on the machine, 
and QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open ExpenseReport.sln in Microsoft Visual Studio .NET and build the solution.
QBFC2Assembly.dll was generated with 'tlbimp' .NET Type Library to Assembly Convertor.

