<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmInvoiceModify
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents chkShow As System.Windows.Forms.CheckBox
	Public WithEvents _txtSpace1_29 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_28 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_27 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_26 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_25 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_24 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_23 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_22 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_21 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_20 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_19 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_18 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_17 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_16 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_15 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_14 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_13 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_12 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_11 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_10 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_1 As System.Windows.Forms.TextBox
	Public WithEvents cmdFinish As System.Windows.Forms.Button
	Public WithEvents cmdDoModify As System.Windows.Forms.Button
	Public WithEvents cmdUndo As System.Windows.Forms.Button
	Public WithEvents cmdDeleteUndelete As System.Windows.Forms.Button
	Public WithEvents cmdAddLineBefore As System.Windows.Forms.Button
	Public WithEvents cmdAddLineAfter As System.Windows.Forms.Button
	Public WithEvents cmdEditLine As System.Windows.Forms.Button
	Public WithEvents vscInvoiceLineScroll As System.Windows.Forms.VScrollBar
	Public WithEvents _txtAmount_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtDesc_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemFullName_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtItemLineNumber_0 As System.Windows.Forms.TextBox
	Public WithEvents cmdEditMemo As System.Windows.Forms.Button
	Public WithEvents txtMemo As System.Windows.Forms.TextBox
	Public WithEvents cmbCustomerMsg As System.Windows.Forms.ComboBox
	Public WithEvents cmbCustTaxCode As System.Windows.Forms.ComboBox
	Public WithEvents cmbItemSalesTax As System.Windows.Forms.ComboBox
	Public WithEvents cmbShipMethod As System.Windows.Forms.ComboBox
	Public WithEvents cmbSalesRep As System.Windows.Forms.ComboBox
	Public WithEvents txtFOB As System.Windows.Forms.TextBox
	Public WithEvents txtShipDate As System.Windows.Forms.TextBox
	Public WithEvents txtDueDate As System.Windows.Forms.TextBox
	Public WithEvents txtPONumber As System.Windows.Forms.TextBox
	Public WithEvents cmbTerms As System.Windows.Forms.ComboBox
	Public WithEvents cmbARAccount As System.Windows.Forms.ComboBox
	Public WithEvents chkToBePrinted As System.Windows.Forms.CheckBox
	Public WithEvents txtShipAddr4 As System.Windows.Forms.TextBox
	Public WithEvents txtShipAddr3 As System.Windows.Forms.TextBox
	Public WithEvents txtShipAddr2 As System.Windows.Forms.TextBox
	Public WithEvents txtShipAddr1 As System.Windows.Forms.TextBox
	Public WithEvents txtShipState As System.Windows.Forms.TextBox
	Public WithEvents txtShipCity As System.Windows.Forms.TextBox
	Public WithEvents txtShipPostalCode As System.Windows.Forms.TextBox
	Public WithEvents txtShipCountry As System.Windows.Forms.TextBox
	Public WithEvents txtBillCountry As System.Windows.Forms.TextBox
	Public WithEvents txtBillPostalCode As System.Windows.Forms.TextBox
	Public WithEvents txtBillState As System.Windows.Forms.TextBox
	Public WithEvents txtBillCity As System.Windows.Forms.TextBox
	Public WithEvents txtBillAddr4 As System.Windows.Forms.TextBox
	Public WithEvents txtBillAddr3 As System.Windows.Forms.TextBox
	Public WithEvents txtBillAddr2 As System.Windows.Forms.TextBox
	Public WithEvents txtBillAddr1 As System.Windows.Forms.TextBox
	Public WithEvents cmbClass As System.Windows.Forms.ComboBox
	Public WithEvents chkPending As System.Windows.Forms.CheckBox
	Public WithEvents txtTxnDate As System.Windows.Forms.TextBox
	Public WithEvents txtRefNumber As System.Windows.Forms.TextBox
	Public WithEvents cmbCustomer As System.Windows.Forms.ComboBox
	Public WithEvents txtEditSequence As System.Windows.Forms.TextBox
	Public WithEvents txtTxnID As System.Windows.Forms.TextBox
	Public WithEvents Label31 As System.Windows.Forms.Label
	Public WithEvents Label30 As System.Windows.Forms.Label
	Public WithEvents Label29 As System.Windows.Forms.Label
	Public WithEvents Label28 As System.Windows.Forms.Label
	Public WithEvents Label27 As System.Windows.Forms.Label
	Public WithEvents Label26 As System.Windows.Forms.Label
	Public WithEvents Label25 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label23 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents _Label13_1 As System.Windows.Forms.Label
	Public WithEvents _Label12_1 As System.Windows.Forms.Label
	Public WithEvents _Label11_1 As System.Windows.Forms.Label
	Public WithEvents _Label10_1 As System.Windows.Forms.Label
	Public WithEvents _Label9_7 As System.Windows.Forms.Label
	Public WithEvents _Label9_6 As System.Windows.Forms.Label
	Public WithEvents _Label9_5 As System.Windows.Forms.Label
	Public WithEvents _Label9_4 As System.Windows.Forms.Label
	Public WithEvents _Label13_0 As System.Windows.Forms.Label
	Public WithEvents _Label12_0 As System.Windows.Forms.Label
	Public WithEvents _Label11_0 As System.Windows.Forms.Label
	Public WithEvents _Label10_0 As System.Windows.Forms.Label
	Public WithEvents _Label9_3 As System.Windows.Forms.Label
	Public WithEvents _Label9_2 As System.Windows.Forms.Label
	Public WithEvents _Label9_1 As System.Windows.Forms.Label
	Public WithEvents _Label9_0 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label10 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label11 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label12 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label13 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label9 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents txtAmount As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtDesc As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtItemFullName As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtItemLineNumber As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtQuantity As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtRate As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace1 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.chkShow = New System.Windows.Forms.CheckBox()
        Me._txtSpace1_29 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_28 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_27 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_26 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_25 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_24 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_23 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_22 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_21 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_20 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_19 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_18 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_17 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_16 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_15 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_14 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_13 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_12 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_11 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_10 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_9 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_8 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_7 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_6 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_5 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_4 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_3 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_2 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_1 = New System.Windows.Forms.TextBox()
        Me._txtSpace1_0 = New System.Windows.Forms.TextBox()
        Me._txtAmount_9 = New System.Windows.Forms.TextBox()
        Me._txtRate_9 = New System.Windows.Forms.TextBox()
        Me._txtDesc_9 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_9 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_9 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_9 = New System.Windows.Forms.TextBox()
        Me._txtAmount_8 = New System.Windows.Forms.TextBox()
        Me._txtRate_8 = New System.Windows.Forms.TextBox()
        Me._txtDesc_8 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_8 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_8 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_8 = New System.Windows.Forms.TextBox()
        Me._txtAmount_7 = New System.Windows.Forms.TextBox()
        Me._txtRate_7 = New System.Windows.Forms.TextBox()
        Me._txtDesc_7 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_7 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_7 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_7 = New System.Windows.Forms.TextBox()
        Me._txtAmount_6 = New System.Windows.Forms.TextBox()
        Me._txtRate_6 = New System.Windows.Forms.TextBox()
        Me._txtDesc_6 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_6 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_6 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_6 = New System.Windows.Forms.TextBox()
        Me._txtAmount_5 = New System.Windows.Forms.TextBox()
        Me._txtRate_5 = New System.Windows.Forms.TextBox()
        Me._txtDesc_5 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_5 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_5 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_5 = New System.Windows.Forms.TextBox()
        Me._txtAmount_4 = New System.Windows.Forms.TextBox()
        Me._txtRate_4 = New System.Windows.Forms.TextBox()
        Me._txtDesc_4 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_4 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_4 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_4 = New System.Windows.Forms.TextBox()
        Me._txtAmount_3 = New System.Windows.Forms.TextBox()
        Me._txtRate_3 = New System.Windows.Forms.TextBox()
        Me._txtDesc_3 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_3 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_3 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_3 = New System.Windows.Forms.TextBox()
        Me._txtAmount_2 = New System.Windows.Forms.TextBox()
        Me._txtRate_2 = New System.Windows.Forms.TextBox()
        Me._txtDesc_2 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_2 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_2 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_2 = New System.Windows.Forms.TextBox()
        Me._txtAmount_1 = New System.Windows.Forms.TextBox()
        Me._txtRate_1 = New System.Windows.Forms.TextBox()
        Me._txtDesc_1 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_1 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_1 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_1 = New System.Windows.Forms.TextBox()
        Me.cmdFinish = New System.Windows.Forms.Button()
        Me.cmdDoModify = New System.Windows.Forms.Button()
        Me.cmdUndo = New System.Windows.Forms.Button()
        Me.cmdDeleteUndelete = New System.Windows.Forms.Button()
        Me.cmdAddLineBefore = New System.Windows.Forms.Button()
        Me.cmdAddLineAfter = New System.Windows.Forms.Button()
        Me.cmdEditLine = New System.Windows.Forms.Button()
        Me.vscInvoiceLineScroll = New System.Windows.Forms.VScrollBar()
        Me._txtAmount_0 = New System.Windows.Forms.TextBox()
        Me._txtRate_0 = New System.Windows.Forms.TextBox()
        Me._txtDesc_0 = New System.Windows.Forms.TextBox()
        Me._txtItemFullName_0 = New System.Windows.Forms.TextBox()
        Me._txtQuantity_0 = New System.Windows.Forms.TextBox()
        Me._txtItemLineNumber_0 = New System.Windows.Forms.TextBox()
        Me.cmdEditMemo = New System.Windows.Forms.Button()
        Me.txtMemo = New System.Windows.Forms.TextBox()
        Me.cmbCustomerMsg = New System.Windows.Forms.ComboBox()
        Me.cmbCustTaxCode = New System.Windows.Forms.ComboBox()
        Me.cmbItemSalesTax = New System.Windows.Forms.ComboBox()
        Me.cmbShipMethod = New System.Windows.Forms.ComboBox()
        Me.cmbSalesRep = New System.Windows.Forms.ComboBox()
        Me.txtFOB = New System.Windows.Forms.TextBox()
        Me.txtShipDate = New System.Windows.Forms.TextBox()
        Me.txtDueDate = New System.Windows.Forms.TextBox()
        Me.txtPONumber = New System.Windows.Forms.TextBox()
        Me.cmbTerms = New System.Windows.Forms.ComboBox()
        Me.cmbARAccount = New System.Windows.Forms.ComboBox()
        Me.chkToBePrinted = New System.Windows.Forms.CheckBox()
        Me.txtShipAddr4 = New System.Windows.Forms.TextBox()
        Me.txtShipAddr3 = New System.Windows.Forms.TextBox()
        Me.txtShipAddr2 = New System.Windows.Forms.TextBox()
        Me.txtShipAddr1 = New System.Windows.Forms.TextBox()
        Me.txtShipState = New System.Windows.Forms.TextBox()
        Me.txtShipCity = New System.Windows.Forms.TextBox()
        Me.txtShipPostalCode = New System.Windows.Forms.TextBox()
        Me.txtShipCountry = New System.Windows.Forms.TextBox()
        Me.txtBillCountry = New System.Windows.Forms.TextBox()
        Me.txtBillPostalCode = New System.Windows.Forms.TextBox()
        Me.txtBillState = New System.Windows.Forms.TextBox()
        Me.txtBillCity = New System.Windows.Forms.TextBox()
        Me.txtBillAddr4 = New System.Windows.Forms.TextBox()
        Me.txtBillAddr3 = New System.Windows.Forms.TextBox()
        Me.txtBillAddr2 = New System.Windows.Forms.TextBox()
        Me.txtBillAddr1 = New System.Windows.Forms.TextBox()
        Me.cmbClass = New System.Windows.Forms.ComboBox()
        Me.chkPending = New System.Windows.Forms.CheckBox()
        Me.txtTxnDate = New System.Windows.Forms.TextBox()
        Me.txtRefNumber = New System.Windows.Forms.TextBox()
        Me.cmbCustomer = New System.Windows.Forms.ComboBox()
        Me.txtEditSequence = New System.Windows.Forms.TextBox()
        Me.txtTxnID = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me._Label13_1 = New System.Windows.Forms.Label()
        Me._Label12_1 = New System.Windows.Forms.Label()
        Me._Label11_1 = New System.Windows.Forms.Label()
        Me._Label10_1 = New System.Windows.Forms.Label()
        Me._Label9_7 = New System.Windows.Forms.Label()
        Me._Label9_6 = New System.Windows.Forms.Label()
        Me._Label9_5 = New System.Windows.Forms.Label()
        Me._Label9_4 = New System.Windows.Forms.Label()
        Me._Label13_0 = New System.Windows.Forms.Label()
        Me._Label12_0 = New System.Windows.Forms.Label()
        Me._Label11_0 = New System.Windows.Forms.Label()
        Me._Label10_0 = New System.Windows.Forms.Label()
        Me._Label9_3 = New System.Windows.Forms.Label()
        Me._Label9_2 = New System.Windows.Forms.Label()
        Me._Label9_1 = New System.Windows.Forms.Label()
        Me._Label9_0 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.Label11 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.Label12 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.Label13 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.Label9 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.txtAmount = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtDesc = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtItemFullName = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtItemLineNumber = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtQuantity = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtRate = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me.txtSpace1 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDesc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItemFullName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItemLineNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkShow
        '
        Me.chkShow.BackColor = System.Drawing.SystemColors.Control
        Me.chkShow.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkShow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShow.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkShow.Location = New System.Drawing.Point(456, 672)
        Me.chkShow.Name = "chkShow"
        Me.chkShow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkShow.Size = New System.Drawing.Size(137, 17)
        Me.chkShow.TabIndex = 177
        Me.chkShow.Text = "Show request"
        Me.chkShow.UseVisualStyleBackColor = False
        '
        '_txtSpace1_29
        '
        Me._txtSpace1_29.AcceptsReturn = True
        Me._txtSpace1_29.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_29.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_29.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_29.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_29.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_29, CType(29, Short))
        Me._txtSpace1_29.Location = New System.Drawing.Point(272, 576)
        Me._txtSpace1_29.MaxLength = 0
        Me._txtSpace1_29.Name = "_txtSpace1_29"
        Me._txtSpace1_29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_29.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_29.TabIndex = 170
        '
        '_txtSpace1_28
        '
        Me._txtSpace1_28.AcceptsReturn = True
        Me._txtSpace1_28.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_28.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_28.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_28.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_28.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_28, CType(28, Short))
        Me._txtSpace1_28.Location = New System.Drawing.Point(272, 560)
        Me._txtSpace1_28.MaxLength = 0
        Me._txtSpace1_28.Name = "_txtSpace1_28"
        Me._txtSpace1_28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_28.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_28.TabIndex = 169
        '
        '_txtSpace1_27
        '
        Me._txtSpace1_27.AcceptsReturn = True
        Me._txtSpace1_27.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_27.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_27.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_27.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_27.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_27, CType(27, Short))
        Me._txtSpace1_27.Location = New System.Drawing.Point(272, 544)
        Me._txtSpace1_27.MaxLength = 0
        Me._txtSpace1_27.Name = "_txtSpace1_27"
        Me._txtSpace1_27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_27.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_27.TabIndex = 168
        '
        '_txtSpace1_26
        '
        Me._txtSpace1_26.AcceptsReturn = True
        Me._txtSpace1_26.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_26.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_26.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_26.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_26.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_26, CType(26, Short))
        Me._txtSpace1_26.Location = New System.Drawing.Point(272, 528)
        Me._txtSpace1_26.MaxLength = 0
        Me._txtSpace1_26.Name = "_txtSpace1_26"
        Me._txtSpace1_26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_26.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_26.TabIndex = 167
        '
        '_txtSpace1_25
        '
        Me._txtSpace1_25.AcceptsReturn = True
        Me._txtSpace1_25.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_25.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_25.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_25.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_25, CType(25, Short))
        Me._txtSpace1_25.Location = New System.Drawing.Point(272, 512)
        Me._txtSpace1_25.MaxLength = 0
        Me._txtSpace1_25.Name = "_txtSpace1_25"
        Me._txtSpace1_25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_25.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_25.TabIndex = 166
        '
        '_txtSpace1_24
        '
        Me._txtSpace1_24.AcceptsReturn = True
        Me._txtSpace1_24.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_24.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_24.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_24.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_24.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_24, CType(24, Short))
        Me._txtSpace1_24.Location = New System.Drawing.Point(272, 496)
        Me._txtSpace1_24.MaxLength = 0
        Me._txtSpace1_24.Name = "_txtSpace1_24"
        Me._txtSpace1_24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_24.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_24.TabIndex = 165
        '
        '_txtSpace1_23
        '
        Me._txtSpace1_23.AcceptsReturn = True
        Me._txtSpace1_23.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_23.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_23.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_23.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_23.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_23, CType(23, Short))
        Me._txtSpace1_23.Location = New System.Drawing.Point(272, 480)
        Me._txtSpace1_23.MaxLength = 0
        Me._txtSpace1_23.Name = "_txtSpace1_23"
        Me._txtSpace1_23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_23.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_23.TabIndex = 164
        '
        '_txtSpace1_22
        '
        Me._txtSpace1_22.AcceptsReturn = True
        Me._txtSpace1_22.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_22.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_22.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_22.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_22.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_22, CType(22, Short))
        Me._txtSpace1_22.Location = New System.Drawing.Point(272, 464)
        Me._txtSpace1_22.MaxLength = 0
        Me._txtSpace1_22.Name = "_txtSpace1_22"
        Me._txtSpace1_22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_22.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_22.TabIndex = 163
        '
        '_txtSpace1_21
        '
        Me._txtSpace1_21.AcceptsReturn = True
        Me._txtSpace1_21.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_21.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_21.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_21.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_21.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_21, CType(21, Short))
        Me._txtSpace1_21.Location = New System.Drawing.Point(272, 448)
        Me._txtSpace1_21.MaxLength = 0
        Me._txtSpace1_21.Name = "_txtSpace1_21"
        Me._txtSpace1_21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_21.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_21.TabIndex = 162
        '
        '_txtSpace1_20
        '
        Me._txtSpace1_20.AcceptsReturn = True
        Me._txtSpace1_20.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_20.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_20.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_20.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_20, CType(20, Short))
        Me._txtSpace1_20.Location = New System.Drawing.Point(272, 432)
        Me._txtSpace1_20.MaxLength = 0
        Me._txtSpace1_20.Name = "_txtSpace1_20"
        Me._txtSpace1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_20.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_20.TabIndex = 161
        '
        '_txtSpace1_19
        '
        Me._txtSpace1_19.AcceptsReturn = True
        Me._txtSpace1_19.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_19.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_19.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_19.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_19, CType(19, Short))
        Me._txtSpace1_19.Location = New System.Drawing.Point(512, 576)
        Me._txtSpace1_19.MaxLength = 0
        Me._txtSpace1_19.Name = "_txtSpace1_19"
        Me._txtSpace1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_19.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_19.TabIndex = 160
        '
        '_txtSpace1_18
        '
        Me._txtSpace1_18.AcceptsReturn = True
        Me._txtSpace1_18.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_18.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_18.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_18, CType(18, Short))
        Me._txtSpace1_18.Location = New System.Drawing.Point(512, 560)
        Me._txtSpace1_18.MaxLength = 0
        Me._txtSpace1_18.Name = "_txtSpace1_18"
        Me._txtSpace1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_18.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_18.TabIndex = 159
        '
        '_txtSpace1_17
        '
        Me._txtSpace1_17.AcceptsReturn = True
        Me._txtSpace1_17.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_17.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_17.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_17.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_17, CType(17, Short))
        Me._txtSpace1_17.Location = New System.Drawing.Point(512, 544)
        Me._txtSpace1_17.MaxLength = 0
        Me._txtSpace1_17.Name = "_txtSpace1_17"
        Me._txtSpace1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_17.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_17.TabIndex = 158
        '
        '_txtSpace1_16
        '
        Me._txtSpace1_16.AcceptsReturn = True
        Me._txtSpace1_16.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_16.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_16.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_16.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_16, CType(16, Short))
        Me._txtSpace1_16.Location = New System.Drawing.Point(512, 528)
        Me._txtSpace1_16.MaxLength = 0
        Me._txtSpace1_16.Name = "_txtSpace1_16"
        Me._txtSpace1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_16.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_16.TabIndex = 157
        '
        '_txtSpace1_15
        '
        Me._txtSpace1_15.AcceptsReturn = True
        Me._txtSpace1_15.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_15.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_15.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_15, CType(15, Short))
        Me._txtSpace1_15.Location = New System.Drawing.Point(512, 512)
        Me._txtSpace1_15.MaxLength = 0
        Me._txtSpace1_15.Name = "_txtSpace1_15"
        Me._txtSpace1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_15.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_15.TabIndex = 156
        '
        '_txtSpace1_14
        '
        Me._txtSpace1_14.AcceptsReturn = True
        Me._txtSpace1_14.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_14.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_14.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_14.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_14, CType(14, Short))
        Me._txtSpace1_14.Location = New System.Drawing.Point(512, 496)
        Me._txtSpace1_14.MaxLength = 0
        Me._txtSpace1_14.Name = "_txtSpace1_14"
        Me._txtSpace1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_14.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_14.TabIndex = 155
        '
        '_txtSpace1_13
        '
        Me._txtSpace1_13.AcceptsReturn = True
        Me._txtSpace1_13.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_13.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_13.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_13.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_13, CType(13, Short))
        Me._txtSpace1_13.Location = New System.Drawing.Point(512, 480)
        Me._txtSpace1_13.MaxLength = 0
        Me._txtSpace1_13.Name = "_txtSpace1_13"
        Me._txtSpace1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_13.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_13.TabIndex = 154
        '
        '_txtSpace1_12
        '
        Me._txtSpace1_12.AcceptsReturn = True
        Me._txtSpace1_12.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_12.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_12.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_12.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_12, CType(12, Short))
        Me._txtSpace1_12.Location = New System.Drawing.Point(512, 464)
        Me._txtSpace1_12.MaxLength = 0
        Me._txtSpace1_12.Name = "_txtSpace1_12"
        Me._txtSpace1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_12.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_12.TabIndex = 153
        '
        '_txtSpace1_11
        '
        Me._txtSpace1_11.AcceptsReturn = True
        Me._txtSpace1_11.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_11.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_11.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_11, CType(11, Short))
        Me._txtSpace1_11.Location = New System.Drawing.Point(512, 448)
        Me._txtSpace1_11.MaxLength = 0
        Me._txtSpace1_11.Name = "_txtSpace1_11"
        Me._txtSpace1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_11.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_11.TabIndex = 152
        '
        '_txtSpace1_10
        '
        Me._txtSpace1_10.AcceptsReturn = True
        Me._txtSpace1_10.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_10.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_10.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_10, CType(10, Short))
        Me._txtSpace1_10.Location = New System.Drawing.Point(512, 432)
        Me._txtSpace1_10.MaxLength = 0
        Me._txtSpace1_10.Name = "_txtSpace1_10"
        Me._txtSpace1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_10.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_10.TabIndex = 151
        '
        '_txtSpace1_9
        '
        Me._txtSpace1_9.AcceptsReturn = True
        Me._txtSpace1_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_9, CType(9, Short))
        Me._txtSpace1_9.Location = New System.Drawing.Point(128, 576)
        Me._txtSpace1_9.MaxLength = 0
        Me._txtSpace1_9.Name = "_txtSpace1_9"
        Me._txtSpace1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_9.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_9.TabIndex = 150
        '
        '_txtSpace1_8
        '
        Me._txtSpace1_8.AcceptsReturn = True
        Me._txtSpace1_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_8, CType(8, Short))
        Me._txtSpace1_8.Location = New System.Drawing.Point(128, 560)
        Me._txtSpace1_8.MaxLength = 0
        Me._txtSpace1_8.Name = "_txtSpace1_8"
        Me._txtSpace1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_8.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_8.TabIndex = 149
        '
        '_txtSpace1_7
        '
        Me._txtSpace1_7.AcceptsReturn = True
        Me._txtSpace1_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_7, CType(7, Short))
        Me._txtSpace1_7.Location = New System.Drawing.Point(128, 544)
        Me._txtSpace1_7.MaxLength = 0
        Me._txtSpace1_7.Name = "_txtSpace1_7"
        Me._txtSpace1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_7.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_7.TabIndex = 148
        '
        '_txtSpace1_6
        '
        Me._txtSpace1_6.AcceptsReturn = True
        Me._txtSpace1_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_6, CType(6, Short))
        Me._txtSpace1_6.Location = New System.Drawing.Point(128, 528)
        Me._txtSpace1_6.MaxLength = 0
        Me._txtSpace1_6.Name = "_txtSpace1_6"
        Me._txtSpace1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_6.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_6.TabIndex = 147
        '
        '_txtSpace1_5
        '
        Me._txtSpace1_5.AcceptsReturn = True
        Me._txtSpace1_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_5, CType(5, Short))
        Me._txtSpace1_5.Location = New System.Drawing.Point(128, 512)
        Me._txtSpace1_5.MaxLength = 0
        Me._txtSpace1_5.Name = "_txtSpace1_5"
        Me._txtSpace1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_5.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_5.TabIndex = 146
        '
        '_txtSpace1_4
        '
        Me._txtSpace1_4.AcceptsReturn = True
        Me._txtSpace1_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_4, CType(4, Short))
        Me._txtSpace1_4.Location = New System.Drawing.Point(128, 496)
        Me._txtSpace1_4.MaxLength = 0
        Me._txtSpace1_4.Name = "_txtSpace1_4"
        Me._txtSpace1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_4.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_4.TabIndex = 145
        '
        '_txtSpace1_3
        '
        Me._txtSpace1_3.AcceptsReturn = True
        Me._txtSpace1_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_3, CType(3, Short))
        Me._txtSpace1_3.Location = New System.Drawing.Point(128, 480)
        Me._txtSpace1_3.MaxLength = 0
        Me._txtSpace1_3.Name = "_txtSpace1_3"
        Me._txtSpace1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_3.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_3.TabIndex = 144
        '
        '_txtSpace1_2
        '
        Me._txtSpace1_2.AcceptsReturn = True
        Me._txtSpace1_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_2, CType(2, Short))
        Me._txtSpace1_2.Location = New System.Drawing.Point(128, 464)
        Me._txtSpace1_2.MaxLength = 0
        Me._txtSpace1_2.Name = "_txtSpace1_2"
        Me._txtSpace1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_2.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_2.TabIndex = 143
        '
        '_txtSpace1_1
        '
        Me._txtSpace1_1.AcceptsReturn = True
        Me._txtSpace1_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_1, CType(1, Short))
        Me._txtSpace1_1.Location = New System.Drawing.Point(128, 448)
        Me._txtSpace1_1.MaxLength = 0
        Me._txtSpace1_1.Name = "_txtSpace1_1"
        Me._txtSpace1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_1.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_1.TabIndex = 142
        '
        '_txtSpace1_0
        '
        Me._txtSpace1_0.AcceptsReturn = True
        Me._txtSpace1_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtSpace1_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtSpace1_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtSpace1_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtSpace1_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpace1.SetIndex(Me._txtSpace1_0, CType(0, Short))
        Me._txtSpace1_0.Location = New System.Drawing.Point(128, 432)
        Me._txtSpace1_0.MaxLength = 0
        Me._txtSpace1_0.Name = "_txtSpace1_0"
        Me._txtSpace1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtSpace1_0.Size = New System.Drawing.Size(9, 13)
        Me._txtSpace1_0.TabIndex = 141
        '
        '_txtAmount_9
        '
        Me._txtAmount_9.AcceptsReturn = True
        Me._txtAmount_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_9, CType(9, Short))
        Me._txtAmount_9.Location = New System.Drawing.Point(560, 576)
        Me._txtAmount_9.MaxLength = 0
        Me._txtAmount_9.Name = "_txtAmount_9"
        Me._txtAmount_9.ReadOnly = True
        Me._txtAmount_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_9.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_9.TabIndex = 140
        Me._txtAmount_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_9
        '
        Me._txtRate_9.AcceptsReturn = True
        Me._txtRate_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_9, CType(9, Short))
        Me._txtRate_9.Location = New System.Drawing.Point(520, 576)
        Me._txtRate_9.MaxLength = 0
        Me._txtRate_9.Name = "_txtRate_9"
        Me._txtRate_9.ReadOnly = True
        Me._txtRate_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_9.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_9.TabIndex = 139
        Me._txtRate_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_9
        '
        Me._txtDesc_9.AcceptsReturn = True
        Me._txtDesc_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_9, CType(9, Short))
        Me._txtDesc_9.Location = New System.Drawing.Point(280, 576)
        Me._txtDesc_9.MaxLength = 0
        Me._txtDesc_9.Name = "_txtDesc_9"
        Me._txtDesc_9.ReadOnly = True
        Me._txtDesc_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_9.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_9.TabIndex = 138
        '
        '_txtItemFullName_9
        '
        Me._txtItemFullName_9.AcceptsReturn = True
        Me._txtItemFullName_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_9, CType(9, Short))
        Me._txtItemFullName_9.Location = New System.Drawing.Point(136, 576)
        Me._txtItemFullName_9.MaxLength = 0
        Me._txtItemFullName_9.Name = "_txtItemFullName_9"
        Me._txtItemFullName_9.ReadOnly = True
        Me._txtItemFullName_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_9.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_9.TabIndex = 137
        '
        '_txtQuantity_9
        '
        Me._txtQuantity_9.AcceptsReturn = True
        Me._txtQuantity_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_9, CType(9, Short))
        Me._txtQuantity_9.Location = New System.Drawing.Point(104, 576)
        Me._txtQuantity_9.MaxLength = 0
        Me._txtQuantity_9.Name = "_txtQuantity_9"
        Me._txtQuantity_9.ReadOnly = True
        Me._txtQuantity_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_9.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_9.TabIndex = 136
        Me._txtQuantity_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_9
        '
        Me._txtItemLineNumber_9.AcceptsReturn = True
        Me._txtItemLineNumber_9.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_9.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_9, CType(9, Short))
        Me._txtItemLineNumber_9.Location = New System.Drawing.Point(8, 576)
        Me._txtItemLineNumber_9.MaxLength = 0
        Me._txtItemLineNumber_9.Name = "_txtItemLineNumber_9"
        Me._txtItemLineNumber_9.ReadOnly = True
        Me._txtItemLineNumber_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_9.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_9.TabIndex = 135
        Me._txtItemLineNumber_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_8
        '
        Me._txtAmount_8.AcceptsReturn = True
        Me._txtAmount_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_8, CType(8, Short))
        Me._txtAmount_8.Location = New System.Drawing.Point(560, 560)
        Me._txtAmount_8.MaxLength = 0
        Me._txtAmount_8.Name = "_txtAmount_8"
        Me._txtAmount_8.ReadOnly = True
        Me._txtAmount_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_8.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_8.TabIndex = 134
        Me._txtAmount_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_8
        '
        Me._txtRate_8.AcceptsReturn = True
        Me._txtRate_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_8, CType(8, Short))
        Me._txtRate_8.Location = New System.Drawing.Point(520, 560)
        Me._txtRate_8.MaxLength = 0
        Me._txtRate_8.Name = "_txtRate_8"
        Me._txtRate_8.ReadOnly = True
        Me._txtRate_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_8.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_8.TabIndex = 133
        Me._txtRate_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_8
        '
        Me._txtDesc_8.AcceptsReturn = True
        Me._txtDesc_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_8, CType(8, Short))
        Me._txtDesc_8.Location = New System.Drawing.Point(280, 560)
        Me._txtDesc_8.MaxLength = 0
        Me._txtDesc_8.Name = "_txtDesc_8"
        Me._txtDesc_8.ReadOnly = True
        Me._txtDesc_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_8.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_8.TabIndex = 132
        '
        '_txtItemFullName_8
        '
        Me._txtItemFullName_8.AcceptsReturn = True
        Me._txtItemFullName_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_8, CType(8, Short))
        Me._txtItemFullName_8.Location = New System.Drawing.Point(136, 560)
        Me._txtItemFullName_8.MaxLength = 0
        Me._txtItemFullName_8.Name = "_txtItemFullName_8"
        Me._txtItemFullName_8.ReadOnly = True
        Me._txtItemFullName_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_8.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_8.TabIndex = 131
        '
        '_txtQuantity_8
        '
        Me._txtQuantity_8.AcceptsReturn = True
        Me._txtQuantity_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_8, CType(8, Short))
        Me._txtQuantity_8.Location = New System.Drawing.Point(104, 560)
        Me._txtQuantity_8.MaxLength = 0
        Me._txtQuantity_8.Name = "_txtQuantity_8"
        Me._txtQuantity_8.ReadOnly = True
        Me._txtQuantity_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_8.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_8.TabIndex = 130
        Me._txtQuantity_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_8
        '
        Me._txtItemLineNumber_8.AcceptsReturn = True
        Me._txtItemLineNumber_8.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_8, CType(8, Short))
        Me._txtItemLineNumber_8.Location = New System.Drawing.Point(8, 560)
        Me._txtItemLineNumber_8.MaxLength = 0
        Me._txtItemLineNumber_8.Name = "_txtItemLineNumber_8"
        Me._txtItemLineNumber_8.ReadOnly = True
        Me._txtItemLineNumber_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_8.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_8.TabIndex = 129
        Me._txtItemLineNumber_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_7
        '
        Me._txtAmount_7.AcceptsReturn = True
        Me._txtAmount_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_7, CType(7, Short))
        Me._txtAmount_7.Location = New System.Drawing.Point(560, 544)
        Me._txtAmount_7.MaxLength = 0
        Me._txtAmount_7.Name = "_txtAmount_7"
        Me._txtAmount_7.ReadOnly = True
        Me._txtAmount_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_7.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_7.TabIndex = 128
        Me._txtAmount_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_7
        '
        Me._txtRate_7.AcceptsReturn = True
        Me._txtRate_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_7, CType(7, Short))
        Me._txtRate_7.Location = New System.Drawing.Point(520, 544)
        Me._txtRate_7.MaxLength = 0
        Me._txtRate_7.Name = "_txtRate_7"
        Me._txtRate_7.ReadOnly = True
        Me._txtRate_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_7.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_7.TabIndex = 127
        Me._txtRate_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_7
        '
        Me._txtDesc_7.AcceptsReturn = True
        Me._txtDesc_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_7, CType(7, Short))
        Me._txtDesc_7.Location = New System.Drawing.Point(280, 544)
        Me._txtDesc_7.MaxLength = 0
        Me._txtDesc_7.Name = "_txtDesc_7"
        Me._txtDesc_7.ReadOnly = True
        Me._txtDesc_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_7.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_7.TabIndex = 126
        '
        '_txtItemFullName_7
        '
        Me._txtItemFullName_7.AcceptsReturn = True
        Me._txtItemFullName_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_7, CType(7, Short))
        Me._txtItemFullName_7.Location = New System.Drawing.Point(136, 544)
        Me._txtItemFullName_7.MaxLength = 0
        Me._txtItemFullName_7.Name = "_txtItemFullName_7"
        Me._txtItemFullName_7.ReadOnly = True
        Me._txtItemFullName_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_7.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_7.TabIndex = 125
        '
        '_txtQuantity_7
        '
        Me._txtQuantity_7.AcceptsReturn = True
        Me._txtQuantity_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_7, CType(7, Short))
        Me._txtQuantity_7.Location = New System.Drawing.Point(104, 544)
        Me._txtQuantity_7.MaxLength = 0
        Me._txtQuantity_7.Name = "_txtQuantity_7"
        Me._txtQuantity_7.ReadOnly = True
        Me._txtQuantity_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_7.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_7.TabIndex = 124
        Me._txtQuantity_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_7
        '
        Me._txtItemLineNumber_7.AcceptsReturn = True
        Me._txtItemLineNumber_7.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_7, CType(7, Short))
        Me._txtItemLineNumber_7.Location = New System.Drawing.Point(8, 544)
        Me._txtItemLineNumber_7.MaxLength = 0
        Me._txtItemLineNumber_7.Name = "_txtItemLineNumber_7"
        Me._txtItemLineNumber_7.ReadOnly = True
        Me._txtItemLineNumber_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_7.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_7.TabIndex = 123
        Me._txtItemLineNumber_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_6
        '
        Me._txtAmount_6.AcceptsReturn = True
        Me._txtAmount_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_6, CType(6, Short))
        Me._txtAmount_6.Location = New System.Drawing.Point(560, 528)
        Me._txtAmount_6.MaxLength = 0
        Me._txtAmount_6.Name = "_txtAmount_6"
        Me._txtAmount_6.ReadOnly = True
        Me._txtAmount_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_6.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_6.TabIndex = 122
        Me._txtAmount_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_6
        '
        Me._txtRate_6.AcceptsReturn = True
        Me._txtRate_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_6, CType(6, Short))
        Me._txtRate_6.Location = New System.Drawing.Point(520, 528)
        Me._txtRate_6.MaxLength = 0
        Me._txtRate_6.Name = "_txtRate_6"
        Me._txtRate_6.ReadOnly = True
        Me._txtRate_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_6.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_6.TabIndex = 121
        Me._txtRate_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_6
        '
        Me._txtDesc_6.AcceptsReturn = True
        Me._txtDesc_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_6, CType(6, Short))
        Me._txtDesc_6.Location = New System.Drawing.Point(280, 528)
        Me._txtDesc_6.MaxLength = 0
        Me._txtDesc_6.Name = "_txtDesc_6"
        Me._txtDesc_6.ReadOnly = True
        Me._txtDesc_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_6.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_6.TabIndex = 120
        '
        '_txtItemFullName_6
        '
        Me._txtItemFullName_6.AcceptsReturn = True
        Me._txtItemFullName_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_6, CType(6, Short))
        Me._txtItemFullName_6.Location = New System.Drawing.Point(136, 528)
        Me._txtItemFullName_6.MaxLength = 0
        Me._txtItemFullName_6.Name = "_txtItemFullName_6"
        Me._txtItemFullName_6.ReadOnly = True
        Me._txtItemFullName_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_6.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_6.TabIndex = 119
        '
        '_txtQuantity_6
        '
        Me._txtQuantity_6.AcceptsReturn = True
        Me._txtQuantity_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_6, CType(6, Short))
        Me._txtQuantity_6.Location = New System.Drawing.Point(104, 528)
        Me._txtQuantity_6.MaxLength = 0
        Me._txtQuantity_6.Name = "_txtQuantity_6"
        Me._txtQuantity_6.ReadOnly = True
        Me._txtQuantity_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_6.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_6.TabIndex = 118
        Me._txtQuantity_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_6
        '
        Me._txtItemLineNumber_6.AcceptsReturn = True
        Me._txtItemLineNumber_6.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_6, CType(6, Short))
        Me._txtItemLineNumber_6.Location = New System.Drawing.Point(8, 528)
        Me._txtItemLineNumber_6.MaxLength = 0
        Me._txtItemLineNumber_6.Name = "_txtItemLineNumber_6"
        Me._txtItemLineNumber_6.ReadOnly = True
        Me._txtItemLineNumber_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_6.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_6.TabIndex = 117
        Me._txtItemLineNumber_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_5
        '
        Me._txtAmount_5.AcceptsReturn = True
        Me._txtAmount_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_5, CType(5, Short))
        Me._txtAmount_5.Location = New System.Drawing.Point(560, 512)
        Me._txtAmount_5.MaxLength = 0
        Me._txtAmount_5.Name = "_txtAmount_5"
        Me._txtAmount_5.ReadOnly = True
        Me._txtAmount_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_5.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_5.TabIndex = 116
        Me._txtAmount_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_5
        '
        Me._txtRate_5.AcceptsReturn = True
        Me._txtRate_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_5, CType(5, Short))
        Me._txtRate_5.Location = New System.Drawing.Point(520, 512)
        Me._txtRate_5.MaxLength = 0
        Me._txtRate_5.Name = "_txtRate_5"
        Me._txtRate_5.ReadOnly = True
        Me._txtRate_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_5.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_5.TabIndex = 115
        Me._txtRate_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_5
        '
        Me._txtDesc_5.AcceptsReturn = True
        Me._txtDesc_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_5, CType(5, Short))
        Me._txtDesc_5.Location = New System.Drawing.Point(280, 512)
        Me._txtDesc_5.MaxLength = 0
        Me._txtDesc_5.Name = "_txtDesc_5"
        Me._txtDesc_5.ReadOnly = True
        Me._txtDesc_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_5.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_5.TabIndex = 114
        '
        '_txtItemFullName_5
        '
        Me._txtItemFullName_5.AcceptsReturn = True
        Me._txtItemFullName_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_5, CType(5, Short))
        Me._txtItemFullName_5.Location = New System.Drawing.Point(136, 512)
        Me._txtItemFullName_5.MaxLength = 0
        Me._txtItemFullName_5.Name = "_txtItemFullName_5"
        Me._txtItemFullName_5.ReadOnly = True
        Me._txtItemFullName_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_5.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_5.TabIndex = 113
        '
        '_txtQuantity_5
        '
        Me._txtQuantity_5.AcceptsReturn = True
        Me._txtQuantity_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_5, CType(5, Short))
        Me._txtQuantity_5.Location = New System.Drawing.Point(104, 512)
        Me._txtQuantity_5.MaxLength = 0
        Me._txtQuantity_5.Name = "_txtQuantity_5"
        Me._txtQuantity_5.ReadOnly = True
        Me._txtQuantity_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_5.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_5.TabIndex = 112
        Me._txtQuantity_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_5
        '
        Me._txtItemLineNumber_5.AcceptsReturn = True
        Me._txtItemLineNumber_5.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_5, CType(5, Short))
        Me._txtItemLineNumber_5.Location = New System.Drawing.Point(8, 512)
        Me._txtItemLineNumber_5.MaxLength = 0
        Me._txtItemLineNumber_5.Name = "_txtItemLineNumber_5"
        Me._txtItemLineNumber_5.ReadOnly = True
        Me._txtItemLineNumber_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_5.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_5.TabIndex = 111
        Me._txtItemLineNumber_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_4
        '
        Me._txtAmount_4.AcceptsReturn = True
        Me._txtAmount_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_4, CType(4, Short))
        Me._txtAmount_4.Location = New System.Drawing.Point(560, 496)
        Me._txtAmount_4.MaxLength = 0
        Me._txtAmount_4.Name = "_txtAmount_4"
        Me._txtAmount_4.ReadOnly = True
        Me._txtAmount_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_4.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_4.TabIndex = 110
        Me._txtAmount_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_4
        '
        Me._txtRate_4.AcceptsReturn = True
        Me._txtRate_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_4, CType(4, Short))
        Me._txtRate_4.Location = New System.Drawing.Point(520, 496)
        Me._txtRate_4.MaxLength = 0
        Me._txtRate_4.Name = "_txtRate_4"
        Me._txtRate_4.ReadOnly = True
        Me._txtRate_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_4.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_4.TabIndex = 109
        Me._txtRate_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_4
        '
        Me._txtDesc_4.AcceptsReturn = True
        Me._txtDesc_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_4, CType(4, Short))
        Me._txtDesc_4.Location = New System.Drawing.Point(280, 496)
        Me._txtDesc_4.MaxLength = 0
        Me._txtDesc_4.Name = "_txtDesc_4"
        Me._txtDesc_4.ReadOnly = True
        Me._txtDesc_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_4.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_4.TabIndex = 108
        '
        '_txtItemFullName_4
        '
        Me._txtItemFullName_4.AcceptsReturn = True
        Me._txtItemFullName_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_4, CType(4, Short))
        Me._txtItemFullName_4.Location = New System.Drawing.Point(136, 496)
        Me._txtItemFullName_4.MaxLength = 0
        Me._txtItemFullName_4.Name = "_txtItemFullName_4"
        Me._txtItemFullName_4.ReadOnly = True
        Me._txtItemFullName_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_4.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_4.TabIndex = 107
        '
        '_txtQuantity_4
        '
        Me._txtQuantity_4.AcceptsReturn = True
        Me._txtQuantity_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_4, CType(4, Short))
        Me._txtQuantity_4.Location = New System.Drawing.Point(104, 496)
        Me._txtQuantity_4.MaxLength = 0
        Me._txtQuantity_4.Name = "_txtQuantity_4"
        Me._txtQuantity_4.ReadOnly = True
        Me._txtQuantity_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_4.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_4.TabIndex = 106
        Me._txtQuantity_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_4
        '
        Me._txtItemLineNumber_4.AcceptsReturn = True
        Me._txtItemLineNumber_4.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_4, CType(4, Short))
        Me._txtItemLineNumber_4.Location = New System.Drawing.Point(8, 496)
        Me._txtItemLineNumber_4.MaxLength = 0
        Me._txtItemLineNumber_4.Name = "_txtItemLineNumber_4"
        Me._txtItemLineNumber_4.ReadOnly = True
        Me._txtItemLineNumber_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_4.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_4.TabIndex = 105
        Me._txtItemLineNumber_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_3
        '
        Me._txtAmount_3.AcceptsReturn = True
        Me._txtAmount_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_3, CType(3, Short))
        Me._txtAmount_3.Location = New System.Drawing.Point(560, 480)
        Me._txtAmount_3.MaxLength = 0
        Me._txtAmount_3.Name = "_txtAmount_3"
        Me._txtAmount_3.ReadOnly = True
        Me._txtAmount_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_3.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_3.TabIndex = 104
        Me._txtAmount_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_3
        '
        Me._txtRate_3.AcceptsReturn = True
        Me._txtRate_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_3, CType(3, Short))
        Me._txtRate_3.Location = New System.Drawing.Point(520, 480)
        Me._txtRate_3.MaxLength = 0
        Me._txtRate_3.Name = "_txtRate_3"
        Me._txtRate_3.ReadOnly = True
        Me._txtRate_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_3.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_3.TabIndex = 103
        Me._txtRate_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_3
        '
        Me._txtDesc_3.AcceptsReturn = True
        Me._txtDesc_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_3, CType(3, Short))
        Me._txtDesc_3.Location = New System.Drawing.Point(280, 480)
        Me._txtDesc_3.MaxLength = 0
        Me._txtDesc_3.Name = "_txtDesc_3"
        Me._txtDesc_3.ReadOnly = True
        Me._txtDesc_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_3.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_3.TabIndex = 102
        '
        '_txtItemFullName_3
        '
        Me._txtItemFullName_3.AcceptsReturn = True
        Me._txtItemFullName_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_3, CType(3, Short))
        Me._txtItemFullName_3.Location = New System.Drawing.Point(136, 480)
        Me._txtItemFullName_3.MaxLength = 0
        Me._txtItemFullName_3.Name = "_txtItemFullName_3"
        Me._txtItemFullName_3.ReadOnly = True
        Me._txtItemFullName_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_3.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_3.TabIndex = 101
        '
        '_txtQuantity_3
        '
        Me._txtQuantity_3.AcceptsReturn = True
        Me._txtQuantity_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_3, CType(3, Short))
        Me._txtQuantity_3.Location = New System.Drawing.Point(104, 480)
        Me._txtQuantity_3.MaxLength = 0
        Me._txtQuantity_3.Name = "_txtQuantity_3"
        Me._txtQuantity_3.ReadOnly = True
        Me._txtQuantity_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_3.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_3.TabIndex = 100
        Me._txtQuantity_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_3
        '
        Me._txtItemLineNumber_3.AcceptsReturn = True
        Me._txtItemLineNumber_3.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_3, CType(3, Short))
        Me._txtItemLineNumber_3.Location = New System.Drawing.Point(8, 480)
        Me._txtItemLineNumber_3.MaxLength = 0
        Me._txtItemLineNumber_3.Name = "_txtItemLineNumber_3"
        Me._txtItemLineNumber_3.ReadOnly = True
        Me._txtItemLineNumber_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_3.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_3.TabIndex = 99
        Me._txtItemLineNumber_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_2
        '
        Me._txtAmount_2.AcceptsReturn = True
        Me._txtAmount_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_2, CType(2, Short))
        Me._txtAmount_2.Location = New System.Drawing.Point(560, 464)
        Me._txtAmount_2.MaxLength = 0
        Me._txtAmount_2.Name = "_txtAmount_2"
        Me._txtAmount_2.ReadOnly = True
        Me._txtAmount_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_2.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_2.TabIndex = 98
        Me._txtAmount_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_2
        '
        Me._txtRate_2.AcceptsReturn = True
        Me._txtRate_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_2, CType(2, Short))
        Me._txtRate_2.Location = New System.Drawing.Point(520, 464)
        Me._txtRate_2.MaxLength = 0
        Me._txtRate_2.Name = "_txtRate_2"
        Me._txtRate_2.ReadOnly = True
        Me._txtRate_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_2.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_2.TabIndex = 97
        Me._txtRate_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_2
        '
        Me._txtDesc_2.AcceptsReturn = True
        Me._txtDesc_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_2, CType(2, Short))
        Me._txtDesc_2.Location = New System.Drawing.Point(280, 464)
        Me._txtDesc_2.MaxLength = 0
        Me._txtDesc_2.Name = "_txtDesc_2"
        Me._txtDesc_2.ReadOnly = True
        Me._txtDesc_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_2.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_2.TabIndex = 96
        '
        '_txtItemFullName_2
        '
        Me._txtItemFullName_2.AcceptsReturn = True
        Me._txtItemFullName_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_2, CType(2, Short))
        Me._txtItemFullName_2.Location = New System.Drawing.Point(136, 464)
        Me._txtItemFullName_2.MaxLength = 0
        Me._txtItemFullName_2.Name = "_txtItemFullName_2"
        Me._txtItemFullName_2.ReadOnly = True
        Me._txtItemFullName_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_2.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_2.TabIndex = 95
        '
        '_txtQuantity_2
        '
        Me._txtQuantity_2.AcceptsReturn = True
        Me._txtQuantity_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_2, CType(2, Short))
        Me._txtQuantity_2.Location = New System.Drawing.Point(104, 464)
        Me._txtQuantity_2.MaxLength = 0
        Me._txtQuantity_2.Name = "_txtQuantity_2"
        Me._txtQuantity_2.ReadOnly = True
        Me._txtQuantity_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_2.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_2.TabIndex = 94
        Me._txtQuantity_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_2
        '
        Me._txtItemLineNumber_2.AcceptsReturn = True
        Me._txtItemLineNumber_2.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_2, CType(2, Short))
        Me._txtItemLineNumber_2.Location = New System.Drawing.Point(8, 464)
        Me._txtItemLineNumber_2.MaxLength = 0
        Me._txtItemLineNumber_2.Name = "_txtItemLineNumber_2"
        Me._txtItemLineNumber_2.ReadOnly = True
        Me._txtItemLineNumber_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_2.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_2.TabIndex = 93
        Me._txtItemLineNumber_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtAmount_1
        '
        Me._txtAmount_1.AcceptsReturn = True
        Me._txtAmount_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_1, CType(1, Short))
        Me._txtAmount_1.Location = New System.Drawing.Point(560, 448)
        Me._txtAmount_1.MaxLength = 0
        Me._txtAmount_1.Name = "_txtAmount_1"
        Me._txtAmount_1.ReadOnly = True
        Me._txtAmount_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_1.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_1.TabIndex = 92
        Me._txtAmount_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_1
        '
        Me._txtRate_1.AcceptsReturn = True
        Me._txtRate_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_1, CType(1, Short))
        Me._txtRate_1.Location = New System.Drawing.Point(520, 448)
        Me._txtRate_1.MaxLength = 0
        Me._txtRate_1.Name = "_txtRate_1"
        Me._txtRate_1.ReadOnly = True
        Me._txtRate_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_1.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_1.TabIndex = 91
        Me._txtRate_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_1
        '
        Me._txtDesc_1.AcceptsReturn = True
        Me._txtDesc_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_1, CType(1, Short))
        Me._txtDesc_1.Location = New System.Drawing.Point(280, 448)
        Me._txtDesc_1.MaxLength = 0
        Me._txtDesc_1.Name = "_txtDesc_1"
        Me._txtDesc_1.ReadOnly = True
        Me._txtDesc_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_1.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_1.TabIndex = 90
        '
        '_txtItemFullName_1
        '
        Me._txtItemFullName_1.AcceptsReturn = True
        Me._txtItemFullName_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_1, CType(1, Short))
        Me._txtItemFullName_1.Location = New System.Drawing.Point(136, 448)
        Me._txtItemFullName_1.MaxLength = 0
        Me._txtItemFullName_1.Name = "_txtItemFullName_1"
        Me._txtItemFullName_1.ReadOnly = True
        Me._txtItemFullName_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_1.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_1.TabIndex = 89
        '
        '_txtQuantity_1
        '
        Me._txtQuantity_1.AcceptsReturn = True
        Me._txtQuantity_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_1, CType(1, Short))
        Me._txtQuantity_1.Location = New System.Drawing.Point(104, 448)
        Me._txtQuantity_1.MaxLength = 0
        Me._txtQuantity_1.Name = "_txtQuantity_1"
        Me._txtQuantity_1.ReadOnly = True
        Me._txtQuantity_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_1.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_1.TabIndex = 88
        Me._txtQuantity_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_1
        '
        Me._txtItemLineNumber_1.AcceptsReturn = True
        Me._txtItemLineNumber_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_1, CType(1, Short))
        Me._txtItemLineNumber_1.Location = New System.Drawing.Point(8, 448)
        Me._txtItemLineNumber_1.MaxLength = 0
        Me._txtItemLineNumber_1.Name = "_txtItemLineNumber_1"
        Me._txtItemLineNumber_1.ReadOnly = True
        Me._txtItemLineNumber_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_1.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_1.TabIndex = 87
        Me._txtItemLineNumber_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmdFinish
        '
        Me.cmdFinish.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFinish.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFinish.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFinish.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFinish.Location = New System.Drawing.Point(552, 608)
        Me.cmdFinish.Name = "cmdFinish"
        Me.cmdFinish.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFinish.Size = New System.Drawing.Size(81, 57)
        Me.cmdFinish.TabIndex = 86
        Me.cmdFinish.Text = "Return to Invoice Selection"
        Me.cmdFinish.UseVisualStyleBackColor = False
        '
        'cmdDoModify
        '
        Me.cmdDoModify.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDoModify.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDoModify.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDoModify.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDoModify.Location = New System.Drawing.Point(456, 608)
        Me.cmdDoModify.Name = "cmdDoModify"
        Me.cmdDoModify.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDoModify.Size = New System.Drawing.Size(81, 57)
        Me.cmdDoModify.TabIndex = 85
        Me.cmdDoModify.Text = "Modify Invoice"
        Me.cmdDoModify.UseVisualStyleBackColor = False
        '
        'cmdUndo
        '
        Me.cmdUndo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdUndo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdUndo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUndo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdUndo.Location = New System.Drawing.Point(368, 608)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdUndo.Size = New System.Drawing.Size(81, 57)
        Me.cmdUndo.TabIndex = 84
        Me.cmdUndo.Text = "Undo All Invoice Changes"
        Me.cmdUndo.UseVisualStyleBackColor = False
        '
        'cmdDeleteUndelete
        '
        Me.cmdDeleteUndelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDeleteUndelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDeleteUndelete.Enabled = False
        Me.cmdDeleteUndelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteUndelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDeleteUndelete.Location = New System.Drawing.Point(272, 608)
        Me.cmdDeleteUndelete.Name = "cmdDeleteUndelete"
        Me.cmdDeleteUndelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDeleteUndelete.Size = New System.Drawing.Size(81, 49)
        Me.cmdDeleteUndelete.TabIndex = 83
        Me.cmdDeleteUndelete.Text = "Delete Line"
        Me.cmdDeleteUndelete.UseVisualStyleBackColor = False
        '
        'cmdAddLineBefore
        '
        Me.cmdAddLineBefore.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddLineBefore.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddLineBefore.Enabled = False
        Me.cmdAddLineBefore.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddLineBefore.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddLineBefore.Location = New System.Drawing.Point(96, 608)
        Me.cmdAddLineBefore.Name = "cmdAddLineBefore"
        Me.cmdAddLineBefore.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddLineBefore.Size = New System.Drawing.Size(81, 49)
        Me.cmdAddLineBefore.TabIndex = 82
        Me.cmdAddLineBefore.Text = "Add Line Before Current Line"
        Me.cmdAddLineBefore.UseVisualStyleBackColor = False
        '
        'cmdAddLineAfter
        '
        Me.cmdAddLineAfter.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddLineAfter.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddLineAfter.Enabled = False
        Me.cmdAddLineAfter.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddLineAfter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddLineAfter.Location = New System.Drawing.Point(184, 608)
        Me.cmdAddLineAfter.Name = "cmdAddLineAfter"
        Me.cmdAddLineAfter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddLineAfter.Size = New System.Drawing.Size(81, 49)
        Me.cmdAddLineAfter.TabIndex = 81
        Me.cmdAddLineAfter.Text = "Add Line After Current Line"
        Me.cmdAddLineAfter.UseVisualStyleBackColor = False
        '
        'cmdEditLine
        '
        Me.cmdEditLine.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEditLine.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEditLine.Enabled = False
        Me.cmdEditLine.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEditLine.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEditLine.Location = New System.Drawing.Point(8, 608)
        Me.cmdEditLine.Name = "cmdEditLine"
        Me.cmdEditLine.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdEditLine.Size = New System.Drawing.Size(81, 49)
        Me.cmdEditLine.TabIndex = 80
        Me.cmdEditLine.Text = "Edit Line"
        Me.cmdEditLine.UseVisualStyleBackColor = False
        '
        'vscInvoiceLineScroll
        '
        Me.vscInvoiceLineScroll.Cursor = System.Windows.Forms.Cursors.Default
        Me.vscInvoiceLineScroll.Location = New System.Drawing.Point(616, 432)
        Me.vscInvoiceLineScroll.Maximum = 32776
        Me.vscInvoiceLineScroll.Name = "vscInvoiceLineScroll"
        Me.vscInvoiceLineScroll.Size = New System.Drawing.Size(17, 161)
        Me.vscInvoiceLineScroll.TabIndex = 79
        Me.vscInvoiceLineScroll.TabStop = True
        Me.vscInvoiceLineScroll.Value = 1
        '
        '_txtAmount_0
        '
        Me._txtAmount_0.AcceptsReturn = True
        Me._txtAmount_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtAmount_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtAmount_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtAmount_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtAmount_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAmount.SetIndex(Me._txtAmount_0, CType(0, Short))
        Me._txtAmount_0.Location = New System.Drawing.Point(560, 432)
        Me._txtAmount_0.MaxLength = 0
        Me._txtAmount_0.Name = "_txtAmount_0"
        Me._txtAmount_0.ReadOnly = True
        Me._txtAmount_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtAmount_0.Size = New System.Drawing.Size(49, 13)
        Me._txtAmount_0.TabIndex = 78
        Me._txtAmount_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtRate_0
        '
        Me._txtRate_0.AcceptsReturn = True
        Me._txtRate_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtRate_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtRate_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtRate_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtRate_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRate.SetIndex(Me._txtRate_0, CType(0, Short))
        Me._txtRate_0.Location = New System.Drawing.Point(520, 432)
        Me._txtRate_0.MaxLength = 0
        Me._txtRate_0.Name = "_txtRate_0"
        Me._txtRate_0.ReadOnly = True
        Me._txtRate_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtRate_0.Size = New System.Drawing.Size(41, 13)
        Me._txtRate_0.TabIndex = 77
        Me._txtRate_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtDesc_0
        '
        Me._txtDesc_0.AcceptsReturn = True
        Me._txtDesc_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtDesc_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtDesc_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDesc_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDesc_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDesc.SetIndex(Me._txtDesc_0, CType(0, Short))
        Me._txtDesc_0.Location = New System.Drawing.Point(280, 432)
        Me._txtDesc_0.MaxLength = 0
        Me._txtDesc_0.Name = "_txtDesc_0"
        Me._txtDesc_0.ReadOnly = True
        Me._txtDesc_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDesc_0.Size = New System.Drawing.Size(233, 13)
        Me._txtDesc_0.TabIndex = 76
        '
        '_txtItemFullName_0
        '
        Me._txtItemFullName_0.AcceptsReturn = True
        Me._txtItemFullName_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemFullName_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemFullName_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemFullName_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemFullName_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtItemFullName.SetIndex(Me._txtItemFullName_0, CType(0, Short))
        Me._txtItemFullName_0.Location = New System.Drawing.Point(136, 432)
        Me._txtItemFullName_0.MaxLength = 0
        Me._txtItemFullName_0.Name = "_txtItemFullName_0"
        Me._txtItemFullName_0.ReadOnly = True
        Me._txtItemFullName_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemFullName_0.Size = New System.Drawing.Size(137, 13)
        Me._txtItemFullName_0.TabIndex = 75
        '
        '_txtQuantity_0
        '
        Me._txtQuantity_0.AcceptsReturn = True
        Me._txtQuantity_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtQuantity_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtQuantity_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtQuantity_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtQuantity_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantity.SetIndex(Me._txtQuantity_0, CType(0, Short))
        Me._txtQuantity_0.Location = New System.Drawing.Point(104, 432)
        Me._txtQuantity_0.MaxLength = 0
        Me._txtQuantity_0.Name = "_txtQuantity_0"
        Me._txtQuantity_0.ReadOnly = True
        Me._txtQuantity_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtQuantity_0.Size = New System.Drawing.Size(25, 13)
        Me._txtQuantity_0.TabIndex = 74
        Me._txtQuantity_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        '_txtItemLineNumber_0
        '
        Me._txtItemLineNumber_0.AcceptsReturn = True
        Me._txtItemLineNumber_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtItemLineNumber_0.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._txtItemLineNumber_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtItemLineNumber_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtItemLineNumber_0.ForeColor = System.Drawing.Color.Red
        Me.txtItemLineNumber.SetIndex(Me._txtItemLineNumber_0, CType(0, Short))
        Me._txtItemLineNumber_0.Location = New System.Drawing.Point(8, 432)
        Me._txtItemLineNumber_0.MaxLength = 0
        Me._txtItemLineNumber_0.Name = "_txtItemLineNumber_0"
        Me._txtItemLineNumber_0.ReadOnly = True
        Me._txtItemLineNumber_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtItemLineNumber_0.Size = New System.Drawing.Size(97, 13)
        Me._txtItemLineNumber_0.TabIndex = 73
        Me._txtItemLineNumber_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmdEditMemo
        '
        Me.cmdEditMemo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEditMemo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEditMemo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEditMemo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEditMemo.Location = New System.Drawing.Point(560, 384)
        Me.cmdEditMemo.Name = "cmdEditMemo"
        Me.cmdEditMemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdEditMemo.Size = New System.Drawing.Size(73, 17)
        Me.cmdEditMemo.TabIndex = 72
        Me.cmdEditMemo.Text = "Edit Memo"
        Me.cmdEditMemo.UseVisualStyleBackColor = False
        '
        'txtMemo
        '
        Me.txtMemo.AcceptsReturn = True
        Me.txtMemo.BackColor = System.Drawing.SystemColors.Window
        Me.txtMemo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMemo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMemo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMemo.Location = New System.Drawing.Point(48, 384)
        Me.txtMemo.MaxLength = 0
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.ReadOnly = True
        Me.txtMemo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMemo.Size = New System.Drawing.Size(505, 20)
        Me.txtMemo.TabIndex = 71
        Me.txtMemo.TabStop = False
        '
        'cmbCustomerMsg
        '
        Me.cmbCustomerMsg.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCustomerMsg.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbCustomerMsg.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCustomerMsg.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCustomerMsg.Location = New System.Drawing.Point(104, 360)
        Me.cmbCustomerMsg.Name = "cmbCustomerMsg"
        Me.cmbCustomerMsg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbCustomerMsg.Size = New System.Drawing.Size(521, 22)
        Me.cmbCustomerMsg.TabIndex = 69
        '
        'cmbCustTaxCode
        '
        Me.cmbCustTaxCode.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCustTaxCode.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbCustTaxCode.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCustTaxCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCustTaxCode.Location = New System.Drawing.Point(456, 336)
        Me.cmbCustTaxCode.Name = "cmbCustTaxCode"
        Me.cmbCustTaxCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbCustTaxCode.Size = New System.Drawing.Size(73, 22)
        Me.cmbCustTaxCode.TabIndex = 67
        '
        'cmbItemSalesTax
        '
        Me.cmbItemSalesTax.BackColor = System.Drawing.SystemColors.Window
        Me.cmbItemSalesTax.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbItemSalesTax.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbItemSalesTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbItemSalesTax.Location = New System.Drawing.Point(88, 336)
        Me.cmbItemSalesTax.Name = "cmbItemSalesTax"
        Me.cmbItemSalesTax.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbItemSalesTax.Size = New System.Drawing.Size(217, 22)
        Me.cmbItemSalesTax.TabIndex = 66
        '
        'cmbShipMethod
        '
        Me.cmbShipMethod.BackColor = System.Drawing.SystemColors.Window
        Me.cmbShipMethod.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbShipMethod.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShipMethod.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbShipMethod.Location = New System.Drawing.Point(224, 312)
        Me.cmbShipMethod.Name = "cmbShipMethod"
        Me.cmbShipMethod.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbShipMethod.Size = New System.Drawing.Size(193, 22)
        Me.cmbShipMethod.TabIndex = 65
        '
        'cmbSalesRep
        '
        Me.cmbSalesRep.BackColor = System.Drawing.SystemColors.Window
        Me.cmbSalesRep.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbSalesRep.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSalesRep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbSalesRep.Location = New System.Drawing.Point(64, 312)
        Me.cmbSalesRep.Name = "cmbSalesRep"
        Me.cmbSalesRep.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbSalesRep.Size = New System.Drawing.Size(65, 22)
        Me.cmbSalesRep.TabIndex = 64
        '
        'txtFOB
        '
        Me.txtFOB.AcceptsReturn = True
        Me.txtFOB.BackColor = System.Drawing.SystemColors.Window
        Me.txtFOB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFOB.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFOB.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFOB.Location = New System.Drawing.Point(544, 288)
        Me.txtFOB.MaxLength = 0
        Me.txtFOB.Name = "txtFOB"
        Me.txtFOB.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFOB.Size = New System.Drawing.Size(89, 20)
        Me.txtFOB.TabIndex = 59
        '
        'txtShipDate
        '
        Me.txtShipDate.AcceptsReturn = True
        Me.txtShipDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipDate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipDate.Location = New System.Drawing.Point(424, 288)
        Me.txtShipDate.MaxLength = 0
        Me.txtShipDate.Name = "txtShipDate"
        Me.txtShipDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipDate.Size = New System.Drawing.Size(65, 20)
        Me.txtShipDate.TabIndex = 58
        '
        'txtDueDate
        '
        Me.txtDueDate.AcceptsReturn = True
        Me.txtDueDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtDueDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDueDate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDueDate.Location = New System.Drawing.Point(280, 288)
        Me.txtDueDate.MaxLength = 0
        Me.txtDueDate.Name = "txtDueDate"
        Me.txtDueDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDueDate.Size = New System.Drawing.Size(65, 20)
        Me.txtDueDate.TabIndex = 57
        '
        'txtPONumber
        '
        Me.txtPONumber.AcceptsReturn = True
        Me.txtPONumber.BackColor = System.Drawing.SystemColors.Window
        Me.txtPONumber.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPONumber.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPONumber.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPONumber.Location = New System.Drawing.Point(72, 288)
        Me.txtPONumber.MaxLength = 0
        Me.txtPONumber.Name = "txtPONumber"
        Me.txtPONumber.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPONumber.Size = New System.Drawing.Size(121, 20)
        Me.txtPONumber.TabIndex = 56
        '
        'cmbTerms
        '
        Me.cmbTerms.BackColor = System.Drawing.SystemColors.Window
        Me.cmbTerms.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbTerms.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbTerms.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbTerms.Location = New System.Drawing.Point(376, 264)
        Me.cmbTerms.Name = "cmbTerms"
        Me.cmbTerms.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbTerms.Size = New System.Drawing.Size(257, 22)
        Me.cmbTerms.TabIndex = 51
        '
        'cmbARAccount
        '
        Me.cmbARAccount.BackColor = System.Drawing.SystemColors.Window
        Me.cmbARAccount.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbARAccount.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbARAccount.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbARAccount.Location = New System.Drawing.Point(72, 264)
        Me.cmbARAccount.Name = "cmbARAccount"
        Me.cmbARAccount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbARAccount.Size = New System.Drawing.Size(265, 22)
        Me.cmbARAccount.TabIndex = 49
        '
        'chkToBePrinted
        '
        Me.chkToBePrinted.BackColor = System.Drawing.SystemColors.Control
        Me.chkToBePrinted.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkToBePrinted.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkToBePrinted.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkToBePrinted.Location = New System.Drawing.Point(480, 40)
        Me.chkToBePrinted.Name = "chkToBePrinted"
        Me.chkToBePrinted.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkToBePrinted.Size = New System.Drawing.Size(89, 17)
        Me.chkToBePrinted.TabIndex = 47
        Me.chkToBePrinted.Text = "To Be Printed"
        Me.chkToBePrinted.UseVisualStyleBackColor = False
        '
        'txtShipAddr4
        '
        Me.txtShipAddr4.AcceptsReturn = True
        Me.txtShipAddr4.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipAddr4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipAddr4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipAddr4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipAddr4.Location = New System.Drawing.Point(360, 184)
        Me.txtShipAddr4.MaxLength = 0
        Me.txtShipAddr4.Name = "txtShipAddr4"
        Me.txtShipAddr4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipAddr4.Size = New System.Drawing.Size(273, 20)
        Me.txtShipAddr4.TabIndex = 46
        '
        'txtShipAddr3
        '
        Me.txtShipAddr3.AcceptsReturn = True
        Me.txtShipAddr3.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipAddr3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipAddr3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipAddr3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipAddr3.Location = New System.Drawing.Point(360, 160)
        Me.txtShipAddr3.MaxLength = 0
        Me.txtShipAddr3.Name = "txtShipAddr3"
        Me.txtShipAddr3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipAddr3.Size = New System.Drawing.Size(273, 20)
        Me.txtShipAddr3.TabIndex = 45
        '
        'txtShipAddr2
        '
        Me.txtShipAddr2.AcceptsReturn = True
        Me.txtShipAddr2.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipAddr2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipAddr2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipAddr2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipAddr2.Location = New System.Drawing.Point(360, 136)
        Me.txtShipAddr2.MaxLength = 0
        Me.txtShipAddr2.Name = "txtShipAddr2"
        Me.txtShipAddr2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipAddr2.Size = New System.Drawing.Size(273, 20)
        Me.txtShipAddr2.TabIndex = 44
        '
        'txtShipAddr1
        '
        Me.txtShipAddr1.AcceptsReturn = True
        Me.txtShipAddr1.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipAddr1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipAddr1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipAddr1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipAddr1.Location = New System.Drawing.Point(360, 112)
        Me.txtShipAddr1.MaxLength = 0
        Me.txtShipAddr1.Name = "txtShipAddr1"
        Me.txtShipAddr1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipAddr1.Size = New System.Drawing.Size(273, 20)
        Me.txtShipAddr1.TabIndex = 43
        '
        'txtShipState
        '
        Me.txtShipState.AcceptsReturn = True
        Me.txtShipState.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipState.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipState.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipState.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipState.Location = New System.Drawing.Point(536, 208)
        Me.txtShipState.MaxLength = 0
        Me.txtShipState.Name = "txtShipState"
        Me.txtShipState.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipState.Size = New System.Drawing.Size(97, 20)
        Me.txtShipState.TabIndex = 42
        '
        'txtShipCity
        '
        Me.txtShipCity.AcceptsReturn = True
        Me.txtShipCity.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipCity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipCity.Location = New System.Drawing.Point(360, 208)
        Me.txtShipCity.MaxLength = 0
        Me.txtShipCity.Name = "txtShipCity"
        Me.txtShipCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipCity.Size = New System.Drawing.Size(137, 20)
        Me.txtShipCity.TabIndex = 41
        '
        'txtShipPostalCode
        '
        Me.txtShipPostalCode.AcceptsReturn = True
        Me.txtShipPostalCode.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipPostalCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipPostalCode.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipPostalCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipPostalCode.Location = New System.Drawing.Point(392, 232)
        Me.txtShipPostalCode.MaxLength = 0
        Me.txtShipPostalCode.Name = "txtShipPostalCode"
        Me.txtShipPostalCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipPostalCode.Size = New System.Drawing.Size(89, 20)
        Me.txtShipPostalCode.TabIndex = 40
        '
        'txtShipCountry
        '
        Me.txtShipCountry.AcceptsReturn = True
        Me.txtShipCountry.BackColor = System.Drawing.SystemColors.Window
        Me.txtShipCountry.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtShipCountry.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShipCountry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShipCountry.Location = New System.Drawing.Point(528, 232)
        Me.txtShipCountry.MaxLength = 0
        Me.txtShipCountry.Name = "txtShipCountry"
        Me.txtShipCountry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtShipCountry.Size = New System.Drawing.Size(105, 20)
        Me.txtShipCountry.TabIndex = 39
        '
        'txtBillCountry
        '
        Me.txtBillCountry.AcceptsReturn = True
        Me.txtBillCountry.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillCountry.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillCountry.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillCountry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillCountry.Location = New System.Drawing.Point(208, 232)
        Me.txtBillCountry.MaxLength = 0
        Me.txtBillCountry.Name = "txtBillCountry"
        Me.txtBillCountry.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillCountry.Size = New System.Drawing.Size(105, 20)
        Me.txtBillCountry.TabIndex = 30
        '
        'txtBillPostalCode
        '
        Me.txtBillPostalCode.AcceptsReturn = True
        Me.txtBillPostalCode.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillPostalCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillPostalCode.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillPostalCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillPostalCode.Location = New System.Drawing.Point(72, 232)
        Me.txtBillPostalCode.MaxLength = 0
        Me.txtBillPostalCode.Name = "txtBillPostalCode"
        Me.txtBillPostalCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillPostalCode.Size = New System.Drawing.Size(89, 20)
        Me.txtBillPostalCode.TabIndex = 28
        '
        'txtBillState
        '
        Me.txtBillState.AcceptsReturn = True
        Me.txtBillState.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillState.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillState.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillState.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillState.Location = New System.Drawing.Point(216, 208)
        Me.txtBillState.MaxLength = 0
        Me.txtBillState.Name = "txtBillState"
        Me.txtBillState.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillState.Size = New System.Drawing.Size(97, 20)
        Me.txtBillState.TabIndex = 26
        '
        'txtBillCity
        '
        Me.txtBillCity.AcceptsReturn = True
        Me.txtBillCity.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillCity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillCity.Location = New System.Drawing.Point(40, 208)
        Me.txtBillCity.MaxLength = 0
        Me.txtBillCity.Name = "txtBillCity"
        Me.txtBillCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillCity.Size = New System.Drawing.Size(137, 20)
        Me.txtBillCity.TabIndex = 24
        '
        'txtBillAddr4
        '
        Me.txtBillAddr4.AcceptsReturn = True
        Me.txtBillAddr4.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillAddr4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillAddr4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillAddr4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillAddr4.Location = New System.Drawing.Point(40, 184)
        Me.txtBillAddr4.MaxLength = 0
        Me.txtBillAddr4.Name = "txtBillAddr4"
        Me.txtBillAddr4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillAddr4.Size = New System.Drawing.Size(273, 20)
        Me.txtBillAddr4.TabIndex = 23
        '
        'txtBillAddr3
        '
        Me.txtBillAddr3.AcceptsReturn = True
        Me.txtBillAddr3.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillAddr3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillAddr3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillAddr3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillAddr3.Location = New System.Drawing.Point(40, 160)
        Me.txtBillAddr3.MaxLength = 0
        Me.txtBillAddr3.Name = "txtBillAddr3"
        Me.txtBillAddr3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillAddr3.Size = New System.Drawing.Size(273, 20)
        Me.txtBillAddr3.TabIndex = 22
        '
        'txtBillAddr2
        '
        Me.txtBillAddr2.AcceptsReturn = True
        Me.txtBillAddr2.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillAddr2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillAddr2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillAddr2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillAddr2.Location = New System.Drawing.Point(40, 136)
        Me.txtBillAddr2.MaxLength = 0
        Me.txtBillAddr2.Name = "txtBillAddr2"
        Me.txtBillAddr2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillAddr2.Size = New System.Drawing.Size(273, 20)
        Me.txtBillAddr2.TabIndex = 21
        '
        'txtBillAddr1
        '
        Me.txtBillAddr1.AcceptsReturn = True
        Me.txtBillAddr1.BackColor = System.Drawing.SystemColors.Window
        Me.txtBillAddr1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBillAddr1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillAddr1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBillAddr1.Location = New System.Drawing.Point(40, 112)
        Me.txtBillAddr1.MaxLength = 0
        Me.txtBillAddr1.Name = "txtBillAddr1"
        Me.txtBillAddr1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBillAddr1.Size = New System.Drawing.Size(273, 20)
        Me.txtBillAddr1.TabIndex = 20
        '
        'cmbClass
        '
        Me.cmbClass.BackColor = System.Drawing.SystemColors.Window
        Me.cmbClass.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbClass.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbClass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbClass.Location = New System.Drawing.Point(424, 64)
        Me.cmbClass.Name = "cmbClass"
        Me.cmbClass.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbClass.Size = New System.Drawing.Size(177, 22)
        Me.cmbClass.TabIndex = 12
        '
        'chkPending
        '
        Me.chkPending.BackColor = System.Drawing.SystemColors.Control
        Me.chkPending.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkPending.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPending.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkPending.Location = New System.Drawing.Point(392, 40)
        Me.chkPending.Name = "chkPending"
        Me.chkPending.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkPending.Size = New System.Drawing.Size(65, 17)
        Me.chkPending.TabIndex = 10
        Me.chkPending.Text = "Pending"
        Me.chkPending.UseVisualStyleBackColor = False
        '
        'txtTxnDate
        '
        Me.txtTxnDate.AcceptsReturn = True
        Me.txtTxnDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtTxnDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTxnDate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTxnDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTxnDate.Location = New System.Drawing.Point(256, 40)
        Me.txtTxnDate.MaxLength = 0
        Me.txtTxnDate.Name = "txtTxnDate"
        Me.txtTxnDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTxnDate.Size = New System.Drawing.Size(89, 20)
        Me.txtTxnDate.TabIndex = 9
        '
        'txtRefNumber
        '
        Me.txtRefNumber.AcceptsReturn = True
        Me.txtRefNumber.BackColor = System.Drawing.SystemColors.Window
        Me.txtRefNumber.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRefNumber.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRefNumber.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRefNumber.Location = New System.Drawing.Point(64, 40)
        Me.txtRefNumber.MaxLength = 0
        Me.txtRefNumber.Name = "txtRefNumber"
        Me.txtRefNumber.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRefNumber.Size = New System.Drawing.Size(129, 20)
        Me.txtRefNumber.TabIndex = 7
        '
        'cmbCustomer
        '
        Me.cmbCustomer.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCustomer.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbCustomer.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCustomer.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCustomer.Location = New System.Drawing.Point(64, 64)
        Me.cmbCustomer.Name = "cmbCustomer"
        Me.cmbCustomer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbCustomer.Size = New System.Drawing.Size(305, 22)
        Me.cmbCustomer.TabIndex = 5
        '
        'txtEditSequence
        '
        Me.txtEditSequence.AcceptsReturn = True
        Me.txtEditSequence.BackColor = System.Drawing.SystemColors.Window
        Me.txtEditSequence.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtEditSequence.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEditSequence.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtEditSequence.Location = New System.Drawing.Point(328, 8)
        Me.txtEditSequence.MaxLength = 0
        Me.txtEditSequence.Name = "txtEditSequence"
        Me.txtEditSequence.ReadOnly = True
        Me.txtEditSequence.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtEditSequence.Size = New System.Drawing.Size(193, 20)
        Me.txtEditSequence.TabIndex = 3
        Me.txtEditSequence.TabStop = False
        '
        'txtTxnID
        '
        Me.txtTxnID.AcceptsReturn = True
        Me.txtTxnID.BackColor = System.Drawing.SystemColors.Window
        Me.txtTxnID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTxnID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTxnID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTxnID.Location = New System.Drawing.Point(48, 8)
        Me.txtTxnID.MaxLength = 0
        Me.txtTxnID.Name = "txtTxnID"
        Me.txtTxnID.ReadOnly = True
        Me.txtTxnID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTxnID.Size = New System.Drawing.Size(177, 20)
        Me.txtTxnID.TabIndex = 1
        Me.txtTxnID.TabStop = False
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.SystemColors.Control
        Me.Label31.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label31.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label31.Location = New System.Drawing.Point(565, 416)
        Me.Label31.Name = "Label31"
        Me.Label31.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label31.Size = New System.Drawing.Size(55, 17)
        Me.Label31.TabIndex = 176
        Me.Label31.Text = "Amount"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.SystemColors.Control
        Me.Label30.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label30.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label30.Location = New System.Drawing.Point(528, 416)
        Me.Label30.Name = "Label30"
        Me.Label30.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label30.Size = New System.Drawing.Size(33, 17)
        Me.Label30.TabIndex = 175
        Me.Label30.Text = "Rate"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.SystemColors.Control
        Me.Label29.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label29.Location = New System.Drawing.Point(280, 416)
        Me.Label29.Name = "Label29"
        Me.Label29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label29.Size = New System.Drawing.Size(75, 17)
        Me.Label29.TabIndex = 174
        Me.Label29.Text = "Description"
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.Control
        Me.Label28.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label28.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label28.Location = New System.Drawing.Point(136, 416)
        Me.Label28.Name = "Label28"
        Me.Label28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label28.Size = New System.Drawing.Size(57, 17)
        Me.Label28.TabIndex = 173
        Me.Label28.Text = "Item"
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.SystemColors.Control
        Me.Label27.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label27.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label27.Location = New System.Drawing.Point(104, 416)
        Me.Label27.Name = "Label27"
        Me.Label27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label27.Size = New System.Drawing.Size(25, 17)
        Me.Label27.TabIndex = 172
        Me.Label27.Text = "Qty"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.SystemColors.Control
        Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label26.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label26.Location = New System.Drawing.Point(8, 416)
        Me.Label26.Name = "Label26"
        Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label26.Size = New System.Drawing.Size(73, 17)
        Me.Label26.TabIndex = 171
        Me.Label26.Text = "TxnLineID"
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.SystemColors.Control
        Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label25.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label25.Location = New System.Drawing.Point(8, 384)
        Me.Label25.Name = "Label25"
        Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label25.Size = New System.Drawing.Size(39, 17)
        Me.Label25.TabIndex = 70
        Me.Label25.Text = "Memo"
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.SystemColors.Control
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(8, 360)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(97, 23)
        Me.Label24.TabIndex = 68
        Me.Label24.Text = "Customer Message"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.SystemColors.Control
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(320, 336)
        Me.Label23.Name = "Label23"
        Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label23.Size = New System.Drawing.Size(142, 17)
        Me.Label23.TabIndex = 63
        Me.Label23.Text = "Customer Sales Tax Code"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.SystemColors.Control
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(8, 336)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(73, 23)
        Me.Label22.TabIndex = 62
        Me.Label22.Text = "Item Sales Tax"
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.SystemColors.Control
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(152, 312)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(65, 17)
        Me.Label21.TabIndex = 61
        Me.Label21.Text = "Ship Method"
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.Control
        Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label20.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label20.Location = New System.Drawing.Point(8, 312)
        Me.Label20.Name = "Label20"
        Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label20.Size = New System.Drawing.Size(57, 17)
        Me.Label20.TabIndex = 60
        Me.Label20.Text = "Sales Rep"
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.Control
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(512, 288)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(25, 23)
        Me.Label19.TabIndex = 55
        Me.Label19.Text = "FOB"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Control
        Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label18.Location = New System.Drawing.Point(368, 288)
        Me.Label18.Name = "Label18"
        Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label18.Size = New System.Drawing.Size(49, 23)
        Me.Label18.TabIndex = 54
        Me.Label18.Text = "Ship Date"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.Control
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label17.Location = New System.Drawing.Point(224, 288)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(49, 23)
        Me.Label17.TabIndex = 53
        Me.Label17.Text = "Due Date"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(8, 288)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(57, 23)
        Me.Label16.TabIndex = 52
        Me.Label16.Text = "PO Number"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(344, 264)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(33, 17)
        Me.Label15.TabIndex = 50
        Me.Label15.Text = "Terms"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(8, 264)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(65, 17)
        Me.Label14.TabIndex = 48
        Me.Label14.Text = "AR Account"
        '
        '_Label13_1
        '
        Me._Label13_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label13_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label13_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label13_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.SetIndex(Me._Label13_1, CType(1, Short))
        Me._Label13_1.Location = New System.Drawing.Point(488, 232)
        Me._Label13_1.Name = "_Label13_1"
        Me._Label13_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label13_1.Size = New System.Drawing.Size(41, 25)
        Me._Label13_1.TabIndex = 38
        Me._Label13_1.Text = "Country"
        '
        '_Label12_1
        '
        Me._Label12_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label12_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label12_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label12_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.SetIndex(Me._Label12_1, CType(1, Short))
        Me._Label12_1.Location = New System.Drawing.Point(328, 232)
        Me._Label12_1.Name = "_Label12_1"
        Me._Label12_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label12_1.Size = New System.Drawing.Size(57, 25)
        Me._Label12_1.TabIndex = 37
        Me._Label12_1.Text = "Postal Code"
        '
        '_Label11_1
        '
        Me._Label11_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label11_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label11_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label11_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.SetIndex(Me._Label11_1, CType(1, Short))
        Me._Label11_1.Location = New System.Drawing.Point(504, 208)
        Me._Label11_1.Name = "_Label11_1"
        Me._Label11_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label11_1.Size = New System.Drawing.Size(33, 17)
        Me._Label11_1.TabIndex = 36
        Me._Label11_1.Text = "State"
        '
        '_Label10_1
        '
        Me._Label10_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label10_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label10_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label10_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.SetIndex(Me._Label10_1, CType(1, Short))
        Me._Label10_1.Location = New System.Drawing.Point(328, 208)
        Me._Label10_1.Name = "_Label10_1"
        Me._Label10_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label10_1.Size = New System.Drawing.Size(25, 17)
        Me._Label10_1.TabIndex = 35
        Me._Label10_1.Text = "City"
        '
        '_Label9_7
        '
        Me._Label9_7.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_7, CType(7, Short))
        Me._Label9_7.Location = New System.Drawing.Point(328, 184)
        Me._Label9_7.Name = "_Label9_7"
        Me._Label9_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_7.Size = New System.Drawing.Size(33, 17)
        Me._Label9_7.TabIndex = 34
        Me._Label9_7.Text = "Addr4"
        '
        '_Label9_6
        '
        Me._Label9_6.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_6, CType(6, Short))
        Me._Label9_6.Location = New System.Drawing.Point(328, 160)
        Me._Label9_6.Name = "_Label9_6"
        Me._Label9_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_6.Size = New System.Drawing.Size(33, 17)
        Me._Label9_6.TabIndex = 33
        Me._Label9_6.Text = "Addr3"
        '
        '_Label9_5
        '
        Me._Label9_5.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_5, CType(5, Short))
        Me._Label9_5.Location = New System.Drawing.Point(328, 136)
        Me._Label9_5.Name = "_Label9_5"
        Me._Label9_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_5.Size = New System.Drawing.Size(33, 17)
        Me._Label9_5.TabIndex = 32
        Me._Label9_5.Text = "Addr2"
        '
        '_Label9_4
        '
        Me._Label9_4.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_4, CType(4, Short))
        Me._Label9_4.Location = New System.Drawing.Point(328, 112)
        Me._Label9_4.Name = "_Label9_4"
        Me._Label9_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_4.Size = New System.Drawing.Size(33, 17)
        Me._Label9_4.TabIndex = 31
        Me._Label9_4.Text = "Addr1"
        '
        '_Label13_0
        '
        Me._Label13_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label13_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label13_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label13_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.SetIndex(Me._Label13_0, CType(0, Short))
        Me._Label13_0.Location = New System.Drawing.Point(168, 232)
        Me._Label13_0.Name = "_Label13_0"
        Me._Label13_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label13_0.Size = New System.Drawing.Size(41, 25)
        Me._Label13_0.TabIndex = 29
        Me._Label13_0.Text = "Country"
        '
        '_Label12_0
        '
        Me._Label12_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label12_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label12_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label12_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.SetIndex(Me._Label12_0, CType(0, Short))
        Me._Label12_0.Location = New System.Drawing.Point(8, 233)
        Me._Label12_0.Name = "_Label12_0"
        Me._Label12_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label12_0.Size = New System.Drawing.Size(57, 25)
        Me._Label12_0.TabIndex = 27
        Me._Label12_0.Text = "Postal Code"
        '
        '_Label11_0
        '
        Me._Label11_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label11_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label11_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label11_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.SetIndex(Me._Label11_0, CType(0, Short))
        Me._Label11_0.Location = New System.Drawing.Point(184, 208)
        Me._Label11_0.Name = "_Label11_0"
        Me._Label11_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label11_0.Size = New System.Drawing.Size(33, 17)
        Me._Label11_0.TabIndex = 25
        Me._Label11_0.Text = "State"
        '
        '_Label10_0
        '
        Me._Label10_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label10_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label10_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label10_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.SetIndex(Me._Label10_0, CType(0, Short))
        Me._Label10_0.Location = New System.Drawing.Point(8, 208)
        Me._Label10_0.Name = "_Label10_0"
        Me._Label10_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label10_0.Size = New System.Drawing.Size(25, 17)
        Me._Label10_0.TabIndex = 19
        Me._Label10_0.Text = "City"
        '
        '_Label9_3
        '
        Me._Label9_3.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_3, CType(3, Short))
        Me._Label9_3.Location = New System.Drawing.Point(8, 184)
        Me._Label9_3.Name = "_Label9_3"
        Me._Label9_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_3.Size = New System.Drawing.Size(33, 17)
        Me._Label9_3.TabIndex = 18
        Me._Label9_3.Text = "Addr4"
        '
        '_Label9_2
        '
        Me._Label9_2.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_2, CType(2, Short))
        Me._Label9_2.Location = New System.Drawing.Point(8, 160)
        Me._Label9_2.Name = "_Label9_2"
        Me._Label9_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_2.Size = New System.Drawing.Size(33, 17)
        Me._Label9_2.TabIndex = 17
        Me._Label9_2.Text = "Addr3"
        '
        '_Label9_1
        '
        Me._Label9_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_1, CType(1, Short))
        Me._Label9_1.Location = New System.Drawing.Point(8, 136)
        Me._Label9_1.Name = "_Label9_1"
        Me._Label9_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_1.Size = New System.Drawing.Size(33, 17)
        Me._Label9_1.TabIndex = 16
        Me._Label9_1.Text = "Addr2"
        '
        '_Label9_0
        '
        Me._Label9_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label9_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label9_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label9_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.SetIndex(Me._Label9_0, CType(0, Short))
        Me._Label9_0.Location = New System.Drawing.Point(8, 112)
        Me._Label9_0.Name = "_Label9_0"
        Me._Label9_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label9_0.Size = New System.Drawing.Size(33, 17)
        Me._Label9_0.TabIndex = 15
        Me._Label9_0.Text = "Addr1"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(328, 88)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(75, 17)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Ship Address"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(8, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(67, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Bill Address"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(392, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(33, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Class"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(216, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(33, 17)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Date"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(8, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(49, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Invoice #"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(8, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(49, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Customer"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(248, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(83, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Edit Sequence"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(33, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "TxnID"
        '
        'txtAmount
        '
        '
        'txtDesc
        '
        '
        'txtItemFullName
        '
        '
        'txtItemLineNumber
        '
        '
        'txtQuantity
        '
        '
        'txtRate
        '
        '
        'txtSpace1
        '
        '
        'frmInvoiceModify
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(642, 669)
        Me.Controls.Add(Me.chkShow)
        Me.Controls.Add(Me._txtSpace1_29)
        Me.Controls.Add(Me._txtSpace1_28)
        Me.Controls.Add(Me._txtSpace1_27)
        Me.Controls.Add(Me._txtSpace1_26)
        Me.Controls.Add(Me._txtSpace1_25)
        Me.Controls.Add(Me._txtSpace1_24)
        Me.Controls.Add(Me._txtSpace1_23)
        Me.Controls.Add(Me._txtSpace1_22)
        Me.Controls.Add(Me._txtSpace1_21)
        Me.Controls.Add(Me._txtSpace1_20)
        Me.Controls.Add(Me._txtSpace1_19)
        Me.Controls.Add(Me._txtSpace1_18)
        Me.Controls.Add(Me._txtSpace1_17)
        Me.Controls.Add(Me._txtSpace1_16)
        Me.Controls.Add(Me._txtSpace1_15)
        Me.Controls.Add(Me._txtSpace1_14)
        Me.Controls.Add(Me._txtSpace1_13)
        Me.Controls.Add(Me._txtSpace1_12)
        Me.Controls.Add(Me._txtSpace1_11)
        Me.Controls.Add(Me._txtSpace1_10)
        Me.Controls.Add(Me._txtSpace1_9)
        Me.Controls.Add(Me._txtSpace1_8)
        Me.Controls.Add(Me._txtSpace1_7)
        Me.Controls.Add(Me._txtSpace1_6)
        Me.Controls.Add(Me._txtSpace1_5)
        Me.Controls.Add(Me._txtSpace1_4)
        Me.Controls.Add(Me._txtSpace1_3)
        Me.Controls.Add(Me._txtSpace1_2)
        Me.Controls.Add(Me._txtSpace1_1)
        Me.Controls.Add(Me._txtSpace1_0)
        Me.Controls.Add(Me._txtAmount_9)
        Me.Controls.Add(Me._txtRate_9)
        Me.Controls.Add(Me._txtDesc_9)
        Me.Controls.Add(Me._txtItemFullName_9)
        Me.Controls.Add(Me._txtQuantity_9)
        Me.Controls.Add(Me._txtItemLineNumber_9)
        Me.Controls.Add(Me._txtAmount_8)
        Me.Controls.Add(Me._txtRate_8)
        Me.Controls.Add(Me._txtDesc_8)
        Me.Controls.Add(Me._txtItemFullName_8)
        Me.Controls.Add(Me._txtQuantity_8)
        Me.Controls.Add(Me._txtItemLineNumber_8)
        Me.Controls.Add(Me._txtAmount_7)
        Me.Controls.Add(Me._txtRate_7)
        Me.Controls.Add(Me._txtDesc_7)
        Me.Controls.Add(Me._txtItemFullName_7)
        Me.Controls.Add(Me._txtQuantity_7)
        Me.Controls.Add(Me._txtItemLineNumber_7)
        Me.Controls.Add(Me._txtAmount_6)
        Me.Controls.Add(Me._txtRate_6)
        Me.Controls.Add(Me._txtDesc_6)
        Me.Controls.Add(Me._txtItemFullName_6)
        Me.Controls.Add(Me._txtQuantity_6)
        Me.Controls.Add(Me._txtItemLineNumber_6)
        Me.Controls.Add(Me._txtAmount_5)
        Me.Controls.Add(Me._txtRate_5)
        Me.Controls.Add(Me._txtDesc_5)
        Me.Controls.Add(Me._txtItemFullName_5)
        Me.Controls.Add(Me._txtQuantity_5)
        Me.Controls.Add(Me._txtItemLineNumber_5)
        Me.Controls.Add(Me._txtAmount_4)
        Me.Controls.Add(Me._txtRate_4)
        Me.Controls.Add(Me._txtDesc_4)
        Me.Controls.Add(Me._txtItemFullName_4)
        Me.Controls.Add(Me._txtQuantity_4)
        Me.Controls.Add(Me._txtItemLineNumber_4)
        Me.Controls.Add(Me._txtAmount_3)
        Me.Controls.Add(Me._txtRate_3)
        Me.Controls.Add(Me._txtDesc_3)
        Me.Controls.Add(Me._txtItemFullName_3)
        Me.Controls.Add(Me._txtQuantity_3)
        Me.Controls.Add(Me._txtItemLineNumber_3)
        Me.Controls.Add(Me._txtAmount_2)
        Me.Controls.Add(Me._txtRate_2)
        Me.Controls.Add(Me._txtDesc_2)
        Me.Controls.Add(Me._txtItemFullName_2)
        Me.Controls.Add(Me._txtQuantity_2)
        Me.Controls.Add(Me._txtItemLineNumber_2)
        Me.Controls.Add(Me._txtAmount_1)
        Me.Controls.Add(Me._txtRate_1)
        Me.Controls.Add(Me._txtDesc_1)
        Me.Controls.Add(Me._txtItemFullName_1)
        Me.Controls.Add(Me._txtQuantity_1)
        Me.Controls.Add(Me._txtItemLineNumber_1)
        Me.Controls.Add(Me.cmdFinish)
        Me.Controls.Add(Me.cmdDoModify)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdDeleteUndelete)
        Me.Controls.Add(Me.cmdAddLineBefore)
        Me.Controls.Add(Me.cmdAddLineAfter)
        Me.Controls.Add(Me.cmdEditLine)
        Me.Controls.Add(Me.vscInvoiceLineScroll)
        Me.Controls.Add(Me._txtAmount_0)
        Me.Controls.Add(Me._txtRate_0)
        Me.Controls.Add(Me._txtDesc_0)
        Me.Controls.Add(Me._txtItemFullName_0)
        Me.Controls.Add(Me._txtQuantity_0)
        Me.Controls.Add(Me._txtItemLineNumber_0)
        Me.Controls.Add(Me.cmdEditMemo)
        Me.Controls.Add(Me.txtMemo)
        Me.Controls.Add(Me.cmbCustomerMsg)
        Me.Controls.Add(Me.cmbCustTaxCode)
        Me.Controls.Add(Me.cmbItemSalesTax)
        Me.Controls.Add(Me.cmbShipMethod)
        Me.Controls.Add(Me.cmbSalesRep)
        Me.Controls.Add(Me.txtFOB)
        Me.Controls.Add(Me.txtShipDate)
        Me.Controls.Add(Me.txtDueDate)
        Me.Controls.Add(Me.txtPONumber)
        Me.Controls.Add(Me.cmbTerms)
        Me.Controls.Add(Me.cmbARAccount)
        Me.Controls.Add(Me.chkToBePrinted)
        Me.Controls.Add(Me.txtShipAddr4)
        Me.Controls.Add(Me.txtShipAddr3)
        Me.Controls.Add(Me.txtShipAddr2)
        Me.Controls.Add(Me.txtShipAddr1)
        Me.Controls.Add(Me.txtShipState)
        Me.Controls.Add(Me.txtShipCity)
        Me.Controls.Add(Me.txtShipPostalCode)
        Me.Controls.Add(Me.txtShipCountry)
        Me.Controls.Add(Me.txtBillCountry)
        Me.Controls.Add(Me.txtBillPostalCode)
        Me.Controls.Add(Me.txtBillState)
        Me.Controls.Add(Me.txtBillCity)
        Me.Controls.Add(Me.txtBillAddr4)
        Me.Controls.Add(Me.txtBillAddr3)
        Me.Controls.Add(Me.txtBillAddr2)
        Me.Controls.Add(Me.txtBillAddr1)
        Me.Controls.Add(Me.cmbClass)
        Me.Controls.Add(Me.chkPending)
        Me.Controls.Add(Me.txtTxnDate)
        Me.Controls.Add(Me.txtRefNumber)
        Me.Controls.Add(Me.cmbCustomer)
        Me.Controls.Add(Me.txtEditSequence)
        Me.Controls.Add(Me.txtTxnID)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me._Label13_1)
        Me.Controls.Add(Me._Label12_1)
        Me.Controls.Add(Me._Label11_1)
        Me.Controls.Add(Me._Label10_1)
        Me.Controls.Add(Me._Label9_7)
        Me.Controls.Add(Me._Label9_6)
        Me.Controls.Add(Me._Label9_5)
        Me.Controls.Add(Me._Label9_4)
        Me.Controls.Add(Me._Label13_0)
        Me.Controls.Add(Me._Label12_0)
        Me.Controls.Add(Me._Label11_0)
        Me.Controls.Add(Me._Label10_0)
        Me.Controls.Add(Me._Label9_3)
        Me.Controls.Add(Me._Label9_2)
        Me.Controls.Add(Me._Label9_1)
        Me.Controls.Add(Me._Label9_0)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(213, 53)
        Me.Name = "frmInvoiceModify"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Modify Invoice"
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDesc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItemFullName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItemLineNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
End Class