Option Strict Off
Option Explicit On
Friend Class frmPatience
	Inherits System.Windows.Forms.Form
	'----------------------------------------------------------
	' Copyright � 2003-2013 Intuit Inc. All rights reserved.
	' Use is subject to the terms specified at:
	'      http://developer.intuit.com/rdmgr/?ID=100
	'
	'----------------------------------------------------------
End Class