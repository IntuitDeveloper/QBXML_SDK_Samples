
This sample is a simple VB.NET desktop application that is used to Sync Customer list by using QBFC2 COM dll. 

Running the sample
------------------

Before running PurchaseOrderModify.exe, make sure that .NET runtime is installed on the machine, 
and QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open PurchaseOrderModify.sln in Microsoft Visual Studio .NET and build the solution.
QBFC2Assembly.dll was generated with 'tlbimp' .NET Type Library to Assembly Convertor.


The PurchaseOrderModify sample program allows users who are running QB 2003 R7P to close purchase orders or purchase order lines in a company file.  QuickBooks must be running and if this is the first time the sample will be run against a company file the Admin user must have the company file open.

When one runs the PurchaseOrderModify sample, one choose at the onset to use either QBXMLRP or QBFC to be used by the sample application.  The sample continues to use that method throughout the rest of the current run of the sample program.

The next form the sample program user is presented lists up to 30 open purchase orders in the company file.  The sample program uses the GeneralDetailReportQuery to retrieve columns from the OpenPOs report.  It uses the new SDK 2.1 feature allowing the return of the TxnID column in a SDK report query response.  It displays information about the open purchase orders  and allows the user to choose a purchase order to modify.

Once a user has selected a purchase order by clicking on it's information and then clicks the View Purchase Order Details button, a screen listing the purchase order information and lines is displayed.  The user may then choose to close the entire purchase order or close an individual line of the purchase order.  They may also simulate the receipt of items against a purchase order or an individual purchase order line.

The SDK is unable to link bills created through the SDK to existing purchase orders.  This sample uses a method we suggest developers use in the absence of the ability to create the purchase order to bill links.  One cannot modify the Recieved Quantity value for purchase order lines because this is done by creating a link to a bill or item receipt through the QuickBooks UI.  Using the SDK a appliction must instead reduce the quantity ordered by the number they wish to have received against the purchase order line and create a bill for those items.  When the sample application does this it uses the quantity still on order (ordered minus quantity recieved) and modifies the purchase order line or lines to reflect the quantity recieved already through the UI.  
It also adds information to the memo field of the bill is created for the item or items and the purchase order memo field indicating what it has done.
