<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmPurchaseOrderDetail
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdExit As System.Windows.Forms.Button
	Public WithEvents cmdReturn As System.Windows.Forms.Button
	Public WithEvents cmdCloseLine As System.Windows.Forms.Button
	Public WithEvents cmdCloseAll As System.Windows.Forms.Button
	Public WithEvents cmdReceiveOne As System.Windows.Forms.Button
	Public WithEvents cmdReceiveAll As System.Windows.Forms.Button
	Public WithEvents _txtClosed_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtClosed_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtReceived_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtAmount_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace4_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtRate_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace3_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtQuantity_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtDescription_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtItem_0 As System.Windows.Forms.TextBox
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents vscPOLineScroll As System.Windows.Forms.VScrollBar
	Public WithEvents txtVendor As System.Windows.Forms.TextBox
	Public WithEvents txtRefNumber As System.Windows.Forms.TextBox
	Public WithEvents txtTxnDate As System.Windows.Forms.TextBox
	Public WithEvents txtTxnID As System.Windows.Forms.TextBox
	Public WithEvents txtEditSequence As System.Windows.Forms.TextBox
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents txtAmount As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtClosed As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtDescription As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtItem As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtQuantity As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtRate As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtReceived As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace1 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace2 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace3 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace4 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPurchaseOrderDetail))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.cmdExit = New System.Windows.Forms.Button
		Me.cmdReturn = New System.Windows.Forms.Button
		Me.cmdCloseLine = New System.Windows.Forms.Button
		Me.cmdCloseAll = New System.Windows.Forms.Button
		Me.cmdReceiveOne = New System.Windows.Forms.Button
		Me.cmdReceiveAll = New System.Windows.Forms.Button
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me._txtClosed_9 = New System.Windows.Forms.TextBox
		Me._txtReceived_9 = New System.Windows.Forms.TextBox
		Me._txtAmount_9 = New System.Windows.Forms.TextBox
		Me._txtSpace4_9 = New System.Windows.Forms.TextBox
		Me._txtRate_9 = New System.Windows.Forms.TextBox
		Me._txtSpace3_9 = New System.Windows.Forms.TextBox
		Me._txtQuantity_9 = New System.Windows.Forms.TextBox
		Me._txtSpace2_9 = New System.Windows.Forms.TextBox
		Me._txtSpace1_9 = New System.Windows.Forms.TextBox
		Me._txtDescription_9 = New System.Windows.Forms.TextBox
		Me._txtItem_9 = New System.Windows.Forms.TextBox
		Me._txtClosed_8 = New System.Windows.Forms.TextBox
		Me._txtReceived_8 = New System.Windows.Forms.TextBox
		Me._txtAmount_8 = New System.Windows.Forms.TextBox
		Me._txtSpace4_8 = New System.Windows.Forms.TextBox
		Me._txtRate_8 = New System.Windows.Forms.TextBox
		Me._txtSpace3_8 = New System.Windows.Forms.TextBox
		Me._txtQuantity_8 = New System.Windows.Forms.TextBox
		Me._txtSpace2_8 = New System.Windows.Forms.TextBox
		Me._txtSpace1_8 = New System.Windows.Forms.TextBox
		Me._txtDescription_8 = New System.Windows.Forms.TextBox
		Me._txtItem_8 = New System.Windows.Forms.TextBox
		Me._txtClosed_7 = New System.Windows.Forms.TextBox
		Me._txtReceived_7 = New System.Windows.Forms.TextBox
		Me._txtAmount_7 = New System.Windows.Forms.TextBox
		Me._txtSpace4_7 = New System.Windows.Forms.TextBox
		Me._txtRate_7 = New System.Windows.Forms.TextBox
		Me._txtSpace3_7 = New System.Windows.Forms.TextBox
		Me._txtQuantity_7 = New System.Windows.Forms.TextBox
		Me._txtSpace2_7 = New System.Windows.Forms.TextBox
		Me._txtSpace1_7 = New System.Windows.Forms.TextBox
		Me._txtDescription_7 = New System.Windows.Forms.TextBox
		Me._txtItem_7 = New System.Windows.Forms.TextBox
		Me._txtClosed_6 = New System.Windows.Forms.TextBox
		Me._txtReceived_6 = New System.Windows.Forms.TextBox
		Me._txtAmount_6 = New System.Windows.Forms.TextBox
		Me._txtSpace4_6 = New System.Windows.Forms.TextBox
		Me._txtRate_6 = New System.Windows.Forms.TextBox
		Me._txtSpace3_6 = New System.Windows.Forms.TextBox
		Me._txtQuantity_6 = New System.Windows.Forms.TextBox
		Me._txtSpace2_6 = New System.Windows.Forms.TextBox
		Me._txtSpace1_6 = New System.Windows.Forms.TextBox
		Me._txtDescription_6 = New System.Windows.Forms.TextBox
		Me._txtItem_6 = New System.Windows.Forms.TextBox
		Me._txtClosed_5 = New System.Windows.Forms.TextBox
		Me._txtReceived_5 = New System.Windows.Forms.TextBox
		Me._txtAmount_5 = New System.Windows.Forms.TextBox
		Me._txtSpace4_5 = New System.Windows.Forms.TextBox
		Me._txtRate_5 = New System.Windows.Forms.TextBox
		Me._txtSpace3_5 = New System.Windows.Forms.TextBox
		Me._txtQuantity_5 = New System.Windows.Forms.TextBox
		Me._txtSpace2_5 = New System.Windows.Forms.TextBox
		Me._txtSpace1_5 = New System.Windows.Forms.TextBox
		Me._txtDescription_5 = New System.Windows.Forms.TextBox
		Me._txtItem_5 = New System.Windows.Forms.TextBox
		Me._txtClosed_4 = New System.Windows.Forms.TextBox
		Me._txtReceived_4 = New System.Windows.Forms.TextBox
		Me._txtAmount_4 = New System.Windows.Forms.TextBox
		Me._txtSpace4_4 = New System.Windows.Forms.TextBox
		Me._txtRate_4 = New System.Windows.Forms.TextBox
		Me._txtSpace3_4 = New System.Windows.Forms.TextBox
		Me._txtQuantity_4 = New System.Windows.Forms.TextBox
		Me._txtSpace2_4 = New System.Windows.Forms.TextBox
		Me._txtSpace1_4 = New System.Windows.Forms.TextBox
		Me._txtDescription_4 = New System.Windows.Forms.TextBox
		Me._txtItem_4 = New System.Windows.Forms.TextBox
		Me._txtClosed_3 = New System.Windows.Forms.TextBox
		Me._txtReceived_3 = New System.Windows.Forms.TextBox
		Me._txtAmount_3 = New System.Windows.Forms.TextBox
		Me._txtSpace4_3 = New System.Windows.Forms.TextBox
		Me._txtRate_3 = New System.Windows.Forms.TextBox
		Me._txtSpace3_3 = New System.Windows.Forms.TextBox
		Me._txtQuantity_3 = New System.Windows.Forms.TextBox
		Me._txtSpace2_3 = New System.Windows.Forms.TextBox
		Me._txtSpace1_3 = New System.Windows.Forms.TextBox
		Me._txtDescription_3 = New System.Windows.Forms.TextBox
		Me._txtItem_3 = New System.Windows.Forms.TextBox
		Me._txtClosed_2 = New System.Windows.Forms.TextBox
		Me._txtReceived_2 = New System.Windows.Forms.TextBox
		Me._txtAmount_2 = New System.Windows.Forms.TextBox
		Me._txtSpace4_2 = New System.Windows.Forms.TextBox
		Me._txtRate_2 = New System.Windows.Forms.TextBox
		Me._txtSpace3_2 = New System.Windows.Forms.TextBox
		Me._txtQuantity_2 = New System.Windows.Forms.TextBox
		Me._txtSpace2_2 = New System.Windows.Forms.TextBox
		Me._txtSpace1_2 = New System.Windows.Forms.TextBox
		Me._txtDescription_2 = New System.Windows.Forms.TextBox
		Me._txtItem_2 = New System.Windows.Forms.TextBox
		Me._txtClosed_1 = New System.Windows.Forms.TextBox
		Me._txtReceived_1 = New System.Windows.Forms.TextBox
		Me._txtAmount_1 = New System.Windows.Forms.TextBox
		Me._txtSpace4_1 = New System.Windows.Forms.TextBox
		Me._txtRate_1 = New System.Windows.Forms.TextBox
		Me._txtSpace3_1 = New System.Windows.Forms.TextBox
		Me._txtQuantity_1 = New System.Windows.Forms.TextBox
		Me._txtSpace2_1 = New System.Windows.Forms.TextBox
		Me._txtSpace1_1 = New System.Windows.Forms.TextBox
		Me._txtDescription_1 = New System.Windows.Forms.TextBox
		Me._txtItem_1 = New System.Windows.Forms.TextBox
		Me._txtClosed_0 = New System.Windows.Forms.TextBox
		Me._txtReceived_0 = New System.Windows.Forms.TextBox
		Me._txtAmount_0 = New System.Windows.Forms.TextBox
		Me._txtSpace4_0 = New System.Windows.Forms.TextBox
		Me._txtRate_0 = New System.Windows.Forms.TextBox
		Me._txtSpace3_0 = New System.Windows.Forms.TextBox
		Me._txtQuantity_0 = New System.Windows.Forms.TextBox
		Me._txtSpace2_0 = New System.Windows.Forms.TextBox
		Me._txtSpace1_0 = New System.Windows.Forms.TextBox
		Me._txtDescription_0 = New System.Windows.Forms.TextBox
		Me._txtItem_0 = New System.Windows.Forms.TextBox
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Label13 = New System.Windows.Forms.Label
		Me.vscPOLineScroll = New System.Windows.Forms.VScrollBar
		Me.txtVendor = New System.Windows.Forms.TextBox
		Me.txtRefNumber = New System.Windows.Forms.TextBox
		Me.txtTxnDate = New System.Windows.Forms.TextBox
		Me.txtTxnID = New System.Windows.Forms.TextBox
		Me.txtEditSequence = New System.Windows.Forms.TextBox
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.txtAmount = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtClosed = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtDescription = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtItem = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtQuantity = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtRate = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtReceived = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace1 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace2 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace3 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace4 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.Frame1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtClosed, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtItem, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtRate, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtReceived, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace4, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.Text = "Purchase Order Details"
		Me.ClientSize = New System.Drawing.Size(618, 493)
		Me.Location = New System.Drawing.Point(224, 157)
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmPurchaseOrderDetail"
		Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdExit.Text = "Exit"
		Me.cmdExit.Size = New System.Drawing.Size(121, 73)
		Me.cmdExit.Location = New System.Drawing.Point(488, 408)
		Me.cmdExit.TabIndex = 134
		Me.cmdExit.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
		Me.cmdExit.CausesValidation = True
		Me.cmdExit.Enabled = True
		Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdExit.TabStop = True
		Me.cmdExit.Name = "cmdExit"
		Me.cmdReturn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdReturn.Text = "Return to open PO list"
		Me.cmdReturn.Size = New System.Drawing.Size(129, 73)
		Me.cmdReturn.Location = New System.Drawing.Point(344, 408)
		Me.cmdReturn.TabIndex = 133
		Me.cmdReturn.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdReturn.BackColor = System.Drawing.SystemColors.Control
		Me.cmdReturn.CausesValidation = True
		Me.cmdReturn.Enabled = True
		Me.cmdReturn.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdReturn.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdReturn.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdReturn.TabStop = True
		Me.cmdReturn.Name = "cmdReturn"
		Me.cmdCloseLine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdCloseLine.Text = "Close highlighted line without receiving remaining quantity"
		Me.cmdCloseLine.Size = New System.Drawing.Size(321, 33)
		Me.cmdCloseLine.Location = New System.Drawing.Point(8, 448)
		Me.cmdCloseLine.TabIndex = 132
		Me.cmdCloseLine.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdCloseLine.BackColor = System.Drawing.SystemColors.Control
		Me.cmdCloseLine.CausesValidation = True
		Me.cmdCloseLine.Enabled = True
		Me.cmdCloseLine.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdCloseLine.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdCloseLine.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdCloseLine.TabStop = True
		Me.cmdCloseLine.Name = "cmdCloseLine"
		Me.cmdCloseAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdCloseAll.Text = "Close entire purchase order without receiving open items"
		Me.cmdCloseAll.Size = New System.Drawing.Size(321, 33)
		Me.cmdCloseAll.Location = New System.Drawing.Point(8, 408)
		Me.cmdCloseAll.TabIndex = 131
		Me.cmdCloseAll.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdCloseAll.BackColor = System.Drawing.SystemColors.Control
		Me.cmdCloseAll.CausesValidation = True
		Me.cmdCloseAll.Enabled = True
		Me.cmdCloseAll.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdCloseAll.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdCloseAll.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdCloseAll.TabStop = True
		Me.cmdCloseAll.Name = "cmdCloseAll"
		Me.cmdReceiveOne.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdReceiveOne.Text = "Set quantity orderd to quantity received and bill for the difference for highlighted line"
		Me.cmdReceiveOne.Size = New System.Drawing.Size(321, 33)
		Me.cmdReceiveOne.Location = New System.Drawing.Point(8, 368)
		Me.cmdReceiveOne.TabIndex = 130
		Me.cmdReceiveOne.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdReceiveOne.BackColor = System.Drawing.SystemColors.Control
		Me.cmdReceiveOne.CausesValidation = True
		Me.cmdReceiveOne.Enabled = True
		Me.cmdReceiveOne.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdReceiveOne.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdReceiveOne.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdReceiveOne.TabStop = True
		Me.cmdReceiveOne.Name = "cmdReceiveOne"
		Me.cmdReceiveAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdReceiveAll.Text = "Set quantities orderd to quantities received and bill for the difference for entire purchase order"
		Me.cmdReceiveAll.Size = New System.Drawing.Size(321, 33)
		Me.cmdReceiveAll.Location = New System.Drawing.Point(8, 328)
		Me.cmdReceiveAll.TabIndex = 129
		Me.cmdReceiveAll.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdReceiveAll.BackColor = System.Drawing.SystemColors.Control
		Me.cmdReceiveAll.CausesValidation = True
		Me.cmdReceiveAll.Enabled = True
		Me.cmdReceiveAll.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdReceiveAll.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdReceiveAll.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdReceiveAll.TabStop = True
		Me.cmdReceiveAll.Name = "cmdReceiveAll"
		Me.Frame1.Text = " Purchase Order Lines "
		Me.Frame1.Size = New System.Drawing.Size(577, 225)
		Me.Frame1.Location = New System.Drawing.Point(8, 96)
		Me.Frame1.TabIndex = 11
		Me.Frame1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame1.Name = "Frame1"
		Me._txtClosed_9.AutoSize = False
		Me._txtClosed_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_9.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_9.Location = New System.Drawing.Point(528, 184)
		Me._txtClosed_9.TabIndex = 121
		Me._txtClosed_9.AcceptsReturn = True
		Me._txtClosed_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_9.CausesValidation = True
		Me._txtClosed_9.Enabled = True
		Me._txtClosed_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_9.HideSelection = True
		Me._txtClosed_9.ReadOnly = False
		Me._txtClosed_9.Maxlength = 0
		Me._txtClosed_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_9.MultiLine = False
		Me._txtClosed_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_9.TabStop = True
		Me._txtClosed_9.Visible = True
		Me._txtClosed_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_9.Name = "_txtClosed_9"
		Me._txtReceived_9.AutoSize = False
		Me._txtReceived_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_9.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_9.Location = New System.Drawing.Point(472, 184)
		Me._txtReceived_9.TabIndex = 120
		Me._txtReceived_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_9.AcceptsReturn = True
		Me._txtReceived_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_9.CausesValidation = True
		Me._txtReceived_9.Enabled = True
		Me._txtReceived_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_9.HideSelection = True
		Me._txtReceived_9.ReadOnly = False
		Me._txtReceived_9.Maxlength = 0
		Me._txtReceived_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_9.MultiLine = False
		Me._txtReceived_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_9.TabStop = True
		Me._txtReceived_9.Visible = True
		Me._txtReceived_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_9.Name = "_txtReceived_9"
		Me._txtAmount_9.AutoSize = False
		Me._txtAmount_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_9.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_9.Location = New System.Drawing.Point(424, 184)
		Me._txtAmount_9.TabIndex = 119
		Me._txtAmount_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_9.AcceptsReturn = True
		Me._txtAmount_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_9.CausesValidation = True
		Me._txtAmount_9.Enabled = True
		Me._txtAmount_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_9.HideSelection = True
		Me._txtAmount_9.ReadOnly = False
		Me._txtAmount_9.Maxlength = 0
		Me._txtAmount_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_9.MultiLine = False
		Me._txtAmount_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_9.TabStop = True
		Me._txtAmount_9.Visible = True
		Me._txtAmount_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_9.Name = "_txtAmount_9"
		Me._txtSpace4_9.AutoSize = False
		Me._txtSpace4_9.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_9.Location = New System.Drawing.Point(416, 184)
		Me._txtSpace4_9.TabIndex = 118
		Me._txtSpace4_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_9.AcceptsReturn = True
		Me._txtSpace4_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_9.CausesValidation = True
		Me._txtSpace4_9.Enabled = True
		Me._txtSpace4_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_9.HideSelection = True
		Me._txtSpace4_9.ReadOnly = False
		Me._txtSpace4_9.Maxlength = 0
		Me._txtSpace4_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_9.MultiLine = False
		Me._txtSpace4_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_9.TabStop = True
		Me._txtSpace4_9.Visible = True
		Me._txtSpace4_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_9.Name = "_txtSpace4_9"
		Me._txtRate_9.AutoSize = False
		Me._txtRate_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_9.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_9.Location = New System.Drawing.Point(360, 184)
		Me._txtRate_9.ReadOnly = True
		Me._txtRate_9.TabIndex = 117
		Me._txtRate_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_9.AcceptsReturn = True
		Me._txtRate_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_9.CausesValidation = True
		Me._txtRate_9.Enabled = True
		Me._txtRate_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_9.HideSelection = True
		Me._txtRate_9.Maxlength = 0
		Me._txtRate_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_9.MultiLine = False
		Me._txtRate_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_9.TabStop = True
		Me._txtRate_9.Visible = True
		Me._txtRate_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_9.Name = "_txtRate_9"
		Me._txtSpace3_9.AutoSize = False
		Me._txtSpace3_9.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_9.Location = New System.Drawing.Point(352, 184)
		Me._txtSpace3_9.TabIndex = 116
		Me._txtSpace3_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_9.AcceptsReturn = True
		Me._txtSpace3_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_9.CausesValidation = True
		Me._txtSpace3_9.Enabled = True
		Me._txtSpace3_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_9.HideSelection = True
		Me._txtSpace3_9.ReadOnly = False
		Me._txtSpace3_9.Maxlength = 0
		Me._txtSpace3_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_9.MultiLine = False
		Me._txtSpace3_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_9.TabStop = True
		Me._txtSpace3_9.Visible = True
		Me._txtSpace3_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_9.Name = "_txtSpace3_9"
		Me._txtQuantity_9.AutoSize = False
		Me._txtQuantity_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_9.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_9.Location = New System.Drawing.Point(304, 184)
		Me._txtQuantity_9.ReadOnly = True
		Me._txtQuantity_9.TabIndex = 115
		Me._txtQuantity_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_9.AcceptsReturn = True
		Me._txtQuantity_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_9.CausesValidation = True
		Me._txtQuantity_9.Enabled = True
		Me._txtQuantity_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_9.HideSelection = True
		Me._txtQuantity_9.Maxlength = 0
		Me._txtQuantity_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_9.MultiLine = False
		Me._txtQuantity_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_9.TabStop = True
		Me._txtQuantity_9.Visible = True
		Me._txtQuantity_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_9.Name = "_txtQuantity_9"
		Me._txtSpace2_9.AutoSize = False
		Me._txtSpace2_9.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_9.Location = New System.Drawing.Point(296, 184)
		Me._txtSpace2_9.TabIndex = 114
		Me._txtSpace2_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_9.AcceptsReturn = True
		Me._txtSpace2_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_9.CausesValidation = True
		Me._txtSpace2_9.Enabled = True
		Me._txtSpace2_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_9.HideSelection = True
		Me._txtSpace2_9.ReadOnly = False
		Me._txtSpace2_9.Maxlength = 0
		Me._txtSpace2_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_9.MultiLine = False
		Me._txtSpace2_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_9.TabStop = True
		Me._txtSpace2_9.Visible = True
		Me._txtSpace2_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_9.Name = "_txtSpace2_9"
		Me._txtSpace1_9.AutoSize = False
		Me._txtSpace1_9.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_9.Location = New System.Drawing.Point(104, 184)
		Me._txtSpace1_9.TabIndex = 113
		Me._txtSpace1_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_9.AcceptsReturn = True
		Me._txtSpace1_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_9.CausesValidation = True
		Me._txtSpace1_9.Enabled = True
		Me._txtSpace1_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_9.HideSelection = True
		Me._txtSpace1_9.ReadOnly = False
		Me._txtSpace1_9.Maxlength = 0
		Me._txtSpace1_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_9.MultiLine = False
		Me._txtSpace1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_9.TabStop = True
		Me._txtSpace1_9.Visible = True
		Me._txtSpace1_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_9.Name = "_txtSpace1_9"
		Me._txtDescription_9.AutoSize = False
		Me._txtDescription_9.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_9.Location = New System.Drawing.Point(112, 184)
		Me._txtDescription_9.ReadOnly = True
		Me._txtDescription_9.TabIndex = 112
		Me._txtDescription_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_9.AcceptsReturn = True
		Me._txtDescription_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_9.CausesValidation = True
		Me._txtDescription_9.Enabled = True
		Me._txtDescription_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_9.HideSelection = True
		Me._txtDescription_9.Maxlength = 0
		Me._txtDescription_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_9.MultiLine = False
		Me._txtDescription_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_9.TabStop = True
		Me._txtDescription_9.Visible = True
		Me._txtDescription_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_9.Name = "_txtDescription_9"
		Me._txtItem_9.AutoSize = False
		Me._txtItem_9.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_9.Location = New System.Drawing.Point(8, 184)
		Me._txtItem_9.ReadOnly = True
		Me._txtItem_9.TabIndex = 111
		Me._txtItem_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_9.AcceptsReturn = True
		Me._txtItem_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_9.CausesValidation = True
		Me._txtItem_9.Enabled = True
		Me._txtItem_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_9.HideSelection = True
		Me._txtItem_9.Maxlength = 0
		Me._txtItem_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_9.MultiLine = False
		Me._txtItem_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_9.TabStop = True
		Me._txtItem_9.Visible = True
		Me._txtItem_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_9.Name = "_txtItem_9"
		Me._txtClosed_8.AutoSize = False
		Me._txtClosed_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_8.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_8.Location = New System.Drawing.Point(528, 168)
		Me._txtClosed_8.TabIndex = 110
		Me._txtClosed_8.AcceptsReturn = True
		Me._txtClosed_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_8.CausesValidation = True
		Me._txtClosed_8.Enabled = True
		Me._txtClosed_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_8.HideSelection = True
		Me._txtClosed_8.ReadOnly = False
		Me._txtClosed_8.Maxlength = 0
		Me._txtClosed_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_8.MultiLine = False
		Me._txtClosed_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_8.TabStop = True
		Me._txtClosed_8.Visible = True
		Me._txtClosed_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_8.Name = "_txtClosed_8"
		Me._txtReceived_8.AutoSize = False
		Me._txtReceived_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_8.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_8.Location = New System.Drawing.Point(472, 168)
		Me._txtReceived_8.TabIndex = 109
		Me._txtReceived_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_8.AcceptsReturn = True
		Me._txtReceived_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_8.CausesValidation = True
		Me._txtReceived_8.Enabled = True
		Me._txtReceived_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_8.HideSelection = True
		Me._txtReceived_8.ReadOnly = False
		Me._txtReceived_8.Maxlength = 0
		Me._txtReceived_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_8.MultiLine = False
		Me._txtReceived_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_8.TabStop = True
		Me._txtReceived_8.Visible = True
		Me._txtReceived_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_8.Name = "_txtReceived_8"
		Me._txtAmount_8.AutoSize = False
		Me._txtAmount_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_8.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_8.Location = New System.Drawing.Point(424, 168)
		Me._txtAmount_8.TabIndex = 108
		Me._txtAmount_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_8.AcceptsReturn = True
		Me._txtAmount_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_8.CausesValidation = True
		Me._txtAmount_8.Enabled = True
		Me._txtAmount_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_8.HideSelection = True
		Me._txtAmount_8.ReadOnly = False
		Me._txtAmount_8.Maxlength = 0
		Me._txtAmount_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_8.MultiLine = False
		Me._txtAmount_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_8.TabStop = True
		Me._txtAmount_8.Visible = True
		Me._txtAmount_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_8.Name = "_txtAmount_8"
		Me._txtSpace4_8.AutoSize = False
		Me._txtSpace4_8.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_8.Location = New System.Drawing.Point(416, 168)
		Me._txtSpace4_8.TabIndex = 107
		Me._txtSpace4_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_8.AcceptsReturn = True
		Me._txtSpace4_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_8.CausesValidation = True
		Me._txtSpace4_8.Enabled = True
		Me._txtSpace4_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_8.HideSelection = True
		Me._txtSpace4_8.ReadOnly = False
		Me._txtSpace4_8.Maxlength = 0
		Me._txtSpace4_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_8.MultiLine = False
		Me._txtSpace4_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_8.TabStop = True
		Me._txtSpace4_8.Visible = True
		Me._txtSpace4_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_8.Name = "_txtSpace4_8"
		Me._txtRate_8.AutoSize = False
		Me._txtRate_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_8.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_8.Location = New System.Drawing.Point(360, 168)
		Me._txtRate_8.ReadOnly = True
		Me._txtRate_8.TabIndex = 106
		Me._txtRate_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_8.AcceptsReturn = True
		Me._txtRate_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_8.CausesValidation = True
		Me._txtRate_8.Enabled = True
		Me._txtRate_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_8.HideSelection = True
		Me._txtRate_8.Maxlength = 0
		Me._txtRate_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_8.MultiLine = False
		Me._txtRate_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_8.TabStop = True
		Me._txtRate_8.Visible = True
		Me._txtRate_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_8.Name = "_txtRate_8"
		Me._txtSpace3_8.AutoSize = False
		Me._txtSpace3_8.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_8.Location = New System.Drawing.Point(352, 168)
		Me._txtSpace3_8.TabIndex = 105
		Me._txtSpace3_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_8.AcceptsReturn = True
		Me._txtSpace3_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_8.CausesValidation = True
		Me._txtSpace3_8.Enabled = True
		Me._txtSpace3_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_8.HideSelection = True
		Me._txtSpace3_8.ReadOnly = False
		Me._txtSpace3_8.Maxlength = 0
		Me._txtSpace3_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_8.MultiLine = False
		Me._txtSpace3_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_8.TabStop = True
		Me._txtSpace3_8.Visible = True
		Me._txtSpace3_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_8.Name = "_txtSpace3_8"
		Me._txtQuantity_8.AutoSize = False
		Me._txtQuantity_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_8.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_8.Location = New System.Drawing.Point(304, 168)
		Me._txtQuantity_8.ReadOnly = True
		Me._txtQuantity_8.TabIndex = 104
		Me._txtQuantity_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_8.AcceptsReturn = True
		Me._txtQuantity_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_8.CausesValidation = True
		Me._txtQuantity_8.Enabled = True
		Me._txtQuantity_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_8.HideSelection = True
		Me._txtQuantity_8.Maxlength = 0
		Me._txtQuantity_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_8.MultiLine = False
		Me._txtQuantity_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_8.TabStop = True
		Me._txtQuantity_8.Visible = True
		Me._txtQuantity_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_8.Name = "_txtQuantity_8"
		Me._txtSpace2_8.AutoSize = False
		Me._txtSpace2_8.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_8.Location = New System.Drawing.Point(296, 168)
		Me._txtSpace2_8.TabIndex = 103
		Me._txtSpace2_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_8.AcceptsReturn = True
		Me._txtSpace2_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_8.CausesValidation = True
		Me._txtSpace2_8.Enabled = True
		Me._txtSpace2_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_8.HideSelection = True
		Me._txtSpace2_8.ReadOnly = False
		Me._txtSpace2_8.Maxlength = 0
		Me._txtSpace2_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_8.MultiLine = False
		Me._txtSpace2_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_8.TabStop = True
		Me._txtSpace2_8.Visible = True
		Me._txtSpace2_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_8.Name = "_txtSpace2_8"
		Me._txtSpace1_8.AutoSize = False
		Me._txtSpace1_8.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_8.Location = New System.Drawing.Point(104, 168)
		Me._txtSpace1_8.TabIndex = 102
		Me._txtSpace1_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_8.AcceptsReturn = True
		Me._txtSpace1_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_8.CausesValidation = True
		Me._txtSpace1_8.Enabled = True
		Me._txtSpace1_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_8.HideSelection = True
		Me._txtSpace1_8.ReadOnly = False
		Me._txtSpace1_8.Maxlength = 0
		Me._txtSpace1_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_8.MultiLine = False
		Me._txtSpace1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_8.TabStop = True
		Me._txtSpace1_8.Visible = True
		Me._txtSpace1_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_8.Name = "_txtSpace1_8"
		Me._txtDescription_8.AutoSize = False
		Me._txtDescription_8.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_8.Location = New System.Drawing.Point(112, 168)
		Me._txtDescription_8.ReadOnly = True
		Me._txtDescription_8.TabIndex = 101
		Me._txtDescription_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_8.AcceptsReturn = True
		Me._txtDescription_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_8.CausesValidation = True
		Me._txtDescription_8.Enabled = True
		Me._txtDescription_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_8.HideSelection = True
		Me._txtDescription_8.Maxlength = 0
		Me._txtDescription_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_8.MultiLine = False
		Me._txtDescription_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_8.TabStop = True
		Me._txtDescription_8.Visible = True
		Me._txtDescription_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_8.Name = "_txtDescription_8"
		Me._txtItem_8.AutoSize = False
		Me._txtItem_8.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_8.Location = New System.Drawing.Point(8, 168)
		Me._txtItem_8.ReadOnly = True
		Me._txtItem_8.TabIndex = 100
		Me._txtItem_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_8.AcceptsReturn = True
		Me._txtItem_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_8.CausesValidation = True
		Me._txtItem_8.Enabled = True
		Me._txtItem_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_8.HideSelection = True
		Me._txtItem_8.Maxlength = 0
		Me._txtItem_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_8.MultiLine = False
		Me._txtItem_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_8.TabStop = True
		Me._txtItem_8.Visible = True
		Me._txtItem_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_8.Name = "_txtItem_8"
		Me._txtClosed_7.AutoSize = False
		Me._txtClosed_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_7.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_7.Location = New System.Drawing.Point(528, 152)
		Me._txtClosed_7.TabIndex = 99
		Me._txtClosed_7.AcceptsReturn = True
		Me._txtClosed_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_7.CausesValidation = True
		Me._txtClosed_7.Enabled = True
		Me._txtClosed_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_7.HideSelection = True
		Me._txtClosed_7.ReadOnly = False
		Me._txtClosed_7.Maxlength = 0
		Me._txtClosed_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_7.MultiLine = False
		Me._txtClosed_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_7.TabStop = True
		Me._txtClosed_7.Visible = True
		Me._txtClosed_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_7.Name = "_txtClosed_7"
		Me._txtReceived_7.AutoSize = False
		Me._txtReceived_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_7.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_7.Location = New System.Drawing.Point(472, 152)
		Me._txtReceived_7.TabIndex = 98
		Me._txtReceived_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_7.AcceptsReturn = True
		Me._txtReceived_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_7.CausesValidation = True
		Me._txtReceived_7.Enabled = True
		Me._txtReceived_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_7.HideSelection = True
		Me._txtReceived_7.ReadOnly = False
		Me._txtReceived_7.Maxlength = 0
		Me._txtReceived_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_7.MultiLine = False
		Me._txtReceived_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_7.TabStop = True
		Me._txtReceived_7.Visible = True
		Me._txtReceived_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_7.Name = "_txtReceived_7"
		Me._txtAmount_7.AutoSize = False
		Me._txtAmount_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_7.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_7.Location = New System.Drawing.Point(424, 152)
		Me._txtAmount_7.TabIndex = 97
		Me._txtAmount_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_7.AcceptsReturn = True
		Me._txtAmount_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_7.CausesValidation = True
		Me._txtAmount_7.Enabled = True
		Me._txtAmount_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_7.HideSelection = True
		Me._txtAmount_7.ReadOnly = False
		Me._txtAmount_7.Maxlength = 0
		Me._txtAmount_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_7.MultiLine = False
		Me._txtAmount_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_7.TabStop = True
		Me._txtAmount_7.Visible = True
		Me._txtAmount_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_7.Name = "_txtAmount_7"
		Me._txtSpace4_7.AutoSize = False
		Me._txtSpace4_7.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_7.Location = New System.Drawing.Point(416, 152)
		Me._txtSpace4_7.TabIndex = 96
		Me._txtSpace4_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_7.AcceptsReturn = True
		Me._txtSpace4_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_7.CausesValidation = True
		Me._txtSpace4_7.Enabled = True
		Me._txtSpace4_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_7.HideSelection = True
		Me._txtSpace4_7.ReadOnly = False
		Me._txtSpace4_7.Maxlength = 0
		Me._txtSpace4_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_7.MultiLine = False
		Me._txtSpace4_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_7.TabStop = True
		Me._txtSpace4_7.Visible = True
		Me._txtSpace4_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_7.Name = "_txtSpace4_7"
		Me._txtRate_7.AutoSize = False
		Me._txtRate_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_7.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_7.Location = New System.Drawing.Point(360, 152)
		Me._txtRate_7.ReadOnly = True
		Me._txtRate_7.TabIndex = 95
		Me._txtRate_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_7.AcceptsReturn = True
		Me._txtRate_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_7.CausesValidation = True
		Me._txtRate_7.Enabled = True
		Me._txtRate_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_7.HideSelection = True
		Me._txtRate_7.Maxlength = 0
		Me._txtRate_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_7.MultiLine = False
		Me._txtRate_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_7.TabStop = True
		Me._txtRate_7.Visible = True
		Me._txtRate_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_7.Name = "_txtRate_7"
		Me._txtSpace3_7.AutoSize = False
		Me._txtSpace3_7.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_7.Location = New System.Drawing.Point(352, 152)
		Me._txtSpace3_7.TabIndex = 94
		Me._txtSpace3_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_7.AcceptsReturn = True
		Me._txtSpace3_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_7.CausesValidation = True
		Me._txtSpace3_7.Enabled = True
		Me._txtSpace3_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_7.HideSelection = True
		Me._txtSpace3_7.ReadOnly = False
		Me._txtSpace3_7.Maxlength = 0
		Me._txtSpace3_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_7.MultiLine = False
		Me._txtSpace3_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_7.TabStop = True
		Me._txtSpace3_7.Visible = True
		Me._txtSpace3_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_7.Name = "_txtSpace3_7"
		Me._txtQuantity_7.AutoSize = False
		Me._txtQuantity_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_7.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_7.Location = New System.Drawing.Point(304, 152)
		Me._txtQuantity_7.ReadOnly = True
		Me._txtQuantity_7.TabIndex = 93
		Me._txtQuantity_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_7.AcceptsReturn = True
		Me._txtQuantity_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_7.CausesValidation = True
		Me._txtQuantity_7.Enabled = True
		Me._txtQuantity_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_7.HideSelection = True
		Me._txtQuantity_7.Maxlength = 0
		Me._txtQuantity_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_7.MultiLine = False
		Me._txtQuantity_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_7.TabStop = True
		Me._txtQuantity_7.Visible = True
		Me._txtQuantity_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_7.Name = "_txtQuantity_7"
		Me._txtSpace2_7.AutoSize = False
		Me._txtSpace2_7.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_7.Location = New System.Drawing.Point(296, 152)
		Me._txtSpace2_7.TabIndex = 92
		Me._txtSpace2_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_7.AcceptsReturn = True
		Me._txtSpace2_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_7.CausesValidation = True
		Me._txtSpace2_7.Enabled = True
		Me._txtSpace2_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_7.HideSelection = True
		Me._txtSpace2_7.ReadOnly = False
		Me._txtSpace2_7.Maxlength = 0
		Me._txtSpace2_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_7.MultiLine = False
		Me._txtSpace2_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_7.TabStop = True
		Me._txtSpace2_7.Visible = True
		Me._txtSpace2_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_7.Name = "_txtSpace2_7"
		Me._txtSpace1_7.AutoSize = False
		Me._txtSpace1_7.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_7.Location = New System.Drawing.Point(104, 152)
		Me._txtSpace1_7.TabIndex = 91
		Me._txtSpace1_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_7.AcceptsReturn = True
		Me._txtSpace1_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_7.CausesValidation = True
		Me._txtSpace1_7.Enabled = True
		Me._txtSpace1_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_7.HideSelection = True
		Me._txtSpace1_7.ReadOnly = False
		Me._txtSpace1_7.Maxlength = 0
		Me._txtSpace1_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_7.MultiLine = False
		Me._txtSpace1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_7.TabStop = True
		Me._txtSpace1_7.Visible = True
		Me._txtSpace1_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_7.Name = "_txtSpace1_7"
		Me._txtDescription_7.AutoSize = False
		Me._txtDescription_7.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_7.Location = New System.Drawing.Point(112, 152)
		Me._txtDescription_7.ReadOnly = True
		Me._txtDescription_7.TabIndex = 90
		Me._txtDescription_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_7.AcceptsReturn = True
		Me._txtDescription_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_7.CausesValidation = True
		Me._txtDescription_7.Enabled = True
		Me._txtDescription_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_7.HideSelection = True
		Me._txtDescription_7.Maxlength = 0
		Me._txtDescription_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_7.MultiLine = False
		Me._txtDescription_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_7.TabStop = True
		Me._txtDescription_7.Visible = True
		Me._txtDescription_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_7.Name = "_txtDescription_7"
		Me._txtItem_7.AutoSize = False
		Me._txtItem_7.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_7.Location = New System.Drawing.Point(8, 152)
		Me._txtItem_7.ReadOnly = True
		Me._txtItem_7.TabIndex = 89
		Me._txtItem_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_7.AcceptsReturn = True
		Me._txtItem_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_7.CausesValidation = True
		Me._txtItem_7.Enabled = True
		Me._txtItem_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_7.HideSelection = True
		Me._txtItem_7.Maxlength = 0
		Me._txtItem_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_7.MultiLine = False
		Me._txtItem_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_7.TabStop = True
		Me._txtItem_7.Visible = True
		Me._txtItem_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_7.Name = "_txtItem_7"
		Me._txtClosed_6.AutoSize = False
		Me._txtClosed_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_6.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_6.Location = New System.Drawing.Point(528, 136)
		Me._txtClosed_6.TabIndex = 88
		Me._txtClosed_6.AcceptsReturn = True
		Me._txtClosed_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_6.CausesValidation = True
		Me._txtClosed_6.Enabled = True
		Me._txtClosed_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_6.HideSelection = True
		Me._txtClosed_6.ReadOnly = False
		Me._txtClosed_6.Maxlength = 0
		Me._txtClosed_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_6.MultiLine = False
		Me._txtClosed_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_6.TabStop = True
		Me._txtClosed_6.Visible = True
		Me._txtClosed_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_6.Name = "_txtClosed_6"
		Me._txtReceived_6.AutoSize = False
		Me._txtReceived_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_6.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_6.Location = New System.Drawing.Point(472, 136)
		Me._txtReceived_6.TabIndex = 87
		Me._txtReceived_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_6.AcceptsReturn = True
		Me._txtReceived_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_6.CausesValidation = True
		Me._txtReceived_6.Enabled = True
		Me._txtReceived_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_6.HideSelection = True
		Me._txtReceived_6.ReadOnly = False
		Me._txtReceived_6.Maxlength = 0
		Me._txtReceived_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_6.MultiLine = False
		Me._txtReceived_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_6.TabStop = True
		Me._txtReceived_6.Visible = True
		Me._txtReceived_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_6.Name = "_txtReceived_6"
		Me._txtAmount_6.AutoSize = False
		Me._txtAmount_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_6.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_6.Location = New System.Drawing.Point(424, 136)
		Me._txtAmount_6.TabIndex = 86
		Me._txtAmount_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_6.AcceptsReturn = True
		Me._txtAmount_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_6.CausesValidation = True
		Me._txtAmount_6.Enabled = True
		Me._txtAmount_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_6.HideSelection = True
		Me._txtAmount_6.ReadOnly = False
		Me._txtAmount_6.Maxlength = 0
		Me._txtAmount_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_6.MultiLine = False
		Me._txtAmount_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_6.TabStop = True
		Me._txtAmount_6.Visible = True
		Me._txtAmount_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_6.Name = "_txtAmount_6"
		Me._txtSpace4_6.AutoSize = False
		Me._txtSpace4_6.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_6.Location = New System.Drawing.Point(416, 136)
		Me._txtSpace4_6.TabIndex = 85
		Me._txtSpace4_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_6.AcceptsReturn = True
		Me._txtSpace4_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_6.CausesValidation = True
		Me._txtSpace4_6.Enabled = True
		Me._txtSpace4_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_6.HideSelection = True
		Me._txtSpace4_6.ReadOnly = False
		Me._txtSpace4_6.Maxlength = 0
		Me._txtSpace4_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_6.MultiLine = False
		Me._txtSpace4_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_6.TabStop = True
		Me._txtSpace4_6.Visible = True
		Me._txtSpace4_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_6.Name = "_txtSpace4_6"
		Me._txtRate_6.AutoSize = False
		Me._txtRate_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_6.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_6.Location = New System.Drawing.Point(360, 136)
		Me._txtRate_6.ReadOnly = True
		Me._txtRate_6.TabIndex = 84
		Me._txtRate_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_6.AcceptsReturn = True
		Me._txtRate_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_6.CausesValidation = True
		Me._txtRate_6.Enabled = True
		Me._txtRate_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_6.HideSelection = True
		Me._txtRate_6.Maxlength = 0
		Me._txtRate_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_6.MultiLine = False
		Me._txtRate_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_6.TabStop = True
		Me._txtRate_6.Visible = True
		Me._txtRate_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_6.Name = "_txtRate_6"
		Me._txtSpace3_6.AutoSize = False
		Me._txtSpace3_6.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_6.Location = New System.Drawing.Point(352, 136)
		Me._txtSpace3_6.TabIndex = 83
		Me._txtSpace3_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_6.AcceptsReturn = True
		Me._txtSpace3_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_6.CausesValidation = True
		Me._txtSpace3_6.Enabled = True
		Me._txtSpace3_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_6.HideSelection = True
		Me._txtSpace3_6.ReadOnly = False
		Me._txtSpace3_6.Maxlength = 0
		Me._txtSpace3_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_6.MultiLine = False
		Me._txtSpace3_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_6.TabStop = True
		Me._txtSpace3_6.Visible = True
		Me._txtSpace3_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_6.Name = "_txtSpace3_6"
		Me._txtQuantity_6.AutoSize = False
		Me._txtQuantity_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_6.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_6.Location = New System.Drawing.Point(304, 136)
		Me._txtQuantity_6.ReadOnly = True
		Me._txtQuantity_6.TabIndex = 82
		Me._txtQuantity_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_6.AcceptsReturn = True
		Me._txtQuantity_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_6.CausesValidation = True
		Me._txtQuantity_6.Enabled = True
		Me._txtQuantity_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_6.HideSelection = True
		Me._txtQuantity_6.Maxlength = 0
		Me._txtQuantity_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_6.MultiLine = False
		Me._txtQuantity_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_6.TabStop = True
		Me._txtQuantity_6.Visible = True
		Me._txtQuantity_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_6.Name = "_txtQuantity_6"
		Me._txtSpace2_6.AutoSize = False
		Me._txtSpace2_6.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_6.Location = New System.Drawing.Point(296, 136)
		Me._txtSpace2_6.TabIndex = 81
		Me._txtSpace2_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_6.AcceptsReturn = True
		Me._txtSpace2_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_6.CausesValidation = True
		Me._txtSpace2_6.Enabled = True
		Me._txtSpace2_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_6.HideSelection = True
		Me._txtSpace2_6.ReadOnly = False
		Me._txtSpace2_6.Maxlength = 0
		Me._txtSpace2_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_6.MultiLine = False
		Me._txtSpace2_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_6.TabStop = True
		Me._txtSpace2_6.Visible = True
		Me._txtSpace2_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_6.Name = "_txtSpace2_6"
		Me._txtSpace1_6.AutoSize = False
		Me._txtSpace1_6.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_6.Location = New System.Drawing.Point(104, 136)
		Me._txtSpace1_6.TabIndex = 80
		Me._txtSpace1_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_6.AcceptsReturn = True
		Me._txtSpace1_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_6.CausesValidation = True
		Me._txtSpace1_6.Enabled = True
		Me._txtSpace1_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_6.HideSelection = True
		Me._txtSpace1_6.ReadOnly = False
		Me._txtSpace1_6.Maxlength = 0
		Me._txtSpace1_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_6.MultiLine = False
		Me._txtSpace1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_6.TabStop = True
		Me._txtSpace1_6.Visible = True
		Me._txtSpace1_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_6.Name = "_txtSpace1_6"
		Me._txtDescription_6.AutoSize = False
		Me._txtDescription_6.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_6.Location = New System.Drawing.Point(112, 136)
		Me._txtDescription_6.ReadOnly = True
		Me._txtDescription_6.TabIndex = 79
		Me._txtDescription_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_6.AcceptsReturn = True
		Me._txtDescription_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_6.CausesValidation = True
		Me._txtDescription_6.Enabled = True
		Me._txtDescription_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_6.HideSelection = True
		Me._txtDescription_6.Maxlength = 0
		Me._txtDescription_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_6.MultiLine = False
		Me._txtDescription_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_6.TabStop = True
		Me._txtDescription_6.Visible = True
		Me._txtDescription_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_6.Name = "_txtDescription_6"
		Me._txtItem_6.AutoSize = False
		Me._txtItem_6.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_6.Location = New System.Drawing.Point(8, 136)
		Me._txtItem_6.ReadOnly = True
		Me._txtItem_6.TabIndex = 78
		Me._txtItem_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_6.AcceptsReturn = True
		Me._txtItem_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_6.CausesValidation = True
		Me._txtItem_6.Enabled = True
		Me._txtItem_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_6.HideSelection = True
		Me._txtItem_6.Maxlength = 0
		Me._txtItem_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_6.MultiLine = False
		Me._txtItem_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_6.TabStop = True
		Me._txtItem_6.Visible = True
		Me._txtItem_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_6.Name = "_txtItem_6"
		Me._txtClosed_5.AutoSize = False
		Me._txtClosed_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_5.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_5.Location = New System.Drawing.Point(528, 120)
		Me._txtClosed_5.TabIndex = 77
		Me._txtClosed_5.AcceptsReturn = True
		Me._txtClosed_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_5.CausesValidation = True
		Me._txtClosed_5.Enabled = True
		Me._txtClosed_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_5.HideSelection = True
		Me._txtClosed_5.ReadOnly = False
		Me._txtClosed_5.Maxlength = 0
		Me._txtClosed_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_5.MultiLine = False
		Me._txtClosed_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_5.TabStop = True
		Me._txtClosed_5.Visible = True
		Me._txtClosed_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_5.Name = "_txtClosed_5"
		Me._txtReceived_5.AutoSize = False
		Me._txtReceived_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_5.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_5.Location = New System.Drawing.Point(472, 120)
		Me._txtReceived_5.TabIndex = 76
		Me._txtReceived_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_5.AcceptsReturn = True
		Me._txtReceived_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_5.CausesValidation = True
		Me._txtReceived_5.Enabled = True
		Me._txtReceived_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_5.HideSelection = True
		Me._txtReceived_5.ReadOnly = False
		Me._txtReceived_5.Maxlength = 0
		Me._txtReceived_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_5.MultiLine = False
		Me._txtReceived_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_5.TabStop = True
		Me._txtReceived_5.Visible = True
		Me._txtReceived_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_5.Name = "_txtReceived_5"
		Me._txtAmount_5.AutoSize = False
		Me._txtAmount_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_5.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_5.Location = New System.Drawing.Point(424, 120)
		Me._txtAmount_5.TabIndex = 75
		Me._txtAmount_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_5.AcceptsReturn = True
		Me._txtAmount_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_5.CausesValidation = True
		Me._txtAmount_5.Enabled = True
		Me._txtAmount_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_5.HideSelection = True
		Me._txtAmount_5.ReadOnly = False
		Me._txtAmount_5.Maxlength = 0
		Me._txtAmount_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_5.MultiLine = False
		Me._txtAmount_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_5.TabStop = True
		Me._txtAmount_5.Visible = True
		Me._txtAmount_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_5.Name = "_txtAmount_5"
		Me._txtSpace4_5.AutoSize = False
		Me._txtSpace4_5.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_5.Location = New System.Drawing.Point(416, 120)
		Me._txtSpace4_5.TabIndex = 74
		Me._txtSpace4_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_5.AcceptsReturn = True
		Me._txtSpace4_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_5.CausesValidation = True
		Me._txtSpace4_5.Enabled = True
		Me._txtSpace4_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_5.HideSelection = True
		Me._txtSpace4_5.ReadOnly = False
		Me._txtSpace4_5.Maxlength = 0
		Me._txtSpace4_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_5.MultiLine = False
		Me._txtSpace4_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_5.TabStop = True
		Me._txtSpace4_5.Visible = True
		Me._txtSpace4_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_5.Name = "_txtSpace4_5"
		Me._txtRate_5.AutoSize = False
		Me._txtRate_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_5.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_5.Location = New System.Drawing.Point(360, 120)
		Me._txtRate_5.ReadOnly = True
		Me._txtRate_5.TabIndex = 73
		Me._txtRate_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_5.AcceptsReturn = True
		Me._txtRate_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_5.CausesValidation = True
		Me._txtRate_5.Enabled = True
		Me._txtRate_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_5.HideSelection = True
		Me._txtRate_5.Maxlength = 0
		Me._txtRate_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_5.MultiLine = False
		Me._txtRate_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_5.TabStop = True
		Me._txtRate_5.Visible = True
		Me._txtRate_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_5.Name = "_txtRate_5"
		Me._txtSpace3_5.AutoSize = False
		Me._txtSpace3_5.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_5.Location = New System.Drawing.Point(352, 120)
		Me._txtSpace3_5.TabIndex = 72
		Me._txtSpace3_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_5.AcceptsReturn = True
		Me._txtSpace3_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_5.CausesValidation = True
		Me._txtSpace3_5.Enabled = True
		Me._txtSpace3_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_5.HideSelection = True
		Me._txtSpace3_5.ReadOnly = False
		Me._txtSpace3_5.Maxlength = 0
		Me._txtSpace3_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_5.MultiLine = False
		Me._txtSpace3_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_5.TabStop = True
		Me._txtSpace3_5.Visible = True
		Me._txtSpace3_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_5.Name = "_txtSpace3_5"
		Me._txtQuantity_5.AutoSize = False
		Me._txtQuantity_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_5.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_5.Location = New System.Drawing.Point(304, 120)
		Me._txtQuantity_5.ReadOnly = True
		Me._txtQuantity_5.TabIndex = 71
		Me._txtQuantity_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_5.AcceptsReturn = True
		Me._txtQuantity_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_5.CausesValidation = True
		Me._txtQuantity_5.Enabled = True
		Me._txtQuantity_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_5.HideSelection = True
		Me._txtQuantity_5.Maxlength = 0
		Me._txtQuantity_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_5.MultiLine = False
		Me._txtQuantity_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_5.TabStop = True
		Me._txtQuantity_5.Visible = True
		Me._txtQuantity_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_5.Name = "_txtQuantity_5"
		Me._txtSpace2_5.AutoSize = False
		Me._txtSpace2_5.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_5.Location = New System.Drawing.Point(296, 120)
		Me._txtSpace2_5.TabIndex = 70
		Me._txtSpace2_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_5.AcceptsReturn = True
		Me._txtSpace2_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_5.CausesValidation = True
		Me._txtSpace2_5.Enabled = True
		Me._txtSpace2_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_5.HideSelection = True
		Me._txtSpace2_5.ReadOnly = False
		Me._txtSpace2_5.Maxlength = 0
		Me._txtSpace2_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_5.MultiLine = False
		Me._txtSpace2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_5.TabStop = True
		Me._txtSpace2_5.Visible = True
		Me._txtSpace2_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_5.Name = "_txtSpace2_5"
		Me._txtSpace1_5.AutoSize = False
		Me._txtSpace1_5.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_5.Location = New System.Drawing.Point(104, 120)
		Me._txtSpace1_5.TabIndex = 69
		Me._txtSpace1_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_5.AcceptsReturn = True
		Me._txtSpace1_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_5.CausesValidation = True
		Me._txtSpace1_5.Enabled = True
		Me._txtSpace1_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_5.HideSelection = True
		Me._txtSpace1_5.ReadOnly = False
		Me._txtSpace1_5.Maxlength = 0
		Me._txtSpace1_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_5.MultiLine = False
		Me._txtSpace1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_5.TabStop = True
		Me._txtSpace1_5.Visible = True
		Me._txtSpace1_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_5.Name = "_txtSpace1_5"
		Me._txtDescription_5.AutoSize = False
		Me._txtDescription_5.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_5.Location = New System.Drawing.Point(112, 120)
		Me._txtDescription_5.ReadOnly = True
		Me._txtDescription_5.TabIndex = 68
		Me._txtDescription_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_5.AcceptsReturn = True
		Me._txtDescription_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_5.CausesValidation = True
		Me._txtDescription_5.Enabled = True
		Me._txtDescription_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_5.HideSelection = True
		Me._txtDescription_5.Maxlength = 0
		Me._txtDescription_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_5.MultiLine = False
		Me._txtDescription_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_5.TabStop = True
		Me._txtDescription_5.Visible = True
		Me._txtDescription_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_5.Name = "_txtDescription_5"
		Me._txtItem_5.AutoSize = False
		Me._txtItem_5.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_5.Location = New System.Drawing.Point(8, 120)
		Me._txtItem_5.ReadOnly = True
		Me._txtItem_5.TabIndex = 67
		Me._txtItem_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_5.AcceptsReturn = True
		Me._txtItem_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_5.CausesValidation = True
		Me._txtItem_5.Enabled = True
		Me._txtItem_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_5.HideSelection = True
		Me._txtItem_5.Maxlength = 0
		Me._txtItem_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_5.MultiLine = False
		Me._txtItem_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_5.TabStop = True
		Me._txtItem_5.Visible = True
		Me._txtItem_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_5.Name = "_txtItem_5"
		Me._txtClosed_4.AutoSize = False
		Me._txtClosed_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_4.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_4.Location = New System.Drawing.Point(528, 104)
		Me._txtClosed_4.TabIndex = 66
		Me._txtClosed_4.AcceptsReturn = True
		Me._txtClosed_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_4.CausesValidation = True
		Me._txtClosed_4.Enabled = True
		Me._txtClosed_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_4.HideSelection = True
		Me._txtClosed_4.ReadOnly = False
		Me._txtClosed_4.Maxlength = 0
		Me._txtClosed_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_4.MultiLine = False
		Me._txtClosed_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_4.TabStop = True
		Me._txtClosed_4.Visible = True
		Me._txtClosed_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_4.Name = "_txtClosed_4"
		Me._txtReceived_4.AutoSize = False
		Me._txtReceived_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_4.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_4.Location = New System.Drawing.Point(472, 104)
		Me._txtReceived_4.TabIndex = 65
		Me._txtReceived_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_4.AcceptsReturn = True
		Me._txtReceived_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_4.CausesValidation = True
		Me._txtReceived_4.Enabled = True
		Me._txtReceived_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_4.HideSelection = True
		Me._txtReceived_4.ReadOnly = False
		Me._txtReceived_4.Maxlength = 0
		Me._txtReceived_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_4.MultiLine = False
		Me._txtReceived_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_4.TabStop = True
		Me._txtReceived_4.Visible = True
		Me._txtReceived_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_4.Name = "_txtReceived_4"
		Me._txtAmount_4.AutoSize = False
		Me._txtAmount_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_4.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_4.Location = New System.Drawing.Point(424, 104)
		Me._txtAmount_4.TabIndex = 64
		Me._txtAmount_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_4.AcceptsReturn = True
		Me._txtAmount_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_4.CausesValidation = True
		Me._txtAmount_4.Enabled = True
		Me._txtAmount_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_4.HideSelection = True
		Me._txtAmount_4.ReadOnly = False
		Me._txtAmount_4.Maxlength = 0
		Me._txtAmount_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_4.MultiLine = False
		Me._txtAmount_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_4.TabStop = True
		Me._txtAmount_4.Visible = True
		Me._txtAmount_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_4.Name = "_txtAmount_4"
		Me._txtSpace4_4.AutoSize = False
		Me._txtSpace4_4.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_4.Location = New System.Drawing.Point(416, 104)
		Me._txtSpace4_4.TabIndex = 63
		Me._txtSpace4_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_4.AcceptsReturn = True
		Me._txtSpace4_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_4.CausesValidation = True
		Me._txtSpace4_4.Enabled = True
		Me._txtSpace4_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_4.HideSelection = True
		Me._txtSpace4_4.ReadOnly = False
		Me._txtSpace4_4.Maxlength = 0
		Me._txtSpace4_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_4.MultiLine = False
		Me._txtSpace4_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_4.TabStop = True
		Me._txtSpace4_4.Visible = True
		Me._txtSpace4_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_4.Name = "_txtSpace4_4"
		Me._txtRate_4.AutoSize = False
		Me._txtRate_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_4.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_4.Location = New System.Drawing.Point(360, 104)
		Me._txtRate_4.ReadOnly = True
		Me._txtRate_4.TabIndex = 62
		Me._txtRate_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_4.AcceptsReturn = True
		Me._txtRate_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_4.CausesValidation = True
		Me._txtRate_4.Enabled = True
		Me._txtRate_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_4.HideSelection = True
		Me._txtRate_4.Maxlength = 0
		Me._txtRate_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_4.MultiLine = False
		Me._txtRate_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_4.TabStop = True
		Me._txtRate_4.Visible = True
		Me._txtRate_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_4.Name = "_txtRate_4"
		Me._txtSpace3_4.AutoSize = False
		Me._txtSpace3_4.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_4.Location = New System.Drawing.Point(352, 104)
		Me._txtSpace3_4.TabIndex = 61
		Me._txtSpace3_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_4.AcceptsReturn = True
		Me._txtSpace3_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_4.CausesValidation = True
		Me._txtSpace3_4.Enabled = True
		Me._txtSpace3_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_4.HideSelection = True
		Me._txtSpace3_4.ReadOnly = False
		Me._txtSpace3_4.Maxlength = 0
		Me._txtSpace3_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_4.MultiLine = False
		Me._txtSpace3_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_4.TabStop = True
		Me._txtSpace3_4.Visible = True
		Me._txtSpace3_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_4.Name = "_txtSpace3_4"
		Me._txtQuantity_4.AutoSize = False
		Me._txtQuantity_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_4.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_4.Location = New System.Drawing.Point(304, 104)
		Me._txtQuantity_4.ReadOnly = True
		Me._txtQuantity_4.TabIndex = 60
		Me._txtQuantity_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_4.AcceptsReturn = True
		Me._txtQuantity_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_4.CausesValidation = True
		Me._txtQuantity_4.Enabled = True
		Me._txtQuantity_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_4.HideSelection = True
		Me._txtQuantity_4.Maxlength = 0
		Me._txtQuantity_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_4.MultiLine = False
		Me._txtQuantity_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_4.TabStop = True
		Me._txtQuantity_4.Visible = True
		Me._txtQuantity_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_4.Name = "_txtQuantity_4"
		Me._txtSpace2_4.AutoSize = False
		Me._txtSpace2_4.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_4.Location = New System.Drawing.Point(296, 104)
		Me._txtSpace2_4.TabIndex = 59
		Me._txtSpace2_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_4.AcceptsReturn = True
		Me._txtSpace2_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_4.CausesValidation = True
		Me._txtSpace2_4.Enabled = True
		Me._txtSpace2_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_4.HideSelection = True
		Me._txtSpace2_4.ReadOnly = False
		Me._txtSpace2_4.Maxlength = 0
		Me._txtSpace2_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_4.MultiLine = False
		Me._txtSpace2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_4.TabStop = True
		Me._txtSpace2_4.Visible = True
		Me._txtSpace2_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_4.Name = "_txtSpace2_4"
		Me._txtSpace1_4.AutoSize = False
		Me._txtSpace1_4.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_4.Location = New System.Drawing.Point(104, 104)
		Me._txtSpace1_4.TabIndex = 58
		Me._txtSpace1_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_4.AcceptsReturn = True
		Me._txtSpace1_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_4.CausesValidation = True
		Me._txtSpace1_4.Enabled = True
		Me._txtSpace1_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_4.HideSelection = True
		Me._txtSpace1_4.ReadOnly = False
		Me._txtSpace1_4.Maxlength = 0
		Me._txtSpace1_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_4.MultiLine = False
		Me._txtSpace1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_4.TabStop = True
		Me._txtSpace1_4.Visible = True
		Me._txtSpace1_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_4.Name = "_txtSpace1_4"
		Me._txtDescription_4.AutoSize = False
		Me._txtDescription_4.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_4.Location = New System.Drawing.Point(112, 104)
		Me._txtDescription_4.ReadOnly = True
		Me._txtDescription_4.TabIndex = 57
		Me._txtDescription_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_4.AcceptsReturn = True
		Me._txtDescription_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_4.CausesValidation = True
		Me._txtDescription_4.Enabled = True
		Me._txtDescription_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_4.HideSelection = True
		Me._txtDescription_4.Maxlength = 0
		Me._txtDescription_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_4.MultiLine = False
		Me._txtDescription_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_4.TabStop = True
		Me._txtDescription_4.Visible = True
		Me._txtDescription_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_4.Name = "_txtDescription_4"
		Me._txtItem_4.AutoSize = False
		Me._txtItem_4.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_4.Location = New System.Drawing.Point(8, 104)
		Me._txtItem_4.ReadOnly = True
		Me._txtItem_4.TabIndex = 56
		Me._txtItem_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_4.AcceptsReturn = True
		Me._txtItem_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_4.CausesValidation = True
		Me._txtItem_4.Enabled = True
		Me._txtItem_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_4.HideSelection = True
		Me._txtItem_4.Maxlength = 0
		Me._txtItem_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_4.MultiLine = False
		Me._txtItem_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_4.TabStop = True
		Me._txtItem_4.Visible = True
		Me._txtItem_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_4.Name = "_txtItem_4"
		Me._txtClosed_3.AutoSize = False
		Me._txtClosed_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_3.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_3.Location = New System.Drawing.Point(528, 88)
		Me._txtClosed_3.TabIndex = 55
		Me._txtClosed_3.AcceptsReturn = True
		Me._txtClosed_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_3.CausesValidation = True
		Me._txtClosed_3.Enabled = True
		Me._txtClosed_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_3.HideSelection = True
		Me._txtClosed_3.ReadOnly = False
		Me._txtClosed_3.Maxlength = 0
		Me._txtClosed_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_3.MultiLine = False
		Me._txtClosed_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_3.TabStop = True
		Me._txtClosed_3.Visible = True
		Me._txtClosed_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_3.Name = "_txtClosed_3"
		Me._txtReceived_3.AutoSize = False
		Me._txtReceived_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_3.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_3.Location = New System.Drawing.Point(472, 88)
		Me._txtReceived_3.TabIndex = 54
		Me._txtReceived_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_3.AcceptsReturn = True
		Me._txtReceived_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_3.CausesValidation = True
		Me._txtReceived_3.Enabled = True
		Me._txtReceived_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_3.HideSelection = True
		Me._txtReceived_3.ReadOnly = False
		Me._txtReceived_3.Maxlength = 0
		Me._txtReceived_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_3.MultiLine = False
		Me._txtReceived_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_3.TabStop = True
		Me._txtReceived_3.Visible = True
		Me._txtReceived_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_3.Name = "_txtReceived_3"
		Me._txtAmount_3.AutoSize = False
		Me._txtAmount_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_3.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_3.Location = New System.Drawing.Point(424, 88)
		Me._txtAmount_3.TabIndex = 53
		Me._txtAmount_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_3.AcceptsReturn = True
		Me._txtAmount_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_3.CausesValidation = True
		Me._txtAmount_3.Enabled = True
		Me._txtAmount_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_3.HideSelection = True
		Me._txtAmount_3.ReadOnly = False
		Me._txtAmount_3.Maxlength = 0
		Me._txtAmount_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_3.MultiLine = False
		Me._txtAmount_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_3.TabStop = True
		Me._txtAmount_3.Visible = True
		Me._txtAmount_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_3.Name = "_txtAmount_3"
		Me._txtSpace4_3.AutoSize = False
		Me._txtSpace4_3.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_3.Location = New System.Drawing.Point(416, 88)
		Me._txtSpace4_3.TabIndex = 52
		Me._txtSpace4_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_3.AcceptsReturn = True
		Me._txtSpace4_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_3.CausesValidation = True
		Me._txtSpace4_3.Enabled = True
		Me._txtSpace4_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_3.HideSelection = True
		Me._txtSpace4_3.ReadOnly = False
		Me._txtSpace4_3.Maxlength = 0
		Me._txtSpace4_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_3.MultiLine = False
		Me._txtSpace4_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_3.TabStop = True
		Me._txtSpace4_3.Visible = True
		Me._txtSpace4_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_3.Name = "_txtSpace4_3"
		Me._txtRate_3.AutoSize = False
		Me._txtRate_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_3.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_3.Location = New System.Drawing.Point(360, 88)
		Me._txtRate_3.ReadOnly = True
		Me._txtRate_3.TabIndex = 51
		Me._txtRate_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_3.AcceptsReturn = True
		Me._txtRate_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_3.CausesValidation = True
		Me._txtRate_3.Enabled = True
		Me._txtRate_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_3.HideSelection = True
		Me._txtRate_3.Maxlength = 0
		Me._txtRate_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_3.MultiLine = False
		Me._txtRate_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_3.TabStop = True
		Me._txtRate_3.Visible = True
		Me._txtRate_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_3.Name = "_txtRate_3"
		Me._txtSpace3_3.AutoSize = False
		Me._txtSpace3_3.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_3.Location = New System.Drawing.Point(352, 88)
		Me._txtSpace3_3.TabIndex = 50
		Me._txtSpace3_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_3.AcceptsReturn = True
		Me._txtSpace3_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_3.CausesValidation = True
		Me._txtSpace3_3.Enabled = True
		Me._txtSpace3_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_3.HideSelection = True
		Me._txtSpace3_3.ReadOnly = False
		Me._txtSpace3_3.Maxlength = 0
		Me._txtSpace3_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_3.MultiLine = False
		Me._txtSpace3_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_3.TabStop = True
		Me._txtSpace3_3.Visible = True
		Me._txtSpace3_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_3.Name = "_txtSpace3_3"
		Me._txtQuantity_3.AutoSize = False
		Me._txtQuantity_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_3.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_3.Location = New System.Drawing.Point(304, 88)
		Me._txtQuantity_3.ReadOnly = True
		Me._txtQuantity_3.TabIndex = 49
		Me._txtQuantity_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_3.AcceptsReturn = True
		Me._txtQuantity_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_3.CausesValidation = True
		Me._txtQuantity_3.Enabled = True
		Me._txtQuantity_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_3.HideSelection = True
		Me._txtQuantity_3.Maxlength = 0
		Me._txtQuantity_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_3.MultiLine = False
		Me._txtQuantity_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_3.TabStop = True
		Me._txtQuantity_3.Visible = True
		Me._txtQuantity_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_3.Name = "_txtQuantity_3"
		Me._txtSpace2_3.AutoSize = False
		Me._txtSpace2_3.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_3.Location = New System.Drawing.Point(296, 88)
		Me._txtSpace2_3.TabIndex = 48
		Me._txtSpace2_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_3.AcceptsReturn = True
		Me._txtSpace2_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_3.CausesValidation = True
		Me._txtSpace2_3.Enabled = True
		Me._txtSpace2_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_3.HideSelection = True
		Me._txtSpace2_3.ReadOnly = False
		Me._txtSpace2_3.Maxlength = 0
		Me._txtSpace2_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_3.MultiLine = False
		Me._txtSpace2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_3.TabStop = True
		Me._txtSpace2_3.Visible = True
		Me._txtSpace2_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_3.Name = "_txtSpace2_3"
		Me._txtSpace1_3.AutoSize = False
		Me._txtSpace1_3.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_3.Location = New System.Drawing.Point(104, 88)
		Me._txtSpace1_3.TabIndex = 47
		Me._txtSpace1_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_3.AcceptsReturn = True
		Me._txtSpace1_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_3.CausesValidation = True
		Me._txtSpace1_3.Enabled = True
		Me._txtSpace1_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_3.HideSelection = True
		Me._txtSpace1_3.ReadOnly = False
		Me._txtSpace1_3.Maxlength = 0
		Me._txtSpace1_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_3.MultiLine = False
		Me._txtSpace1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_3.TabStop = True
		Me._txtSpace1_3.Visible = True
		Me._txtSpace1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_3.Name = "_txtSpace1_3"
		Me._txtDescription_3.AutoSize = False
		Me._txtDescription_3.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_3.Location = New System.Drawing.Point(112, 88)
		Me._txtDescription_3.ReadOnly = True
		Me._txtDescription_3.TabIndex = 46
		Me._txtDescription_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_3.AcceptsReturn = True
		Me._txtDescription_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_3.CausesValidation = True
		Me._txtDescription_3.Enabled = True
		Me._txtDescription_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_3.HideSelection = True
		Me._txtDescription_3.Maxlength = 0
		Me._txtDescription_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_3.MultiLine = False
		Me._txtDescription_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_3.TabStop = True
		Me._txtDescription_3.Visible = True
		Me._txtDescription_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_3.Name = "_txtDescription_3"
		Me._txtItem_3.AutoSize = False
		Me._txtItem_3.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_3.Location = New System.Drawing.Point(8, 88)
		Me._txtItem_3.ReadOnly = True
		Me._txtItem_3.TabIndex = 45
		Me._txtItem_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_3.AcceptsReturn = True
		Me._txtItem_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_3.CausesValidation = True
		Me._txtItem_3.Enabled = True
		Me._txtItem_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_3.HideSelection = True
		Me._txtItem_3.Maxlength = 0
		Me._txtItem_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_3.MultiLine = False
		Me._txtItem_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_3.TabStop = True
		Me._txtItem_3.Visible = True
		Me._txtItem_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_3.Name = "_txtItem_3"
		Me._txtClosed_2.AutoSize = False
		Me._txtClosed_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_2.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_2.Location = New System.Drawing.Point(528, 72)
		Me._txtClosed_2.TabIndex = 44
		Me._txtClosed_2.AcceptsReturn = True
		Me._txtClosed_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_2.CausesValidation = True
		Me._txtClosed_2.Enabled = True
		Me._txtClosed_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_2.HideSelection = True
		Me._txtClosed_2.ReadOnly = False
		Me._txtClosed_2.Maxlength = 0
		Me._txtClosed_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_2.MultiLine = False
		Me._txtClosed_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_2.TabStop = True
		Me._txtClosed_2.Visible = True
		Me._txtClosed_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_2.Name = "_txtClosed_2"
		Me._txtReceived_2.AutoSize = False
		Me._txtReceived_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_2.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_2.Location = New System.Drawing.Point(472, 72)
		Me._txtReceived_2.TabIndex = 43
		Me._txtReceived_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_2.AcceptsReturn = True
		Me._txtReceived_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_2.CausesValidation = True
		Me._txtReceived_2.Enabled = True
		Me._txtReceived_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_2.HideSelection = True
		Me._txtReceived_2.ReadOnly = False
		Me._txtReceived_2.Maxlength = 0
		Me._txtReceived_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_2.MultiLine = False
		Me._txtReceived_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_2.TabStop = True
		Me._txtReceived_2.Visible = True
		Me._txtReceived_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_2.Name = "_txtReceived_2"
		Me._txtAmount_2.AutoSize = False
		Me._txtAmount_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_2.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_2.Location = New System.Drawing.Point(424, 72)
		Me._txtAmount_2.TabIndex = 42
		Me._txtAmount_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_2.AcceptsReturn = True
		Me._txtAmount_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_2.CausesValidation = True
		Me._txtAmount_2.Enabled = True
		Me._txtAmount_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_2.HideSelection = True
		Me._txtAmount_2.ReadOnly = False
		Me._txtAmount_2.Maxlength = 0
		Me._txtAmount_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_2.MultiLine = False
		Me._txtAmount_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_2.TabStop = True
		Me._txtAmount_2.Visible = True
		Me._txtAmount_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_2.Name = "_txtAmount_2"
		Me._txtSpace4_2.AutoSize = False
		Me._txtSpace4_2.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_2.Location = New System.Drawing.Point(416, 72)
		Me._txtSpace4_2.TabIndex = 41
		Me._txtSpace4_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_2.AcceptsReturn = True
		Me._txtSpace4_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_2.CausesValidation = True
		Me._txtSpace4_2.Enabled = True
		Me._txtSpace4_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_2.HideSelection = True
		Me._txtSpace4_2.ReadOnly = False
		Me._txtSpace4_2.Maxlength = 0
		Me._txtSpace4_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_2.MultiLine = False
		Me._txtSpace4_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_2.TabStop = True
		Me._txtSpace4_2.Visible = True
		Me._txtSpace4_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_2.Name = "_txtSpace4_2"
		Me._txtRate_2.AutoSize = False
		Me._txtRate_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_2.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_2.Location = New System.Drawing.Point(360, 72)
		Me._txtRate_2.ReadOnly = True
		Me._txtRate_2.TabIndex = 40
		Me._txtRate_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_2.AcceptsReturn = True
		Me._txtRate_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_2.CausesValidation = True
		Me._txtRate_2.Enabled = True
		Me._txtRate_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_2.HideSelection = True
		Me._txtRate_2.Maxlength = 0
		Me._txtRate_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_2.MultiLine = False
		Me._txtRate_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_2.TabStop = True
		Me._txtRate_2.Visible = True
		Me._txtRate_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_2.Name = "_txtRate_2"
		Me._txtSpace3_2.AutoSize = False
		Me._txtSpace3_2.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_2.Location = New System.Drawing.Point(352, 72)
		Me._txtSpace3_2.TabIndex = 39
		Me._txtSpace3_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_2.AcceptsReturn = True
		Me._txtSpace3_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_2.CausesValidation = True
		Me._txtSpace3_2.Enabled = True
		Me._txtSpace3_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_2.HideSelection = True
		Me._txtSpace3_2.ReadOnly = False
		Me._txtSpace3_2.Maxlength = 0
		Me._txtSpace3_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_2.MultiLine = False
		Me._txtSpace3_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_2.TabStop = True
		Me._txtSpace3_2.Visible = True
		Me._txtSpace3_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_2.Name = "_txtSpace3_2"
		Me._txtQuantity_2.AutoSize = False
		Me._txtQuantity_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_2.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_2.Location = New System.Drawing.Point(304, 72)
		Me._txtQuantity_2.ReadOnly = True
		Me._txtQuantity_2.TabIndex = 38
		Me._txtQuantity_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_2.AcceptsReturn = True
		Me._txtQuantity_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_2.CausesValidation = True
		Me._txtQuantity_2.Enabled = True
		Me._txtQuantity_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_2.HideSelection = True
		Me._txtQuantity_2.Maxlength = 0
		Me._txtQuantity_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_2.MultiLine = False
		Me._txtQuantity_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_2.TabStop = True
		Me._txtQuantity_2.Visible = True
		Me._txtQuantity_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_2.Name = "_txtQuantity_2"
		Me._txtSpace2_2.AutoSize = False
		Me._txtSpace2_2.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_2.Location = New System.Drawing.Point(296, 72)
		Me._txtSpace2_2.TabIndex = 37
		Me._txtSpace2_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_2.AcceptsReturn = True
		Me._txtSpace2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_2.CausesValidation = True
		Me._txtSpace2_2.Enabled = True
		Me._txtSpace2_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_2.HideSelection = True
		Me._txtSpace2_2.ReadOnly = False
		Me._txtSpace2_2.Maxlength = 0
		Me._txtSpace2_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_2.MultiLine = False
		Me._txtSpace2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_2.TabStop = True
		Me._txtSpace2_2.Visible = True
		Me._txtSpace2_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_2.Name = "_txtSpace2_2"
		Me._txtSpace1_2.AutoSize = False
		Me._txtSpace1_2.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_2.Location = New System.Drawing.Point(104, 72)
		Me._txtSpace1_2.TabIndex = 36
		Me._txtSpace1_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_2.AcceptsReturn = True
		Me._txtSpace1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_2.CausesValidation = True
		Me._txtSpace1_2.Enabled = True
		Me._txtSpace1_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_2.HideSelection = True
		Me._txtSpace1_2.ReadOnly = False
		Me._txtSpace1_2.Maxlength = 0
		Me._txtSpace1_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_2.MultiLine = False
		Me._txtSpace1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_2.TabStop = True
		Me._txtSpace1_2.Visible = True
		Me._txtSpace1_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_2.Name = "_txtSpace1_2"
		Me._txtDescription_2.AutoSize = False
		Me._txtDescription_2.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_2.Location = New System.Drawing.Point(112, 72)
		Me._txtDescription_2.ReadOnly = True
		Me._txtDescription_2.TabIndex = 35
		Me._txtDescription_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_2.AcceptsReturn = True
		Me._txtDescription_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_2.CausesValidation = True
		Me._txtDescription_2.Enabled = True
		Me._txtDescription_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_2.HideSelection = True
		Me._txtDescription_2.Maxlength = 0
		Me._txtDescription_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_2.MultiLine = False
		Me._txtDescription_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_2.TabStop = True
		Me._txtDescription_2.Visible = True
		Me._txtDescription_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_2.Name = "_txtDescription_2"
		Me._txtItem_2.AutoSize = False
		Me._txtItem_2.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_2.Location = New System.Drawing.Point(8, 72)
		Me._txtItem_2.ReadOnly = True
		Me._txtItem_2.TabIndex = 34
		Me._txtItem_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_2.AcceptsReturn = True
		Me._txtItem_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_2.CausesValidation = True
		Me._txtItem_2.Enabled = True
		Me._txtItem_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_2.HideSelection = True
		Me._txtItem_2.Maxlength = 0
		Me._txtItem_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_2.MultiLine = False
		Me._txtItem_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_2.TabStop = True
		Me._txtItem_2.Visible = True
		Me._txtItem_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_2.Name = "_txtItem_2"
		Me._txtClosed_1.AutoSize = False
		Me._txtClosed_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_1.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_1.Location = New System.Drawing.Point(528, 56)
		Me._txtClosed_1.TabIndex = 33
		Me._txtClosed_1.AcceptsReturn = True
		Me._txtClosed_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_1.CausesValidation = True
		Me._txtClosed_1.Enabled = True
		Me._txtClosed_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_1.HideSelection = True
		Me._txtClosed_1.ReadOnly = False
		Me._txtClosed_1.Maxlength = 0
		Me._txtClosed_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_1.MultiLine = False
		Me._txtClosed_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_1.TabStop = True
		Me._txtClosed_1.Visible = True
		Me._txtClosed_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_1.Name = "_txtClosed_1"
		Me._txtReceived_1.AutoSize = False
		Me._txtReceived_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_1.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_1.Location = New System.Drawing.Point(472, 56)
		Me._txtReceived_1.TabIndex = 32
		Me._txtReceived_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_1.AcceptsReturn = True
		Me._txtReceived_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_1.CausesValidation = True
		Me._txtReceived_1.Enabled = True
		Me._txtReceived_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_1.HideSelection = True
		Me._txtReceived_1.ReadOnly = False
		Me._txtReceived_1.Maxlength = 0
		Me._txtReceived_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_1.MultiLine = False
		Me._txtReceived_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_1.TabStop = True
		Me._txtReceived_1.Visible = True
		Me._txtReceived_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_1.Name = "_txtReceived_1"
		Me._txtAmount_1.AutoSize = False
		Me._txtAmount_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_1.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_1.Location = New System.Drawing.Point(424, 56)
		Me._txtAmount_1.TabIndex = 31
		Me._txtAmount_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_1.AcceptsReturn = True
		Me._txtAmount_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_1.CausesValidation = True
		Me._txtAmount_1.Enabled = True
		Me._txtAmount_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_1.HideSelection = True
		Me._txtAmount_1.ReadOnly = False
		Me._txtAmount_1.Maxlength = 0
		Me._txtAmount_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_1.MultiLine = False
		Me._txtAmount_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_1.TabStop = True
		Me._txtAmount_1.Visible = True
		Me._txtAmount_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_1.Name = "_txtAmount_1"
		Me._txtSpace4_1.AutoSize = False
		Me._txtSpace4_1.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_1.Location = New System.Drawing.Point(416, 56)
		Me._txtSpace4_1.TabIndex = 30
		Me._txtSpace4_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_1.AcceptsReturn = True
		Me._txtSpace4_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_1.CausesValidation = True
		Me._txtSpace4_1.Enabled = True
		Me._txtSpace4_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_1.HideSelection = True
		Me._txtSpace4_1.ReadOnly = False
		Me._txtSpace4_1.Maxlength = 0
		Me._txtSpace4_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_1.MultiLine = False
		Me._txtSpace4_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_1.TabStop = True
		Me._txtSpace4_1.Visible = True
		Me._txtSpace4_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_1.Name = "_txtSpace4_1"
		Me._txtRate_1.AutoSize = False
		Me._txtRate_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_1.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_1.Location = New System.Drawing.Point(360, 56)
		Me._txtRate_1.ReadOnly = True
		Me._txtRate_1.TabIndex = 29
		Me._txtRate_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_1.AcceptsReturn = True
		Me._txtRate_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_1.CausesValidation = True
		Me._txtRate_1.Enabled = True
		Me._txtRate_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_1.HideSelection = True
		Me._txtRate_1.Maxlength = 0
		Me._txtRate_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_1.MultiLine = False
		Me._txtRate_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_1.TabStop = True
		Me._txtRate_1.Visible = True
		Me._txtRate_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_1.Name = "_txtRate_1"
		Me._txtSpace3_1.AutoSize = False
		Me._txtSpace3_1.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_1.Location = New System.Drawing.Point(352, 56)
		Me._txtSpace3_1.TabIndex = 28
		Me._txtSpace3_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_1.AcceptsReturn = True
		Me._txtSpace3_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_1.CausesValidation = True
		Me._txtSpace3_1.Enabled = True
		Me._txtSpace3_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_1.HideSelection = True
		Me._txtSpace3_1.ReadOnly = False
		Me._txtSpace3_1.Maxlength = 0
		Me._txtSpace3_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_1.MultiLine = False
		Me._txtSpace3_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_1.TabStop = True
		Me._txtSpace3_1.Visible = True
		Me._txtSpace3_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_1.Name = "_txtSpace3_1"
		Me._txtQuantity_1.AutoSize = False
		Me._txtQuantity_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_1.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_1.Location = New System.Drawing.Point(304, 56)
		Me._txtQuantity_1.ReadOnly = True
		Me._txtQuantity_1.TabIndex = 27
		Me._txtQuantity_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_1.AcceptsReturn = True
		Me._txtQuantity_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_1.CausesValidation = True
		Me._txtQuantity_1.Enabled = True
		Me._txtQuantity_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_1.HideSelection = True
		Me._txtQuantity_1.Maxlength = 0
		Me._txtQuantity_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_1.MultiLine = False
		Me._txtQuantity_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_1.TabStop = True
		Me._txtQuantity_1.Visible = True
		Me._txtQuantity_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_1.Name = "_txtQuantity_1"
		Me._txtSpace2_1.AutoSize = False
		Me._txtSpace2_1.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_1.Location = New System.Drawing.Point(296, 56)
		Me._txtSpace2_1.TabIndex = 26
		Me._txtSpace2_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_1.AcceptsReturn = True
		Me._txtSpace2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_1.CausesValidation = True
		Me._txtSpace2_1.Enabled = True
		Me._txtSpace2_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_1.HideSelection = True
		Me._txtSpace2_1.ReadOnly = False
		Me._txtSpace2_1.Maxlength = 0
		Me._txtSpace2_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_1.MultiLine = False
		Me._txtSpace2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_1.TabStop = True
		Me._txtSpace2_1.Visible = True
		Me._txtSpace2_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_1.Name = "_txtSpace2_1"
		Me._txtSpace1_1.AutoSize = False
		Me._txtSpace1_1.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_1.Location = New System.Drawing.Point(104, 56)
		Me._txtSpace1_1.TabIndex = 25
		Me._txtSpace1_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_1.AcceptsReturn = True
		Me._txtSpace1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_1.CausesValidation = True
		Me._txtSpace1_1.Enabled = True
		Me._txtSpace1_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_1.HideSelection = True
		Me._txtSpace1_1.ReadOnly = False
		Me._txtSpace1_1.Maxlength = 0
		Me._txtSpace1_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_1.MultiLine = False
		Me._txtSpace1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_1.TabStop = True
		Me._txtSpace1_1.Visible = True
		Me._txtSpace1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_1.Name = "_txtSpace1_1"
		Me._txtDescription_1.AutoSize = False
		Me._txtDescription_1.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_1.Location = New System.Drawing.Point(112, 56)
		Me._txtDescription_1.ReadOnly = True
		Me._txtDescription_1.TabIndex = 24
		Me._txtDescription_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_1.AcceptsReturn = True
		Me._txtDescription_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_1.CausesValidation = True
		Me._txtDescription_1.Enabled = True
		Me._txtDescription_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_1.HideSelection = True
		Me._txtDescription_1.Maxlength = 0
		Me._txtDescription_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_1.MultiLine = False
		Me._txtDescription_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_1.TabStop = True
		Me._txtDescription_1.Visible = True
		Me._txtDescription_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_1.Name = "_txtDescription_1"
		Me._txtItem_1.AutoSize = False
		Me._txtItem_1.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_1.Location = New System.Drawing.Point(8, 56)
		Me._txtItem_1.ReadOnly = True
		Me._txtItem_1.TabIndex = 23
		Me._txtItem_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_1.AcceptsReturn = True
		Me._txtItem_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_1.CausesValidation = True
		Me._txtItem_1.Enabled = True
		Me._txtItem_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_1.HideSelection = True
		Me._txtItem_1.Maxlength = 0
		Me._txtItem_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_1.MultiLine = False
		Me._txtItem_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_1.TabStop = True
		Me._txtItem_1.Visible = True
		Me._txtItem_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_1.Name = "_txtItem_1"
		Me._txtClosed_0.AutoSize = False
		Me._txtClosed_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me._txtClosed_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtClosed_0.Size = New System.Drawing.Size(33, 19)
		Me._txtClosed_0.Location = New System.Drawing.Point(528, 40)
		Me._txtClosed_0.TabIndex = 22
		Me._txtClosed_0.AcceptsReturn = True
		Me._txtClosed_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtClosed_0.CausesValidation = True
		Me._txtClosed_0.Enabled = True
		Me._txtClosed_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtClosed_0.HideSelection = True
		Me._txtClosed_0.ReadOnly = False
		Me._txtClosed_0.Maxlength = 0
		Me._txtClosed_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtClosed_0.MultiLine = False
		Me._txtClosed_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtClosed_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtClosed_0.TabStop = True
		Me._txtClosed_0.Visible = True
		Me._txtClosed_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtClosed_0.Name = "_txtClosed_0"
		Me._txtReceived_0.AutoSize = False
		Me._txtReceived_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtReceived_0.Size = New System.Drawing.Size(57, 19)
		Me._txtReceived_0.Location = New System.Drawing.Point(472, 40)
		Me._txtReceived_0.TabIndex = 21
		Me._txtReceived_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtReceived_0.AcceptsReturn = True
		Me._txtReceived_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtReceived_0.CausesValidation = True
		Me._txtReceived_0.Enabled = True
		Me._txtReceived_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtReceived_0.HideSelection = True
		Me._txtReceived_0.ReadOnly = False
		Me._txtReceived_0.Maxlength = 0
		Me._txtReceived_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtReceived_0.MultiLine = False
		Me._txtReceived_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtReceived_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtReceived_0.TabStop = True
		Me._txtReceived_0.Visible = True
		Me._txtReceived_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtReceived_0.Name = "_txtReceived_0"
		Me._txtAmount_0.AutoSize = False
		Me._txtAmount_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtAmount_0.Size = New System.Drawing.Size(49, 19)
		Me._txtAmount_0.Location = New System.Drawing.Point(424, 40)
		Me._txtAmount_0.TabIndex = 20
		Me._txtAmount_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtAmount_0.AcceptsReturn = True
		Me._txtAmount_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtAmount_0.CausesValidation = True
		Me._txtAmount_0.Enabled = True
		Me._txtAmount_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAmount_0.HideSelection = True
		Me._txtAmount_0.ReadOnly = False
		Me._txtAmount_0.Maxlength = 0
		Me._txtAmount_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAmount_0.MultiLine = False
		Me._txtAmount_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAmount_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAmount_0.TabStop = True
		Me._txtAmount_0.Visible = True
		Me._txtAmount_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtAmount_0.Name = "_txtAmount_0"
		Me._txtSpace4_0.AutoSize = False
		Me._txtSpace4_0.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace4_0.Location = New System.Drawing.Point(416, 40)
		Me._txtSpace4_0.TabIndex = 19
		Me._txtSpace4_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace4_0.AcceptsReturn = True
		Me._txtSpace4_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace4_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace4_0.CausesValidation = True
		Me._txtSpace4_0.Enabled = True
		Me._txtSpace4_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace4_0.HideSelection = True
		Me._txtSpace4_0.ReadOnly = False
		Me._txtSpace4_0.Maxlength = 0
		Me._txtSpace4_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace4_0.MultiLine = False
		Me._txtSpace4_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace4_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace4_0.TabStop = True
		Me._txtSpace4_0.Visible = True
		Me._txtSpace4_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace4_0.Name = "_txtSpace4_0"
		Me._txtRate_0.AutoSize = False
		Me._txtRate_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtRate_0.Size = New System.Drawing.Size(57, 19)
		Me._txtRate_0.Location = New System.Drawing.Point(360, 40)
		Me._txtRate_0.ReadOnly = True
		Me._txtRate_0.TabIndex = 18
		Me._txtRate_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtRate_0.AcceptsReturn = True
		Me._txtRate_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtRate_0.CausesValidation = True
		Me._txtRate_0.Enabled = True
		Me._txtRate_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtRate_0.HideSelection = True
		Me._txtRate_0.Maxlength = 0
		Me._txtRate_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtRate_0.MultiLine = False
		Me._txtRate_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtRate_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtRate_0.TabStop = True
		Me._txtRate_0.Visible = True
		Me._txtRate_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtRate_0.Name = "_txtRate_0"
		Me._txtSpace3_0.AutoSize = False
		Me._txtSpace3_0.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace3_0.Location = New System.Drawing.Point(352, 40)
		Me._txtSpace3_0.TabIndex = 17
		Me._txtSpace3_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace3_0.AcceptsReturn = True
		Me._txtSpace3_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace3_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace3_0.CausesValidation = True
		Me._txtSpace3_0.Enabled = True
		Me._txtSpace3_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace3_0.HideSelection = True
		Me._txtSpace3_0.ReadOnly = False
		Me._txtSpace3_0.Maxlength = 0
		Me._txtSpace3_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace3_0.MultiLine = False
		Me._txtSpace3_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace3_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace3_0.TabStop = True
		Me._txtSpace3_0.Visible = True
		Me._txtSpace3_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace3_0.Name = "_txtSpace3_0"
		Me._txtQuantity_0.AutoSize = False
		Me._txtQuantity_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtQuantity_0.Size = New System.Drawing.Size(49, 19)
		Me._txtQuantity_0.Location = New System.Drawing.Point(304, 40)
		Me._txtQuantity_0.ReadOnly = True
		Me._txtQuantity_0.TabIndex = 16
		Me._txtQuantity_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtQuantity_0.AcceptsReturn = True
		Me._txtQuantity_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtQuantity_0.CausesValidation = True
		Me._txtQuantity_0.Enabled = True
		Me._txtQuantity_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtQuantity_0.HideSelection = True
		Me._txtQuantity_0.Maxlength = 0
		Me._txtQuantity_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtQuantity_0.MultiLine = False
		Me._txtQuantity_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtQuantity_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtQuantity_0.TabStop = True
		Me._txtQuantity_0.Visible = True
		Me._txtQuantity_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtQuantity_0.Name = "_txtQuantity_0"
		Me._txtSpace2_0.AutoSize = False
		Me._txtSpace2_0.Size = New System.Drawing.Size(10, 19)
		Me._txtSpace2_0.Location = New System.Drawing.Point(296, 40)
		Me._txtSpace2_0.TabIndex = 15
		Me._txtSpace2_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_0.AcceptsReturn = True
		Me._txtSpace2_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_0.CausesValidation = True
		Me._txtSpace2_0.Enabled = True
		Me._txtSpace2_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_0.HideSelection = True
		Me._txtSpace2_0.ReadOnly = False
		Me._txtSpace2_0.Maxlength = 0
		Me._txtSpace2_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_0.MultiLine = False
		Me._txtSpace2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_0.TabStop = True
		Me._txtSpace2_0.Visible = True
		Me._txtSpace2_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_0.Name = "_txtSpace2_0"
		Me._txtSpace1_0.AutoSize = False
		Me._txtSpace1_0.Size = New System.Drawing.Size(9, 19)
		Me._txtSpace1_0.Location = New System.Drawing.Point(104, 40)
		Me._txtSpace1_0.TabIndex = 14
		Me._txtSpace1_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_0.AcceptsReturn = True
		Me._txtSpace1_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_0.CausesValidation = True
		Me._txtSpace1_0.Enabled = True
		Me._txtSpace1_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_0.HideSelection = True
		Me._txtSpace1_0.ReadOnly = False
		Me._txtSpace1_0.Maxlength = 0
		Me._txtSpace1_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_0.MultiLine = False
		Me._txtSpace1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_0.TabStop = True
		Me._txtSpace1_0.Visible = True
		Me._txtSpace1_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_0.Name = "_txtSpace1_0"
		Me._txtDescription_0.AutoSize = False
		Me._txtDescription_0.Size = New System.Drawing.Size(185, 19)
		Me._txtDescription_0.Location = New System.Drawing.Point(112, 40)
		Me._txtDescription_0.ReadOnly = True
		Me._txtDescription_0.TabIndex = 13
		Me._txtDescription_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtDescription_0.AcceptsReturn = True
		Me._txtDescription_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtDescription_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtDescription_0.CausesValidation = True
		Me._txtDescription_0.Enabled = True
		Me._txtDescription_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtDescription_0.HideSelection = True
		Me._txtDescription_0.Maxlength = 0
		Me._txtDescription_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtDescription_0.MultiLine = False
		Me._txtDescription_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtDescription_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtDescription_0.TabStop = True
		Me._txtDescription_0.Visible = True
		Me._txtDescription_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtDescription_0.Name = "_txtDescription_0"
		Me._txtItem_0.AutoSize = False
		Me._txtItem_0.Size = New System.Drawing.Size(96, 19)
		Me._txtItem_0.Location = New System.Drawing.Point(8, 40)
		Me._txtItem_0.ReadOnly = True
		Me._txtItem_0.TabIndex = 12
		Me._txtItem_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtItem_0.AcceptsReturn = True
		Me._txtItem_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtItem_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtItem_0.CausesValidation = True
		Me._txtItem_0.Enabled = True
		Me._txtItem_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtItem_0.HideSelection = True
		Me._txtItem_0.Maxlength = 0
		Me._txtItem_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtItem_0.MultiLine = False
		Me._txtItem_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtItem_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtItem_0.TabStop = True
		Me._txtItem_0.Visible = True
		Me._txtItem_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtItem_0.Name = "_txtItem_0"
		Me.Label6.Text = "Item"
		Me.Label6.Size = New System.Drawing.Size(49, 17)
		Me.Label6.Location = New System.Drawing.Point(8, 24)
		Me.Label6.TabIndex = 128
		Me.Label6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label6.BackColor = System.Drawing.SystemColors.Control
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label7.Text = "Description"
		Me.Label7.Size = New System.Drawing.Size(81, 17)
		Me.Label7.Location = New System.Drawing.Point(112, 24)
		Me.Label7.TabIndex = 127
		Me.Label7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label7.BackColor = System.Drawing.SystemColors.Control
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label8.Text = "Quantity"
		Me.Label8.Size = New System.Drawing.Size(41, 17)
		Me.Label8.Location = New System.Drawing.Point(312, 24)
		Me.Label8.TabIndex = 126
		Me.Label8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label8.BackColor = System.Drawing.SystemColors.Control
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label9.Text = "Rate"
		Me.Label9.Size = New System.Drawing.Size(25, 17)
		Me.Label9.Location = New System.Drawing.Point(392, 24)
		Me.Label9.TabIndex = 125
		Me.Label9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label9.BackColor = System.Drawing.SystemColors.Control
		Me.Label9.Enabled = True
		Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Label11.Text = "Amount"
		Me.Label11.Size = New System.Drawing.Size(41, 17)
		Me.Label11.Location = New System.Drawing.Point(432, 24)
		Me.Label11.TabIndex = 124
		Me.Label11.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label11.BackColor = System.Drawing.SystemColors.Control
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Label12.Text = "Received"
		Me.Label12.Size = New System.Drawing.Size(49, 17)
		Me.Label12.Location = New System.Drawing.Point(480, 24)
		Me.Label12.TabIndex = 123
		Me.Label12.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label12.BackColor = System.Drawing.SystemColors.Control
		Me.Label12.Enabled = True
		Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label13.Text = "Closed"
		Me.Label13.Size = New System.Drawing.Size(33, 17)
		Me.Label13.Location = New System.Drawing.Point(528, 24)
		Me.Label13.TabIndex = 122
		Me.Label13.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.BackColor = System.Drawing.SystemColors.Control
		Me.Label13.Enabled = True
		Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label13.UseMnemonic = True
		Me.Label13.Visible = True
		Me.Label13.AutoSize = False
		Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label13.Name = "Label13"
		Me.vscPOLineScroll.Size = New System.Drawing.Size(17, 161)
		Me.vscPOLineScroll.LargeChange = 10
		Me.vscPOLineScroll.Location = New System.Drawing.Point(592, 136)
		Me.vscPOLineScroll.TabIndex = 10
		Me.vscPOLineScroll.CausesValidation = True
		Me.vscPOLineScroll.Enabled = True
		Me.vscPOLineScroll.Maximum = 32776
		Me.vscPOLineScroll.Minimum = 0
		Me.vscPOLineScroll.Cursor = System.Windows.Forms.Cursors.Default
		Me.vscPOLineScroll.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.vscPOLineScroll.SmallChange = 1
		Me.vscPOLineScroll.TabStop = True
		Me.vscPOLineScroll.Value = 0
		Me.vscPOLineScroll.Visible = True
		Me.vscPOLineScroll.Name = "vscPOLineScroll"
		Me.txtVendor.AutoSize = False
		Me.txtVendor.Size = New System.Drawing.Size(305, 19)
		Me.txtVendor.Location = New System.Drawing.Point(48, 64)
		Me.txtVendor.ReadOnly = True
		Me.txtVendor.TabIndex = 9
		Me.txtVendor.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtVendor.AcceptsReturn = True
		Me.txtVendor.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtVendor.BackColor = System.Drawing.SystemColors.Window
		Me.txtVendor.CausesValidation = True
		Me.txtVendor.Enabled = True
		Me.txtVendor.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtVendor.HideSelection = True
		Me.txtVendor.Maxlength = 0
		Me.txtVendor.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtVendor.MultiLine = False
		Me.txtVendor.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtVendor.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtVendor.TabStop = True
		Me.txtVendor.Visible = True
		Me.txtVendor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtVendor.Name = "txtVendor"
		Me.txtRefNumber.AutoSize = False
		Me.txtRefNumber.Size = New System.Drawing.Size(129, 19)
		Me.txtRefNumber.Location = New System.Drawing.Point(48, 40)
		Me.txtRefNumber.ReadOnly = True
		Me.txtRefNumber.TabIndex = 5
		Me.txtRefNumber.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtRefNumber.AcceptsReturn = True
		Me.txtRefNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtRefNumber.BackColor = System.Drawing.SystemColors.Window
		Me.txtRefNumber.CausesValidation = True
		Me.txtRefNumber.Enabled = True
		Me.txtRefNumber.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtRefNumber.HideSelection = True
		Me.txtRefNumber.Maxlength = 0
		Me.txtRefNumber.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtRefNumber.MultiLine = False
		Me.txtRefNumber.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtRefNumber.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtRefNumber.TabStop = True
		Me.txtRefNumber.Visible = True
		Me.txtRefNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtRefNumber.Name = "txtRefNumber"
		Me.txtTxnDate.AutoSize = False
		Me.txtTxnDate.Size = New System.Drawing.Size(89, 19)
		Me.txtTxnDate.Location = New System.Drawing.Point(240, 40)
		Me.txtTxnDate.ReadOnly = True
		Me.txtTxnDate.TabIndex = 4
		Me.txtTxnDate.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTxnDate.AcceptsReturn = True
		Me.txtTxnDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTxnDate.BackColor = System.Drawing.SystemColors.Window
		Me.txtTxnDate.CausesValidation = True
		Me.txtTxnDate.Enabled = True
		Me.txtTxnDate.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTxnDate.HideSelection = True
		Me.txtTxnDate.Maxlength = 0
		Me.txtTxnDate.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTxnDate.MultiLine = False
		Me.txtTxnDate.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTxnDate.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtTxnDate.TabStop = True
		Me.txtTxnDate.Visible = True
		Me.txtTxnDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTxnDate.Name = "txtTxnDate"
		Me.txtTxnID.AutoSize = False
		Me.txtTxnID.Size = New System.Drawing.Size(177, 19)
		Me.txtTxnID.Location = New System.Drawing.Point(48, 8)
		Me.txtTxnID.ReadOnly = True
		Me.txtTxnID.TabIndex = 1
		Me.txtTxnID.TabStop = False
		Me.txtTxnID.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTxnID.AcceptsReturn = True
		Me.txtTxnID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTxnID.BackColor = System.Drawing.SystemColors.Window
		Me.txtTxnID.CausesValidation = True
		Me.txtTxnID.Enabled = True
		Me.txtTxnID.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTxnID.HideSelection = True
		Me.txtTxnID.Maxlength = 0
		Me.txtTxnID.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTxnID.MultiLine = False
		Me.txtTxnID.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTxnID.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtTxnID.Visible = True
		Me.txtTxnID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTxnID.Name = "txtTxnID"
		Me.txtEditSequence.AutoSize = False
		Me.txtEditSequence.Size = New System.Drawing.Size(193, 19)
		Me.txtEditSequence.Location = New System.Drawing.Point(328, 8)
		Me.txtEditSequence.ReadOnly = True
		Me.txtEditSequence.TabIndex = 0
		Me.txtEditSequence.TabStop = False
		Me.txtEditSequence.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtEditSequence.AcceptsReturn = True
		Me.txtEditSequence.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtEditSequence.BackColor = System.Drawing.SystemColors.Window
		Me.txtEditSequence.CausesValidation = True
		Me.txtEditSequence.Enabled = True
		Me.txtEditSequence.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtEditSequence.HideSelection = True
		Me.txtEditSequence.Maxlength = 0
		Me.txtEditSequence.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtEditSequence.MultiLine = False
		Me.txtEditSequence.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtEditSequence.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtEditSequence.Visible = True
		Me.txtEditSequence.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtEditSequence.Name = "txtEditSequence"
		Me.Label3.Text = "Vendor"
		Me.Label3.Size = New System.Drawing.Size(49, 17)
		Me.Label3.Location = New System.Drawing.Point(8, 64)
		Me.Label3.TabIndex = 8
		Me.Label3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label4.Text = "PO #"
		Me.Label4.Size = New System.Drawing.Size(49, 17)
		Me.Label4.Location = New System.Drawing.Point(8, 40)
		Me.Label4.TabIndex = 7
		Me.Label4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label5.Text = "Date"
		Me.Label5.Size = New System.Drawing.Size(33, 17)
		Me.Label5.Location = New System.Drawing.Point(200, 40)
		Me.Label5.TabIndex = 6
		Me.Label5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label1.Text = "TxnID"
		Me.Label1.Size = New System.Drawing.Size(33, 17)
		Me.Label1.Location = New System.Drawing.Point(8, 8)
		Me.Label1.TabIndex = 3
		Me.Label1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Label2.Text = "Edit Sequence"
		Me.Label2.Size = New System.Drawing.Size(73, 17)
		Me.Label2.Location = New System.Drawing.Point(248, 8)
		Me.Label2.TabIndex = 2
		Me.Label2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Controls.Add(cmdExit)
		Me.Controls.Add(cmdReturn)
		Me.Controls.Add(cmdCloseLine)
		Me.Controls.Add(cmdCloseAll)
		Me.Controls.Add(cmdReceiveOne)
		Me.Controls.Add(cmdReceiveAll)
		Me.Controls.Add(Frame1)
		Me.Controls.Add(vscPOLineScroll)
		Me.Controls.Add(txtVendor)
		Me.Controls.Add(txtRefNumber)
		Me.Controls.Add(txtTxnDate)
		Me.Controls.Add(txtTxnID)
		Me.Controls.Add(txtEditSequence)
		Me.Controls.Add(Label3)
		Me.Controls.Add(Label4)
		Me.Controls.Add(Label5)
		Me.Controls.Add(Label1)
		Me.Controls.Add(Label2)
		Me.Frame1.Controls.Add(_txtClosed_9)
		Me.Frame1.Controls.Add(_txtReceived_9)
		Me.Frame1.Controls.Add(_txtAmount_9)
		Me.Frame1.Controls.Add(_txtSpace4_9)
		Me.Frame1.Controls.Add(_txtRate_9)
		Me.Frame1.Controls.Add(_txtSpace3_9)
		Me.Frame1.Controls.Add(_txtQuantity_9)
		Me.Frame1.Controls.Add(_txtSpace2_9)
		Me.Frame1.Controls.Add(_txtSpace1_9)
		Me.Frame1.Controls.Add(_txtDescription_9)
		Me.Frame1.Controls.Add(_txtItem_9)
		Me.Frame1.Controls.Add(_txtClosed_8)
		Me.Frame1.Controls.Add(_txtReceived_8)
		Me.Frame1.Controls.Add(_txtAmount_8)
		Me.Frame1.Controls.Add(_txtSpace4_8)
		Me.Frame1.Controls.Add(_txtRate_8)
		Me.Frame1.Controls.Add(_txtSpace3_8)
		Me.Frame1.Controls.Add(_txtQuantity_8)
		Me.Frame1.Controls.Add(_txtSpace2_8)
		Me.Frame1.Controls.Add(_txtSpace1_8)
		Me.Frame1.Controls.Add(_txtDescription_8)
		Me.Frame1.Controls.Add(_txtItem_8)
		Me.Frame1.Controls.Add(_txtClosed_7)
		Me.Frame1.Controls.Add(_txtReceived_7)
		Me.Frame1.Controls.Add(_txtAmount_7)
		Me.Frame1.Controls.Add(_txtSpace4_7)
		Me.Frame1.Controls.Add(_txtRate_7)
		Me.Frame1.Controls.Add(_txtSpace3_7)
		Me.Frame1.Controls.Add(_txtQuantity_7)
		Me.Frame1.Controls.Add(_txtSpace2_7)
		Me.Frame1.Controls.Add(_txtSpace1_7)
		Me.Frame1.Controls.Add(_txtDescription_7)
		Me.Frame1.Controls.Add(_txtItem_7)
		Me.Frame1.Controls.Add(_txtClosed_6)
		Me.Frame1.Controls.Add(_txtReceived_6)
		Me.Frame1.Controls.Add(_txtAmount_6)
		Me.Frame1.Controls.Add(_txtSpace4_6)
		Me.Frame1.Controls.Add(_txtRate_6)
		Me.Frame1.Controls.Add(_txtSpace3_6)
		Me.Frame1.Controls.Add(_txtQuantity_6)
		Me.Frame1.Controls.Add(_txtSpace2_6)
		Me.Frame1.Controls.Add(_txtSpace1_6)
		Me.Frame1.Controls.Add(_txtDescription_6)
		Me.Frame1.Controls.Add(_txtItem_6)
		Me.Frame1.Controls.Add(_txtClosed_5)
		Me.Frame1.Controls.Add(_txtReceived_5)
		Me.Frame1.Controls.Add(_txtAmount_5)
		Me.Frame1.Controls.Add(_txtSpace4_5)
		Me.Frame1.Controls.Add(_txtRate_5)
		Me.Frame1.Controls.Add(_txtSpace3_5)
		Me.Frame1.Controls.Add(_txtQuantity_5)
		Me.Frame1.Controls.Add(_txtSpace2_5)
		Me.Frame1.Controls.Add(_txtSpace1_5)
		Me.Frame1.Controls.Add(_txtDescription_5)
		Me.Frame1.Controls.Add(_txtItem_5)
		Me.Frame1.Controls.Add(_txtClosed_4)
		Me.Frame1.Controls.Add(_txtReceived_4)
		Me.Frame1.Controls.Add(_txtAmount_4)
		Me.Frame1.Controls.Add(_txtSpace4_4)
		Me.Frame1.Controls.Add(_txtRate_4)
		Me.Frame1.Controls.Add(_txtSpace3_4)
		Me.Frame1.Controls.Add(_txtQuantity_4)
		Me.Frame1.Controls.Add(_txtSpace2_4)
		Me.Frame1.Controls.Add(_txtSpace1_4)
		Me.Frame1.Controls.Add(_txtDescription_4)
		Me.Frame1.Controls.Add(_txtItem_4)
		Me.Frame1.Controls.Add(_txtClosed_3)
		Me.Frame1.Controls.Add(_txtReceived_3)
		Me.Frame1.Controls.Add(_txtAmount_3)
		Me.Frame1.Controls.Add(_txtSpace4_3)
		Me.Frame1.Controls.Add(_txtRate_3)
		Me.Frame1.Controls.Add(_txtSpace3_3)
		Me.Frame1.Controls.Add(_txtQuantity_3)
		Me.Frame1.Controls.Add(_txtSpace2_3)
		Me.Frame1.Controls.Add(_txtSpace1_3)
		Me.Frame1.Controls.Add(_txtDescription_3)
		Me.Frame1.Controls.Add(_txtItem_3)
		Me.Frame1.Controls.Add(_txtClosed_2)
		Me.Frame1.Controls.Add(_txtReceived_2)
		Me.Frame1.Controls.Add(_txtAmount_2)
		Me.Frame1.Controls.Add(_txtSpace4_2)
		Me.Frame1.Controls.Add(_txtRate_2)
		Me.Frame1.Controls.Add(_txtSpace3_2)
		Me.Frame1.Controls.Add(_txtQuantity_2)
		Me.Frame1.Controls.Add(_txtSpace2_2)
		Me.Frame1.Controls.Add(_txtSpace1_2)
		Me.Frame1.Controls.Add(_txtDescription_2)
		Me.Frame1.Controls.Add(_txtItem_2)
		Me.Frame1.Controls.Add(_txtClosed_1)
		Me.Frame1.Controls.Add(_txtReceived_1)
		Me.Frame1.Controls.Add(_txtAmount_1)
		Me.Frame1.Controls.Add(_txtSpace4_1)
		Me.Frame1.Controls.Add(_txtRate_1)
		Me.Frame1.Controls.Add(_txtSpace3_1)
		Me.Frame1.Controls.Add(_txtQuantity_1)
		Me.Frame1.Controls.Add(_txtSpace2_1)
		Me.Frame1.Controls.Add(_txtSpace1_1)
		Me.Frame1.Controls.Add(_txtDescription_1)
		Me.Frame1.Controls.Add(_txtItem_1)
		Me.Frame1.Controls.Add(_txtClosed_0)
		Me.Frame1.Controls.Add(_txtReceived_0)
		Me.Frame1.Controls.Add(_txtAmount_0)
		Me.Frame1.Controls.Add(_txtSpace4_0)
		Me.Frame1.Controls.Add(_txtRate_0)
		Me.Frame1.Controls.Add(_txtSpace3_0)
		Me.Frame1.Controls.Add(_txtQuantity_0)
		Me.Frame1.Controls.Add(_txtSpace2_0)
		Me.Frame1.Controls.Add(_txtSpace1_0)
		Me.Frame1.Controls.Add(_txtDescription_0)
		Me.Frame1.Controls.Add(_txtItem_0)
		Me.Frame1.Controls.Add(Label6)
		Me.Frame1.Controls.Add(Label7)
		Me.Frame1.Controls.Add(Label8)
		Me.Frame1.Controls.Add(Label9)
		Me.Frame1.Controls.Add(Label11)
		Me.Frame1.Controls.Add(Label12)
		Me.Frame1.Controls.Add(Label13)
		Me.txtAmount.SetIndex(_txtAmount_9, CType(9, Short))
		Me.txtAmount.SetIndex(_txtAmount_8, CType(8, Short))
		Me.txtAmount.SetIndex(_txtAmount_7, CType(7, Short))
		Me.txtAmount.SetIndex(_txtAmount_6, CType(6, Short))
		Me.txtAmount.SetIndex(_txtAmount_5, CType(5, Short))
		Me.txtAmount.SetIndex(_txtAmount_4, CType(4, Short))
		Me.txtAmount.SetIndex(_txtAmount_3, CType(3, Short))
		Me.txtAmount.SetIndex(_txtAmount_2, CType(2, Short))
		Me.txtAmount.SetIndex(_txtAmount_1, CType(1, Short))
		Me.txtAmount.SetIndex(_txtAmount_0, CType(0, Short))
		Me.txtClosed.SetIndex(_txtClosed_9, CType(9, Short))
		Me.txtClosed.SetIndex(_txtClosed_8, CType(8, Short))
		Me.txtClosed.SetIndex(_txtClosed_7, CType(7, Short))
		Me.txtClosed.SetIndex(_txtClosed_6, CType(6, Short))
		Me.txtClosed.SetIndex(_txtClosed_5, CType(5, Short))
		Me.txtClosed.SetIndex(_txtClosed_4, CType(4, Short))
		Me.txtClosed.SetIndex(_txtClosed_3, CType(3, Short))
		Me.txtClosed.SetIndex(_txtClosed_2, CType(2, Short))
		Me.txtClosed.SetIndex(_txtClosed_1, CType(1, Short))
		Me.txtClosed.SetIndex(_txtClosed_0, CType(0, Short))
		Me.txtDescription.SetIndex(_txtDescription_9, CType(9, Short))
		Me.txtDescription.SetIndex(_txtDescription_8, CType(8, Short))
		Me.txtDescription.SetIndex(_txtDescription_7, CType(7, Short))
		Me.txtDescription.SetIndex(_txtDescription_6, CType(6, Short))
		Me.txtDescription.SetIndex(_txtDescription_5, CType(5, Short))
		Me.txtDescription.SetIndex(_txtDescription_4, CType(4, Short))
		Me.txtDescription.SetIndex(_txtDescription_3, CType(3, Short))
		Me.txtDescription.SetIndex(_txtDescription_2, CType(2, Short))
		Me.txtDescription.SetIndex(_txtDescription_1, CType(1, Short))
		Me.txtDescription.SetIndex(_txtDescription_0, CType(0, Short))
		Me.txtItem.SetIndex(_txtItem_9, CType(9, Short))
		Me.txtItem.SetIndex(_txtItem_8, CType(8, Short))
		Me.txtItem.SetIndex(_txtItem_7, CType(7, Short))
		Me.txtItem.SetIndex(_txtItem_6, CType(6, Short))
		Me.txtItem.SetIndex(_txtItem_5, CType(5, Short))
		Me.txtItem.SetIndex(_txtItem_4, CType(4, Short))
		Me.txtItem.SetIndex(_txtItem_3, CType(3, Short))
		Me.txtItem.SetIndex(_txtItem_2, CType(2, Short))
		Me.txtItem.SetIndex(_txtItem_1, CType(1, Short))
		Me.txtItem.SetIndex(_txtItem_0, CType(0, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_9, CType(9, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_8, CType(8, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_7, CType(7, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_6, CType(6, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_5, CType(5, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_4, CType(4, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_3, CType(3, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_2, CType(2, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_1, CType(1, Short))
		Me.txtQuantity.SetIndex(_txtQuantity_0, CType(0, Short))
		Me.txtRate.SetIndex(_txtRate_9, CType(9, Short))
		Me.txtRate.SetIndex(_txtRate_8, CType(8, Short))
		Me.txtRate.SetIndex(_txtRate_7, CType(7, Short))
		Me.txtRate.SetIndex(_txtRate_6, CType(6, Short))
		Me.txtRate.SetIndex(_txtRate_5, CType(5, Short))
		Me.txtRate.SetIndex(_txtRate_4, CType(4, Short))
		Me.txtRate.SetIndex(_txtRate_3, CType(3, Short))
		Me.txtRate.SetIndex(_txtRate_2, CType(2, Short))
		Me.txtRate.SetIndex(_txtRate_1, CType(1, Short))
		Me.txtRate.SetIndex(_txtRate_0, CType(0, Short))
		Me.txtReceived.SetIndex(_txtReceived_9, CType(9, Short))
		Me.txtReceived.SetIndex(_txtReceived_8, CType(8, Short))
		Me.txtReceived.SetIndex(_txtReceived_7, CType(7, Short))
		Me.txtReceived.SetIndex(_txtReceived_6, CType(6, Short))
		Me.txtReceived.SetIndex(_txtReceived_5, CType(5, Short))
		Me.txtReceived.SetIndex(_txtReceived_4, CType(4, Short))
		Me.txtReceived.SetIndex(_txtReceived_3, CType(3, Short))
		Me.txtReceived.SetIndex(_txtReceived_2, CType(2, Short))
		Me.txtReceived.SetIndex(_txtReceived_1, CType(1, Short))
		Me.txtReceived.SetIndex(_txtReceived_0, CType(0, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_9, CType(9, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_8, CType(8, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_7, CType(7, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_6, CType(6, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_5, CType(5, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_4, CType(4, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_3, CType(3, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_2, CType(2, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_1, CType(1, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_0, CType(0, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_9, CType(9, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_8, CType(8, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_7, CType(7, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_6, CType(6, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_5, CType(5, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_4, CType(4, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_3, CType(3, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_2, CType(2, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_1, CType(1, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_0, CType(0, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_9, CType(9, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_8, CType(8, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_7, CType(7, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_6, CType(6, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_5, CType(5, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_4, CType(4, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_3, CType(3, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_2, CType(2, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_1, CType(1, Short))
		Me.txtSpace3.SetIndex(_txtSpace3_0, CType(0, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_9, CType(9, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_8, CType(8, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_7, CType(7, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_6, CType(6, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_5, CType(5, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_4, CType(4, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_3, CType(3, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_2, CType(2, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_1, CType(1, Short))
		Me.txtSpace4.SetIndex(_txtSpace4_0, CType(0, Short))
		CType(Me.txtSpace4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtSpace3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtSpace2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtReceived, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtRate, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtItem, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtClosed, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Frame1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class