<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmPurchaseOrderSelect
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdPODetails As System.Windows.Forms.Button
	Public WithEvents _txtSpace2_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace2_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtSpace1_0 As System.Windows.Forms.TextBox
	Public WithEvents cmdExit As System.Windows.Forms.Button
	Public WithEvents vscPOScroll As System.Windows.Forms.VScrollBar
	Public WithEvents _txtPOAmount_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_9 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_8 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_1 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOAmount_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODeliveryDate_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtPOVendor_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtPODate_0 As System.Windows.Forms.TextBox
	Public WithEvents _txtPONumber_0 As System.Windows.Forms.TextBox
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents txtPOAmount As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtPODate As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtPODeliveryDate As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtPONumber As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtPOVendor As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace1 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	Public WithEvents txtSpace2 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPurchaseOrderSelect))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.cmdPODetails = New System.Windows.Forms.Button
		Me._txtSpace2_9 = New System.Windows.Forms.TextBox
		Me._txtSpace1_9 = New System.Windows.Forms.TextBox
		Me._txtSpace2_8 = New System.Windows.Forms.TextBox
		Me._txtSpace1_8 = New System.Windows.Forms.TextBox
		Me._txtSpace2_7 = New System.Windows.Forms.TextBox
		Me._txtSpace1_7 = New System.Windows.Forms.TextBox
		Me._txtSpace2_6 = New System.Windows.Forms.TextBox
		Me._txtSpace1_6 = New System.Windows.Forms.TextBox
		Me._txtSpace2_5 = New System.Windows.Forms.TextBox
		Me._txtSpace1_5 = New System.Windows.Forms.TextBox
		Me._txtSpace2_4 = New System.Windows.Forms.TextBox
		Me._txtSpace1_4 = New System.Windows.Forms.TextBox
		Me._txtSpace2_3 = New System.Windows.Forms.TextBox
		Me._txtSpace1_3 = New System.Windows.Forms.TextBox
		Me._txtSpace2_2 = New System.Windows.Forms.TextBox
		Me._txtSpace1_2 = New System.Windows.Forms.TextBox
		Me._txtSpace2_1 = New System.Windows.Forms.TextBox
		Me._txtSpace1_1 = New System.Windows.Forms.TextBox
		Me._txtSpace2_0 = New System.Windows.Forms.TextBox
		Me._txtSpace1_0 = New System.Windows.Forms.TextBox
		Me.cmdExit = New System.Windows.Forms.Button
		Me.vscPOScroll = New System.Windows.Forms.VScrollBar
		Me._txtPOAmount_9 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_9 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_9 = New System.Windows.Forms.TextBox
		Me._txtPODate_9 = New System.Windows.Forms.TextBox
		Me._txtPONumber_9 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_8 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_8 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_8 = New System.Windows.Forms.TextBox
		Me._txtPODate_8 = New System.Windows.Forms.TextBox
		Me._txtPONumber_8 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_7 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_7 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_7 = New System.Windows.Forms.TextBox
		Me._txtPODate_7 = New System.Windows.Forms.TextBox
		Me._txtPONumber_7 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_6 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_6 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_6 = New System.Windows.Forms.TextBox
		Me._txtPODate_6 = New System.Windows.Forms.TextBox
		Me._txtPONumber_6 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_5 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_5 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_5 = New System.Windows.Forms.TextBox
		Me._txtPODate_5 = New System.Windows.Forms.TextBox
		Me._txtPONumber_5 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_4 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_4 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_4 = New System.Windows.Forms.TextBox
		Me._txtPODate_4 = New System.Windows.Forms.TextBox
		Me._txtPONumber_4 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_3 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_3 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_3 = New System.Windows.Forms.TextBox
		Me._txtPODate_3 = New System.Windows.Forms.TextBox
		Me._txtPONumber_3 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_2 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_2 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_2 = New System.Windows.Forms.TextBox
		Me._txtPODate_2 = New System.Windows.Forms.TextBox
		Me._txtPONumber_2 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_1 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_1 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_1 = New System.Windows.Forms.TextBox
		Me._txtPODate_1 = New System.Windows.Forms.TextBox
		Me._txtPONumber_1 = New System.Windows.Forms.TextBox
		Me._txtPOAmount_0 = New System.Windows.Forms.TextBox
		Me._txtPODeliveryDate_0 = New System.Windows.Forms.TextBox
		Me._txtPOVendor_0 = New System.Windows.Forms.TextBox
		Me._txtPODate_0 = New System.Windows.Forms.TextBox
		Me._txtPONumber_0 = New System.Windows.Forms.TextBox
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.txtPOAmount = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtPODate = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtPODeliveryDate = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtPONumber = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtPOVendor = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace1 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.txtSpace2 = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.txtPOAmount, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtPODate, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtPODeliveryDate, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtPONumber, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtPOVendor, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtSpace2, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.Text = "Select A Purchase Order for Modify"
		Me.ClientSize = New System.Drawing.Size(631, 307)
		Me.Location = New System.Drawing.Point(213, 234)
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmPurchaseOrderSelect"
		Me.cmdPODetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdPODetails.Text = "View Purchase Order Details"
		Me.cmdPODetails.Size = New System.Drawing.Size(105, 49)
		Me.cmdPODetails.Location = New System.Drawing.Point(16, 240)
		Me.cmdPODetails.TabIndex = 77
		Me.cmdPODetails.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdPODetails.BackColor = System.Drawing.SystemColors.Control
		Me.cmdPODetails.CausesValidation = True
		Me.cmdPODetails.Enabled = True
		Me.cmdPODetails.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdPODetails.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdPODetails.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdPODetails.TabStop = True
		Me.cmdPODetails.Name = "cmdPODetails"
		Me._txtSpace2_9.AutoSize = False
		Me._txtSpace2_9.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_9.Location = New System.Drawing.Point(160, 176)
		Me._txtSpace2_9.ReadOnly = True
		Me._txtSpace2_9.TabIndex = 76
		Me._txtSpace2_9.TabStop = False
		Me._txtSpace2_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_9.AcceptsReturn = True
		Me._txtSpace2_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_9.CausesValidation = True
		Me._txtSpace2_9.Enabled = True
		Me._txtSpace2_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_9.HideSelection = True
		Me._txtSpace2_9.Maxlength = 0
		Me._txtSpace2_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_9.MultiLine = False
		Me._txtSpace2_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_9.Visible = True
		Me._txtSpace2_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_9.Name = "_txtSpace2_9"
		Me._txtSpace1_9.AutoSize = False
		Me._txtSpace1_9.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_9.Location = New System.Drawing.Point(72, 176)
		Me._txtSpace1_9.ReadOnly = True
		Me._txtSpace1_9.TabIndex = 75
		Me._txtSpace1_9.TabStop = False
		Me._txtSpace1_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_9.AcceptsReturn = True
		Me._txtSpace1_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_9.CausesValidation = True
		Me._txtSpace1_9.Enabled = True
		Me._txtSpace1_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_9.HideSelection = True
		Me._txtSpace1_9.Maxlength = 0
		Me._txtSpace1_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_9.MultiLine = False
		Me._txtSpace1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_9.Visible = True
		Me._txtSpace1_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_9.Name = "_txtSpace1_9"
		Me._txtSpace2_8.AutoSize = False
		Me._txtSpace2_8.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_8.Location = New System.Drawing.Point(160, 160)
		Me._txtSpace2_8.ReadOnly = True
		Me._txtSpace2_8.TabIndex = 74
		Me._txtSpace2_8.TabStop = False
		Me._txtSpace2_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_8.AcceptsReturn = True
		Me._txtSpace2_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_8.CausesValidation = True
		Me._txtSpace2_8.Enabled = True
		Me._txtSpace2_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_8.HideSelection = True
		Me._txtSpace2_8.Maxlength = 0
		Me._txtSpace2_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_8.MultiLine = False
		Me._txtSpace2_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_8.Visible = True
		Me._txtSpace2_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_8.Name = "_txtSpace2_8"
		Me._txtSpace1_8.AutoSize = False
		Me._txtSpace1_8.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_8.Location = New System.Drawing.Point(72, 160)
		Me._txtSpace1_8.ReadOnly = True
		Me._txtSpace1_8.TabIndex = 73
		Me._txtSpace1_8.TabStop = False
		Me._txtSpace1_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_8.AcceptsReturn = True
		Me._txtSpace1_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_8.CausesValidation = True
		Me._txtSpace1_8.Enabled = True
		Me._txtSpace1_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_8.HideSelection = True
		Me._txtSpace1_8.Maxlength = 0
		Me._txtSpace1_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_8.MultiLine = False
		Me._txtSpace1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_8.Visible = True
		Me._txtSpace1_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_8.Name = "_txtSpace1_8"
		Me._txtSpace2_7.AutoSize = False
		Me._txtSpace2_7.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_7.Location = New System.Drawing.Point(160, 144)
		Me._txtSpace2_7.ReadOnly = True
		Me._txtSpace2_7.TabIndex = 72
		Me._txtSpace2_7.TabStop = False
		Me._txtSpace2_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_7.AcceptsReturn = True
		Me._txtSpace2_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_7.CausesValidation = True
		Me._txtSpace2_7.Enabled = True
		Me._txtSpace2_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_7.HideSelection = True
		Me._txtSpace2_7.Maxlength = 0
		Me._txtSpace2_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_7.MultiLine = False
		Me._txtSpace2_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_7.Visible = True
		Me._txtSpace2_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_7.Name = "_txtSpace2_7"
		Me._txtSpace1_7.AutoSize = False
		Me._txtSpace1_7.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_7.Location = New System.Drawing.Point(72, 144)
		Me._txtSpace1_7.ReadOnly = True
		Me._txtSpace1_7.TabIndex = 71
		Me._txtSpace1_7.TabStop = False
		Me._txtSpace1_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_7.AcceptsReturn = True
		Me._txtSpace1_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_7.CausesValidation = True
		Me._txtSpace1_7.Enabled = True
		Me._txtSpace1_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_7.HideSelection = True
		Me._txtSpace1_7.Maxlength = 0
		Me._txtSpace1_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_7.MultiLine = False
		Me._txtSpace1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_7.Visible = True
		Me._txtSpace1_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_7.Name = "_txtSpace1_7"
		Me._txtSpace2_6.AutoSize = False
		Me._txtSpace2_6.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_6.Location = New System.Drawing.Point(160, 128)
		Me._txtSpace2_6.ReadOnly = True
		Me._txtSpace2_6.TabIndex = 70
		Me._txtSpace2_6.TabStop = False
		Me._txtSpace2_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_6.AcceptsReturn = True
		Me._txtSpace2_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_6.CausesValidation = True
		Me._txtSpace2_6.Enabled = True
		Me._txtSpace2_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_6.HideSelection = True
		Me._txtSpace2_6.Maxlength = 0
		Me._txtSpace2_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_6.MultiLine = False
		Me._txtSpace2_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_6.Visible = True
		Me._txtSpace2_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_6.Name = "_txtSpace2_6"
		Me._txtSpace1_6.AutoSize = False
		Me._txtSpace1_6.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_6.Location = New System.Drawing.Point(72, 128)
		Me._txtSpace1_6.ReadOnly = True
		Me._txtSpace1_6.TabIndex = 69
		Me._txtSpace1_6.TabStop = False
		Me._txtSpace1_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_6.AcceptsReturn = True
		Me._txtSpace1_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_6.CausesValidation = True
		Me._txtSpace1_6.Enabled = True
		Me._txtSpace1_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_6.HideSelection = True
		Me._txtSpace1_6.Maxlength = 0
		Me._txtSpace1_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_6.MultiLine = False
		Me._txtSpace1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_6.Visible = True
		Me._txtSpace1_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_6.Name = "_txtSpace1_6"
		Me._txtSpace2_5.AutoSize = False
		Me._txtSpace2_5.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_5.Location = New System.Drawing.Point(160, 112)
		Me._txtSpace2_5.ReadOnly = True
		Me._txtSpace2_5.TabIndex = 68
		Me._txtSpace2_5.TabStop = False
		Me._txtSpace2_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_5.AcceptsReturn = True
		Me._txtSpace2_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_5.CausesValidation = True
		Me._txtSpace2_5.Enabled = True
		Me._txtSpace2_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_5.HideSelection = True
		Me._txtSpace2_5.Maxlength = 0
		Me._txtSpace2_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_5.MultiLine = False
		Me._txtSpace2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_5.Visible = True
		Me._txtSpace2_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_5.Name = "_txtSpace2_5"
		Me._txtSpace1_5.AutoSize = False
		Me._txtSpace1_5.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_5.Location = New System.Drawing.Point(72, 112)
		Me._txtSpace1_5.ReadOnly = True
		Me._txtSpace1_5.TabIndex = 67
		Me._txtSpace1_5.TabStop = False
		Me._txtSpace1_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_5.AcceptsReturn = True
		Me._txtSpace1_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_5.CausesValidation = True
		Me._txtSpace1_5.Enabled = True
		Me._txtSpace1_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_5.HideSelection = True
		Me._txtSpace1_5.Maxlength = 0
		Me._txtSpace1_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_5.MultiLine = False
		Me._txtSpace1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_5.Visible = True
		Me._txtSpace1_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_5.Name = "_txtSpace1_5"
		Me._txtSpace2_4.AutoSize = False
		Me._txtSpace2_4.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_4.Location = New System.Drawing.Point(160, 96)
		Me._txtSpace2_4.ReadOnly = True
		Me._txtSpace2_4.TabIndex = 66
		Me._txtSpace2_4.TabStop = False
		Me._txtSpace2_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_4.AcceptsReturn = True
		Me._txtSpace2_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_4.CausesValidation = True
		Me._txtSpace2_4.Enabled = True
		Me._txtSpace2_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_4.HideSelection = True
		Me._txtSpace2_4.Maxlength = 0
		Me._txtSpace2_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_4.MultiLine = False
		Me._txtSpace2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_4.Visible = True
		Me._txtSpace2_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_4.Name = "_txtSpace2_4"
		Me._txtSpace1_4.AutoSize = False
		Me._txtSpace1_4.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_4.Location = New System.Drawing.Point(72, 96)
		Me._txtSpace1_4.ReadOnly = True
		Me._txtSpace1_4.TabIndex = 65
		Me._txtSpace1_4.TabStop = False
		Me._txtSpace1_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_4.AcceptsReturn = True
		Me._txtSpace1_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_4.CausesValidation = True
		Me._txtSpace1_4.Enabled = True
		Me._txtSpace1_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_4.HideSelection = True
		Me._txtSpace1_4.Maxlength = 0
		Me._txtSpace1_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_4.MultiLine = False
		Me._txtSpace1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_4.Visible = True
		Me._txtSpace1_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_4.Name = "_txtSpace1_4"
		Me._txtSpace2_3.AutoSize = False
		Me._txtSpace2_3.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_3.Location = New System.Drawing.Point(160, 80)
		Me._txtSpace2_3.ReadOnly = True
		Me._txtSpace2_3.TabIndex = 64
		Me._txtSpace2_3.TabStop = False
		Me._txtSpace2_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_3.AcceptsReturn = True
		Me._txtSpace2_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_3.CausesValidation = True
		Me._txtSpace2_3.Enabled = True
		Me._txtSpace2_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_3.HideSelection = True
		Me._txtSpace2_3.Maxlength = 0
		Me._txtSpace2_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_3.MultiLine = False
		Me._txtSpace2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_3.Visible = True
		Me._txtSpace2_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_3.Name = "_txtSpace2_3"
		Me._txtSpace1_3.AutoSize = False
		Me._txtSpace1_3.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_3.Location = New System.Drawing.Point(72, 80)
		Me._txtSpace1_3.ReadOnly = True
		Me._txtSpace1_3.TabIndex = 63
		Me._txtSpace1_3.TabStop = False
		Me._txtSpace1_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_3.AcceptsReturn = True
		Me._txtSpace1_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_3.CausesValidation = True
		Me._txtSpace1_3.Enabled = True
		Me._txtSpace1_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_3.HideSelection = True
		Me._txtSpace1_3.Maxlength = 0
		Me._txtSpace1_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_3.MultiLine = False
		Me._txtSpace1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_3.Visible = True
		Me._txtSpace1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_3.Name = "_txtSpace1_3"
		Me._txtSpace2_2.AutoSize = False
		Me._txtSpace2_2.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_2.Location = New System.Drawing.Point(160, 64)
		Me._txtSpace2_2.ReadOnly = True
		Me._txtSpace2_2.TabIndex = 62
		Me._txtSpace2_2.TabStop = False
		Me._txtSpace2_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_2.AcceptsReturn = True
		Me._txtSpace2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_2.CausesValidation = True
		Me._txtSpace2_2.Enabled = True
		Me._txtSpace2_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_2.HideSelection = True
		Me._txtSpace2_2.Maxlength = 0
		Me._txtSpace2_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_2.MultiLine = False
		Me._txtSpace2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_2.Visible = True
		Me._txtSpace2_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_2.Name = "_txtSpace2_2"
		Me._txtSpace1_2.AutoSize = False
		Me._txtSpace1_2.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_2.Location = New System.Drawing.Point(72, 64)
		Me._txtSpace1_2.ReadOnly = True
		Me._txtSpace1_2.TabIndex = 61
		Me._txtSpace1_2.TabStop = False
		Me._txtSpace1_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_2.AcceptsReturn = True
		Me._txtSpace1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_2.CausesValidation = True
		Me._txtSpace1_2.Enabled = True
		Me._txtSpace1_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_2.HideSelection = True
		Me._txtSpace1_2.Maxlength = 0
		Me._txtSpace1_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_2.MultiLine = False
		Me._txtSpace1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_2.Visible = True
		Me._txtSpace1_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_2.Name = "_txtSpace1_2"
		Me._txtSpace2_1.AutoSize = False
		Me._txtSpace2_1.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_1.Location = New System.Drawing.Point(160, 48)
		Me._txtSpace2_1.ReadOnly = True
		Me._txtSpace2_1.TabIndex = 60
		Me._txtSpace2_1.TabStop = False
		Me._txtSpace2_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_1.AcceptsReturn = True
		Me._txtSpace2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_1.CausesValidation = True
		Me._txtSpace2_1.Enabled = True
		Me._txtSpace2_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_1.HideSelection = True
		Me._txtSpace2_1.Maxlength = 0
		Me._txtSpace2_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_1.MultiLine = False
		Me._txtSpace2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_1.Visible = True
		Me._txtSpace2_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_1.Name = "_txtSpace2_1"
		Me._txtSpace1_1.AutoSize = False
		Me._txtSpace1_1.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_1.Location = New System.Drawing.Point(72, 48)
		Me._txtSpace1_1.ReadOnly = True
		Me._txtSpace1_1.TabIndex = 59
		Me._txtSpace1_1.TabStop = False
		Me._txtSpace1_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_1.AcceptsReturn = True
		Me._txtSpace1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_1.CausesValidation = True
		Me._txtSpace1_1.Enabled = True
		Me._txtSpace1_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_1.HideSelection = True
		Me._txtSpace1_1.Maxlength = 0
		Me._txtSpace1_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_1.MultiLine = False
		Me._txtSpace1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_1.Visible = True
		Me._txtSpace1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_1.Name = "_txtSpace1_1"
		Me._txtSpace2_0.AutoSize = False
		Me._txtSpace2_0.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace2_0.Location = New System.Drawing.Point(160, 32)
		Me._txtSpace2_0.ReadOnly = True
		Me._txtSpace2_0.TabIndex = 58
		Me._txtSpace2_0.TabStop = False
		Me._txtSpace2_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace2_0.AcceptsReturn = True
		Me._txtSpace2_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace2_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace2_0.CausesValidation = True
		Me._txtSpace2_0.Enabled = True
		Me._txtSpace2_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace2_0.HideSelection = True
		Me._txtSpace2_0.Maxlength = 0
		Me._txtSpace2_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace2_0.MultiLine = False
		Me._txtSpace2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace2_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace2_0.Visible = True
		Me._txtSpace2_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace2_0.Name = "_txtSpace2_0"
		Me._txtSpace1_0.AutoSize = False
		Me._txtSpace1_0.Size = New System.Drawing.Size(25, 19)
		Me._txtSpace1_0.Location = New System.Drawing.Point(72, 32)
		Me._txtSpace1_0.ReadOnly = True
		Me._txtSpace1_0.TabIndex = 57
		Me._txtSpace1_0.TabStop = False
		Me._txtSpace1_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtSpace1_0.AcceptsReturn = True
		Me._txtSpace1_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtSpace1_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtSpace1_0.CausesValidation = True
		Me._txtSpace1_0.Enabled = True
		Me._txtSpace1_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtSpace1_0.HideSelection = True
		Me._txtSpace1_0.Maxlength = 0
		Me._txtSpace1_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtSpace1_0.MultiLine = False
		Me._txtSpace1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtSpace1_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtSpace1_0.Visible = True
		Me._txtSpace1_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtSpace1_0.Name = "_txtSpace1_0"
		Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdExit.Text = "Exit"
		Me.cmdExit.Size = New System.Drawing.Size(105, 49)
		Me.cmdExit.Location = New System.Drawing.Point(496, 240)
		Me.cmdExit.TabIndex = 56
		Me.cmdExit.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
		Me.cmdExit.CausesValidation = True
		Me.cmdExit.Enabled = True
		Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdExit.TabStop = True
		Me.cmdExit.Name = "cmdExit"
		Me.vscPOScroll.Size = New System.Drawing.Size(17, 161)
		Me.vscPOScroll.LargeChange = 10
		Me.vscPOScroll.Location = New System.Drawing.Point(584, 32)
		Me.vscPOScroll.TabIndex = 50
		Me.vscPOScroll.CausesValidation = True
		Me.vscPOScroll.Enabled = True
		Me.vscPOScroll.Maximum = 32776
		Me.vscPOScroll.Minimum = 0
		Me.vscPOScroll.Cursor = System.Windows.Forms.Cursors.Default
		Me.vscPOScroll.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.vscPOScroll.SmallChange = 1
		Me.vscPOScroll.TabStop = True
		Me.vscPOScroll.Value = 0
		Me.vscPOScroll.Visible = True
		Me.vscPOScroll.Name = "vscPOScroll"
		Me._txtPOAmount_9.AutoSize = False
		Me._txtPOAmount_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_9.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_9.Location = New System.Drawing.Point(480, 176)
		Me._txtPOAmount_9.ReadOnly = True
		Me._txtPOAmount_9.TabIndex = 49
		Me._txtPOAmount_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_9.AcceptsReturn = True
		Me._txtPOAmount_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_9.CausesValidation = True
		Me._txtPOAmount_9.Enabled = True
		Me._txtPOAmount_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_9.HideSelection = True
		Me._txtPOAmount_9.Maxlength = 0
		Me._txtPOAmount_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_9.MultiLine = False
		Me._txtPOAmount_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_9.TabStop = True
		Me._txtPOAmount_9.Visible = True
		Me._txtPOAmount_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_9.Name = "_txtPOAmount_9"
		Me._txtPODeliveryDate_9.AutoSize = False
		Me._txtPODeliveryDate_9.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_9.Location = New System.Drawing.Point(408, 176)
		Me._txtPODeliveryDate_9.ReadOnly = True
		Me._txtPODeliveryDate_9.TabIndex = 48
		Me._txtPODeliveryDate_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_9.AcceptsReturn = True
		Me._txtPODeliveryDate_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_9.CausesValidation = True
		Me._txtPODeliveryDate_9.Enabled = True
		Me._txtPODeliveryDate_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_9.HideSelection = True
		Me._txtPODeliveryDate_9.Maxlength = 0
		Me._txtPODeliveryDate_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_9.MultiLine = False
		Me._txtPODeliveryDate_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_9.TabStop = True
		Me._txtPODeliveryDate_9.Visible = True
		Me._txtPODeliveryDate_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_9.Name = "_txtPODeliveryDate_9"
		Me._txtPOVendor_9.AutoSize = False
		Me._txtPOVendor_9.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_9.Location = New System.Drawing.Point(184, 176)
		Me._txtPOVendor_9.ReadOnly = True
		Me._txtPOVendor_9.TabIndex = 47
		Me._txtPOVendor_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_9.AcceptsReturn = True
		Me._txtPOVendor_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_9.CausesValidation = True
		Me._txtPOVendor_9.Enabled = True
		Me._txtPOVendor_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_9.HideSelection = True
		Me._txtPOVendor_9.Maxlength = 0
		Me._txtPOVendor_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_9.MultiLine = False
		Me._txtPOVendor_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_9.TabStop = True
		Me._txtPOVendor_9.Visible = True
		Me._txtPOVendor_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_9.Name = "_txtPOVendor_9"
		Me._txtPODate_9.AutoSize = False
		Me._txtPODate_9.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_9.Location = New System.Drawing.Point(96, 176)
		Me._txtPODate_9.ReadOnly = True
		Me._txtPODate_9.TabIndex = 46
		Me._txtPODate_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_9.AcceptsReturn = True
		Me._txtPODate_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_9.CausesValidation = True
		Me._txtPODate_9.Enabled = True
		Me._txtPODate_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_9.HideSelection = True
		Me._txtPODate_9.Maxlength = 0
		Me._txtPODate_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_9.MultiLine = False
		Me._txtPODate_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_9.TabStop = True
		Me._txtPODate_9.Visible = True
		Me._txtPODate_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_9.Name = "_txtPODate_9"
		Me._txtPONumber_9.AutoSize = False
		Me._txtPONumber_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_9.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_9.Location = New System.Drawing.Point(16, 176)
		Me._txtPONumber_9.ReadOnly = True
		Me._txtPONumber_9.TabIndex = 45
		Me._txtPONumber_9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_9.AcceptsReturn = True
		Me._txtPONumber_9.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_9.CausesValidation = True
		Me._txtPONumber_9.Enabled = True
		Me._txtPONumber_9.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_9.HideSelection = True
		Me._txtPONumber_9.Maxlength = 0
		Me._txtPONumber_9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_9.MultiLine = False
		Me._txtPONumber_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_9.TabStop = True
		Me._txtPONumber_9.Visible = True
		Me._txtPONumber_9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_9.Name = "_txtPONumber_9"
		Me._txtPOAmount_8.AutoSize = False
		Me._txtPOAmount_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_8.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_8.Location = New System.Drawing.Point(480, 160)
		Me._txtPOAmount_8.ReadOnly = True
		Me._txtPOAmount_8.TabIndex = 44
		Me._txtPOAmount_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_8.AcceptsReturn = True
		Me._txtPOAmount_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_8.CausesValidation = True
		Me._txtPOAmount_8.Enabled = True
		Me._txtPOAmount_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_8.HideSelection = True
		Me._txtPOAmount_8.Maxlength = 0
		Me._txtPOAmount_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_8.MultiLine = False
		Me._txtPOAmount_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_8.TabStop = True
		Me._txtPOAmount_8.Visible = True
		Me._txtPOAmount_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_8.Name = "_txtPOAmount_8"
		Me._txtPODeliveryDate_8.AutoSize = False
		Me._txtPODeliveryDate_8.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_8.Location = New System.Drawing.Point(408, 160)
		Me._txtPODeliveryDate_8.ReadOnly = True
		Me._txtPODeliveryDate_8.TabIndex = 43
		Me._txtPODeliveryDate_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_8.AcceptsReturn = True
		Me._txtPODeliveryDate_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_8.CausesValidation = True
		Me._txtPODeliveryDate_8.Enabled = True
		Me._txtPODeliveryDate_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_8.HideSelection = True
		Me._txtPODeliveryDate_8.Maxlength = 0
		Me._txtPODeliveryDate_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_8.MultiLine = False
		Me._txtPODeliveryDate_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_8.TabStop = True
		Me._txtPODeliveryDate_8.Visible = True
		Me._txtPODeliveryDate_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_8.Name = "_txtPODeliveryDate_8"
		Me._txtPOVendor_8.AutoSize = False
		Me._txtPOVendor_8.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_8.Location = New System.Drawing.Point(184, 160)
		Me._txtPOVendor_8.ReadOnly = True
		Me._txtPOVendor_8.TabIndex = 42
		Me._txtPOVendor_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_8.AcceptsReturn = True
		Me._txtPOVendor_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_8.CausesValidation = True
		Me._txtPOVendor_8.Enabled = True
		Me._txtPOVendor_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_8.HideSelection = True
		Me._txtPOVendor_8.Maxlength = 0
		Me._txtPOVendor_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_8.MultiLine = False
		Me._txtPOVendor_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_8.TabStop = True
		Me._txtPOVendor_8.Visible = True
		Me._txtPOVendor_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_8.Name = "_txtPOVendor_8"
		Me._txtPODate_8.AutoSize = False
		Me._txtPODate_8.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_8.Location = New System.Drawing.Point(96, 160)
		Me._txtPODate_8.ReadOnly = True
		Me._txtPODate_8.TabIndex = 41
		Me._txtPODate_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_8.AcceptsReturn = True
		Me._txtPODate_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_8.CausesValidation = True
		Me._txtPODate_8.Enabled = True
		Me._txtPODate_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_8.HideSelection = True
		Me._txtPODate_8.Maxlength = 0
		Me._txtPODate_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_8.MultiLine = False
		Me._txtPODate_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_8.TabStop = True
		Me._txtPODate_8.Visible = True
		Me._txtPODate_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_8.Name = "_txtPODate_8"
		Me._txtPONumber_8.AutoSize = False
		Me._txtPONumber_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_8.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_8.Location = New System.Drawing.Point(16, 160)
		Me._txtPONumber_8.ReadOnly = True
		Me._txtPONumber_8.TabIndex = 40
		Me._txtPONumber_8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_8.AcceptsReturn = True
		Me._txtPONumber_8.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_8.CausesValidation = True
		Me._txtPONumber_8.Enabled = True
		Me._txtPONumber_8.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_8.HideSelection = True
		Me._txtPONumber_8.Maxlength = 0
		Me._txtPONumber_8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_8.MultiLine = False
		Me._txtPONumber_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_8.TabStop = True
		Me._txtPONumber_8.Visible = True
		Me._txtPONumber_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_8.Name = "_txtPONumber_8"
		Me._txtPOAmount_7.AutoSize = False
		Me._txtPOAmount_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_7.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_7.Location = New System.Drawing.Point(480, 144)
		Me._txtPOAmount_7.ReadOnly = True
		Me._txtPOAmount_7.TabIndex = 39
		Me._txtPOAmount_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_7.AcceptsReturn = True
		Me._txtPOAmount_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_7.CausesValidation = True
		Me._txtPOAmount_7.Enabled = True
		Me._txtPOAmount_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_7.HideSelection = True
		Me._txtPOAmount_7.Maxlength = 0
		Me._txtPOAmount_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_7.MultiLine = False
		Me._txtPOAmount_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_7.TabStop = True
		Me._txtPOAmount_7.Visible = True
		Me._txtPOAmount_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_7.Name = "_txtPOAmount_7"
		Me._txtPODeliveryDate_7.AutoSize = False
		Me._txtPODeliveryDate_7.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_7.Location = New System.Drawing.Point(408, 144)
		Me._txtPODeliveryDate_7.ReadOnly = True
		Me._txtPODeliveryDate_7.TabIndex = 38
		Me._txtPODeliveryDate_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_7.AcceptsReturn = True
		Me._txtPODeliveryDate_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_7.CausesValidation = True
		Me._txtPODeliveryDate_7.Enabled = True
		Me._txtPODeliveryDate_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_7.HideSelection = True
		Me._txtPODeliveryDate_7.Maxlength = 0
		Me._txtPODeliveryDate_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_7.MultiLine = False
		Me._txtPODeliveryDate_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_7.TabStop = True
		Me._txtPODeliveryDate_7.Visible = True
		Me._txtPODeliveryDate_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_7.Name = "_txtPODeliveryDate_7"
		Me._txtPOVendor_7.AutoSize = False
		Me._txtPOVendor_7.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_7.Location = New System.Drawing.Point(184, 144)
		Me._txtPOVendor_7.ReadOnly = True
		Me._txtPOVendor_7.TabIndex = 37
		Me._txtPOVendor_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_7.AcceptsReturn = True
		Me._txtPOVendor_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_7.CausesValidation = True
		Me._txtPOVendor_7.Enabled = True
		Me._txtPOVendor_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_7.HideSelection = True
		Me._txtPOVendor_7.Maxlength = 0
		Me._txtPOVendor_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_7.MultiLine = False
		Me._txtPOVendor_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_7.TabStop = True
		Me._txtPOVendor_7.Visible = True
		Me._txtPOVendor_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_7.Name = "_txtPOVendor_7"
		Me._txtPODate_7.AutoSize = False
		Me._txtPODate_7.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_7.Location = New System.Drawing.Point(96, 144)
		Me._txtPODate_7.ReadOnly = True
		Me._txtPODate_7.TabIndex = 36
		Me._txtPODate_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_7.AcceptsReturn = True
		Me._txtPODate_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_7.CausesValidation = True
		Me._txtPODate_7.Enabled = True
		Me._txtPODate_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_7.HideSelection = True
		Me._txtPODate_7.Maxlength = 0
		Me._txtPODate_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_7.MultiLine = False
		Me._txtPODate_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_7.TabStop = True
		Me._txtPODate_7.Visible = True
		Me._txtPODate_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_7.Name = "_txtPODate_7"
		Me._txtPONumber_7.AutoSize = False
		Me._txtPONumber_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_7.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_7.Location = New System.Drawing.Point(16, 144)
		Me._txtPONumber_7.ReadOnly = True
		Me._txtPONumber_7.TabIndex = 35
		Me._txtPONumber_7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_7.AcceptsReturn = True
		Me._txtPONumber_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_7.CausesValidation = True
		Me._txtPONumber_7.Enabled = True
		Me._txtPONumber_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_7.HideSelection = True
		Me._txtPONumber_7.Maxlength = 0
		Me._txtPONumber_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_7.MultiLine = False
		Me._txtPONumber_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_7.TabStop = True
		Me._txtPONumber_7.Visible = True
		Me._txtPONumber_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_7.Name = "_txtPONumber_7"
		Me._txtPOAmount_6.AutoSize = False
		Me._txtPOAmount_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_6.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_6.Location = New System.Drawing.Point(480, 128)
		Me._txtPOAmount_6.ReadOnly = True
		Me._txtPOAmount_6.TabIndex = 34
		Me._txtPOAmount_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_6.AcceptsReturn = True
		Me._txtPOAmount_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_6.CausesValidation = True
		Me._txtPOAmount_6.Enabled = True
		Me._txtPOAmount_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_6.HideSelection = True
		Me._txtPOAmount_6.Maxlength = 0
		Me._txtPOAmount_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_6.MultiLine = False
		Me._txtPOAmount_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_6.TabStop = True
		Me._txtPOAmount_6.Visible = True
		Me._txtPOAmount_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_6.Name = "_txtPOAmount_6"
		Me._txtPODeliveryDate_6.AutoSize = False
		Me._txtPODeliveryDate_6.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_6.Location = New System.Drawing.Point(408, 128)
		Me._txtPODeliveryDate_6.ReadOnly = True
		Me._txtPODeliveryDate_6.TabIndex = 33
		Me._txtPODeliveryDate_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_6.AcceptsReturn = True
		Me._txtPODeliveryDate_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_6.CausesValidation = True
		Me._txtPODeliveryDate_6.Enabled = True
		Me._txtPODeliveryDate_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_6.HideSelection = True
		Me._txtPODeliveryDate_6.Maxlength = 0
		Me._txtPODeliveryDate_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_6.MultiLine = False
		Me._txtPODeliveryDate_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_6.TabStop = True
		Me._txtPODeliveryDate_6.Visible = True
		Me._txtPODeliveryDate_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_6.Name = "_txtPODeliveryDate_6"
		Me._txtPOVendor_6.AutoSize = False
		Me._txtPOVendor_6.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_6.Location = New System.Drawing.Point(184, 128)
		Me._txtPOVendor_6.ReadOnly = True
		Me._txtPOVendor_6.TabIndex = 32
		Me._txtPOVendor_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_6.AcceptsReturn = True
		Me._txtPOVendor_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_6.CausesValidation = True
		Me._txtPOVendor_6.Enabled = True
		Me._txtPOVendor_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_6.HideSelection = True
		Me._txtPOVendor_6.Maxlength = 0
		Me._txtPOVendor_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_6.MultiLine = False
		Me._txtPOVendor_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_6.TabStop = True
		Me._txtPOVendor_6.Visible = True
		Me._txtPOVendor_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_6.Name = "_txtPOVendor_6"
		Me._txtPODate_6.AutoSize = False
		Me._txtPODate_6.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_6.Location = New System.Drawing.Point(96, 128)
		Me._txtPODate_6.ReadOnly = True
		Me._txtPODate_6.TabIndex = 31
		Me._txtPODate_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_6.AcceptsReturn = True
		Me._txtPODate_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_6.CausesValidation = True
		Me._txtPODate_6.Enabled = True
		Me._txtPODate_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_6.HideSelection = True
		Me._txtPODate_6.Maxlength = 0
		Me._txtPODate_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_6.MultiLine = False
		Me._txtPODate_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_6.TabStop = True
		Me._txtPODate_6.Visible = True
		Me._txtPODate_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_6.Name = "_txtPODate_6"
		Me._txtPONumber_6.AutoSize = False
		Me._txtPONumber_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_6.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_6.Location = New System.Drawing.Point(16, 128)
		Me._txtPONumber_6.ReadOnly = True
		Me._txtPONumber_6.TabIndex = 30
		Me._txtPONumber_6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_6.AcceptsReturn = True
		Me._txtPONumber_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_6.CausesValidation = True
		Me._txtPONumber_6.Enabled = True
		Me._txtPONumber_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_6.HideSelection = True
		Me._txtPONumber_6.Maxlength = 0
		Me._txtPONumber_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_6.MultiLine = False
		Me._txtPONumber_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_6.TabStop = True
		Me._txtPONumber_6.Visible = True
		Me._txtPONumber_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_6.Name = "_txtPONumber_6"
		Me._txtPOAmount_5.AutoSize = False
		Me._txtPOAmount_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_5.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_5.Location = New System.Drawing.Point(480, 112)
		Me._txtPOAmount_5.ReadOnly = True
		Me._txtPOAmount_5.TabIndex = 29
		Me._txtPOAmount_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_5.AcceptsReturn = True
		Me._txtPOAmount_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_5.CausesValidation = True
		Me._txtPOAmount_5.Enabled = True
		Me._txtPOAmount_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_5.HideSelection = True
		Me._txtPOAmount_5.Maxlength = 0
		Me._txtPOAmount_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_5.MultiLine = False
		Me._txtPOAmount_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_5.TabStop = True
		Me._txtPOAmount_5.Visible = True
		Me._txtPOAmount_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_5.Name = "_txtPOAmount_5"
		Me._txtPODeliveryDate_5.AutoSize = False
		Me._txtPODeliveryDate_5.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_5.Location = New System.Drawing.Point(408, 112)
		Me._txtPODeliveryDate_5.ReadOnly = True
		Me._txtPODeliveryDate_5.TabIndex = 28
		Me._txtPODeliveryDate_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_5.AcceptsReturn = True
		Me._txtPODeliveryDate_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_5.CausesValidation = True
		Me._txtPODeliveryDate_5.Enabled = True
		Me._txtPODeliveryDate_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_5.HideSelection = True
		Me._txtPODeliveryDate_5.Maxlength = 0
		Me._txtPODeliveryDate_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_5.MultiLine = False
		Me._txtPODeliveryDate_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_5.TabStop = True
		Me._txtPODeliveryDate_5.Visible = True
		Me._txtPODeliveryDate_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_5.Name = "_txtPODeliveryDate_5"
		Me._txtPOVendor_5.AutoSize = False
		Me._txtPOVendor_5.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_5.Location = New System.Drawing.Point(184, 112)
		Me._txtPOVendor_5.ReadOnly = True
		Me._txtPOVendor_5.TabIndex = 27
		Me._txtPOVendor_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_5.AcceptsReturn = True
		Me._txtPOVendor_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_5.CausesValidation = True
		Me._txtPOVendor_5.Enabled = True
		Me._txtPOVendor_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_5.HideSelection = True
		Me._txtPOVendor_5.Maxlength = 0
		Me._txtPOVendor_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_5.MultiLine = False
		Me._txtPOVendor_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_5.TabStop = True
		Me._txtPOVendor_5.Visible = True
		Me._txtPOVendor_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_5.Name = "_txtPOVendor_5"
		Me._txtPODate_5.AutoSize = False
		Me._txtPODate_5.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_5.Location = New System.Drawing.Point(96, 112)
		Me._txtPODate_5.ReadOnly = True
		Me._txtPODate_5.TabIndex = 26
		Me._txtPODate_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_5.AcceptsReturn = True
		Me._txtPODate_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_5.CausesValidation = True
		Me._txtPODate_5.Enabled = True
		Me._txtPODate_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_5.HideSelection = True
		Me._txtPODate_5.Maxlength = 0
		Me._txtPODate_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_5.MultiLine = False
		Me._txtPODate_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_5.TabStop = True
		Me._txtPODate_5.Visible = True
		Me._txtPODate_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_5.Name = "_txtPODate_5"
		Me._txtPONumber_5.AutoSize = False
		Me._txtPONumber_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_5.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_5.Location = New System.Drawing.Point(16, 112)
		Me._txtPONumber_5.ReadOnly = True
		Me._txtPONumber_5.TabIndex = 25
		Me._txtPONumber_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_5.AcceptsReturn = True
		Me._txtPONumber_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_5.CausesValidation = True
		Me._txtPONumber_5.Enabled = True
		Me._txtPONumber_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_5.HideSelection = True
		Me._txtPONumber_5.Maxlength = 0
		Me._txtPONumber_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_5.MultiLine = False
		Me._txtPONumber_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_5.TabStop = True
		Me._txtPONumber_5.Visible = True
		Me._txtPONumber_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_5.Name = "_txtPONumber_5"
		Me._txtPOAmount_4.AutoSize = False
		Me._txtPOAmount_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_4.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_4.Location = New System.Drawing.Point(480, 96)
		Me._txtPOAmount_4.ReadOnly = True
		Me._txtPOAmount_4.TabIndex = 24
		Me._txtPOAmount_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_4.AcceptsReturn = True
		Me._txtPOAmount_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_4.CausesValidation = True
		Me._txtPOAmount_4.Enabled = True
		Me._txtPOAmount_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_4.HideSelection = True
		Me._txtPOAmount_4.Maxlength = 0
		Me._txtPOAmount_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_4.MultiLine = False
		Me._txtPOAmount_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_4.TabStop = True
		Me._txtPOAmount_4.Visible = True
		Me._txtPOAmount_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_4.Name = "_txtPOAmount_4"
		Me._txtPODeliveryDate_4.AutoSize = False
		Me._txtPODeliveryDate_4.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_4.Location = New System.Drawing.Point(408, 96)
		Me._txtPODeliveryDate_4.ReadOnly = True
		Me._txtPODeliveryDate_4.TabIndex = 23
		Me._txtPODeliveryDate_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_4.AcceptsReturn = True
		Me._txtPODeliveryDate_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_4.CausesValidation = True
		Me._txtPODeliveryDate_4.Enabled = True
		Me._txtPODeliveryDate_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_4.HideSelection = True
		Me._txtPODeliveryDate_4.Maxlength = 0
		Me._txtPODeliveryDate_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_4.MultiLine = False
		Me._txtPODeliveryDate_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_4.TabStop = True
		Me._txtPODeliveryDate_4.Visible = True
		Me._txtPODeliveryDate_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_4.Name = "_txtPODeliveryDate_4"
		Me._txtPOVendor_4.AutoSize = False
		Me._txtPOVendor_4.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_4.Location = New System.Drawing.Point(184, 96)
		Me._txtPOVendor_4.ReadOnly = True
		Me._txtPOVendor_4.TabIndex = 22
		Me._txtPOVendor_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_4.AcceptsReturn = True
		Me._txtPOVendor_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_4.CausesValidation = True
		Me._txtPOVendor_4.Enabled = True
		Me._txtPOVendor_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_4.HideSelection = True
		Me._txtPOVendor_4.Maxlength = 0
		Me._txtPOVendor_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_4.MultiLine = False
		Me._txtPOVendor_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_4.TabStop = True
		Me._txtPOVendor_4.Visible = True
		Me._txtPOVendor_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_4.Name = "_txtPOVendor_4"
		Me._txtPODate_4.AutoSize = False
		Me._txtPODate_4.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_4.Location = New System.Drawing.Point(96, 96)
		Me._txtPODate_4.ReadOnly = True
		Me._txtPODate_4.TabIndex = 21
		Me._txtPODate_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_4.AcceptsReturn = True
		Me._txtPODate_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_4.CausesValidation = True
		Me._txtPODate_4.Enabled = True
		Me._txtPODate_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_4.HideSelection = True
		Me._txtPODate_4.Maxlength = 0
		Me._txtPODate_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_4.MultiLine = False
		Me._txtPODate_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_4.TabStop = True
		Me._txtPODate_4.Visible = True
		Me._txtPODate_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_4.Name = "_txtPODate_4"
		Me._txtPONumber_4.AutoSize = False
		Me._txtPONumber_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_4.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_4.Location = New System.Drawing.Point(16, 96)
		Me._txtPONumber_4.ReadOnly = True
		Me._txtPONumber_4.TabIndex = 20
		Me._txtPONumber_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_4.AcceptsReturn = True
		Me._txtPONumber_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_4.CausesValidation = True
		Me._txtPONumber_4.Enabled = True
		Me._txtPONumber_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_4.HideSelection = True
		Me._txtPONumber_4.Maxlength = 0
		Me._txtPONumber_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_4.MultiLine = False
		Me._txtPONumber_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_4.TabStop = True
		Me._txtPONumber_4.Visible = True
		Me._txtPONumber_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_4.Name = "_txtPONumber_4"
		Me._txtPOAmount_3.AutoSize = False
		Me._txtPOAmount_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_3.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_3.Location = New System.Drawing.Point(480, 80)
		Me._txtPOAmount_3.ReadOnly = True
		Me._txtPOAmount_3.TabIndex = 19
		Me._txtPOAmount_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_3.AcceptsReturn = True
		Me._txtPOAmount_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_3.CausesValidation = True
		Me._txtPOAmount_3.Enabled = True
		Me._txtPOAmount_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_3.HideSelection = True
		Me._txtPOAmount_3.Maxlength = 0
		Me._txtPOAmount_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_3.MultiLine = False
		Me._txtPOAmount_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_3.TabStop = True
		Me._txtPOAmount_3.Visible = True
		Me._txtPOAmount_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_3.Name = "_txtPOAmount_3"
		Me._txtPODeliveryDate_3.AutoSize = False
		Me._txtPODeliveryDate_3.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_3.Location = New System.Drawing.Point(408, 80)
		Me._txtPODeliveryDate_3.ReadOnly = True
		Me._txtPODeliveryDate_3.TabIndex = 18
		Me._txtPODeliveryDate_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_3.AcceptsReturn = True
		Me._txtPODeliveryDate_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_3.CausesValidation = True
		Me._txtPODeliveryDate_3.Enabled = True
		Me._txtPODeliveryDate_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_3.HideSelection = True
		Me._txtPODeliveryDate_3.Maxlength = 0
		Me._txtPODeliveryDate_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_3.MultiLine = False
		Me._txtPODeliveryDate_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_3.TabStop = True
		Me._txtPODeliveryDate_3.Visible = True
		Me._txtPODeliveryDate_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_3.Name = "_txtPODeliveryDate_3"
		Me._txtPOVendor_3.AutoSize = False
		Me._txtPOVendor_3.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_3.Location = New System.Drawing.Point(184, 80)
		Me._txtPOVendor_3.ReadOnly = True
		Me._txtPOVendor_3.TabIndex = 17
		Me._txtPOVendor_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_3.AcceptsReturn = True
		Me._txtPOVendor_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_3.CausesValidation = True
		Me._txtPOVendor_3.Enabled = True
		Me._txtPOVendor_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_3.HideSelection = True
		Me._txtPOVendor_3.Maxlength = 0
		Me._txtPOVendor_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_3.MultiLine = False
		Me._txtPOVendor_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_3.TabStop = True
		Me._txtPOVendor_3.Visible = True
		Me._txtPOVendor_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_3.Name = "_txtPOVendor_3"
		Me._txtPODate_3.AutoSize = False
		Me._txtPODate_3.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_3.Location = New System.Drawing.Point(96, 80)
		Me._txtPODate_3.ReadOnly = True
		Me._txtPODate_3.TabIndex = 16
		Me._txtPODate_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_3.AcceptsReturn = True
		Me._txtPODate_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_3.CausesValidation = True
		Me._txtPODate_3.Enabled = True
		Me._txtPODate_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_3.HideSelection = True
		Me._txtPODate_3.Maxlength = 0
		Me._txtPODate_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_3.MultiLine = False
		Me._txtPODate_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_3.TabStop = True
		Me._txtPODate_3.Visible = True
		Me._txtPODate_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_3.Name = "_txtPODate_3"
		Me._txtPONumber_3.AutoSize = False
		Me._txtPONumber_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_3.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_3.Location = New System.Drawing.Point(16, 80)
		Me._txtPONumber_3.ReadOnly = True
		Me._txtPONumber_3.TabIndex = 15
		Me._txtPONumber_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_3.AcceptsReturn = True
		Me._txtPONumber_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_3.CausesValidation = True
		Me._txtPONumber_3.Enabled = True
		Me._txtPONumber_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_3.HideSelection = True
		Me._txtPONumber_3.Maxlength = 0
		Me._txtPONumber_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_3.MultiLine = False
		Me._txtPONumber_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_3.TabStop = True
		Me._txtPONumber_3.Visible = True
		Me._txtPONumber_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_3.Name = "_txtPONumber_3"
		Me._txtPOAmount_2.AutoSize = False
		Me._txtPOAmount_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_2.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_2.Location = New System.Drawing.Point(480, 64)
		Me._txtPOAmount_2.ReadOnly = True
		Me._txtPOAmount_2.TabIndex = 14
		Me._txtPOAmount_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_2.AcceptsReturn = True
		Me._txtPOAmount_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_2.CausesValidation = True
		Me._txtPOAmount_2.Enabled = True
		Me._txtPOAmount_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_2.HideSelection = True
		Me._txtPOAmount_2.Maxlength = 0
		Me._txtPOAmount_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_2.MultiLine = False
		Me._txtPOAmount_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_2.TabStop = True
		Me._txtPOAmount_2.Visible = True
		Me._txtPOAmount_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_2.Name = "_txtPOAmount_2"
		Me._txtPODeliveryDate_2.AutoSize = False
		Me._txtPODeliveryDate_2.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_2.Location = New System.Drawing.Point(408, 64)
		Me._txtPODeliveryDate_2.ReadOnly = True
		Me._txtPODeliveryDate_2.TabIndex = 13
		Me._txtPODeliveryDate_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_2.AcceptsReturn = True
		Me._txtPODeliveryDate_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_2.CausesValidation = True
		Me._txtPODeliveryDate_2.Enabled = True
		Me._txtPODeliveryDate_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_2.HideSelection = True
		Me._txtPODeliveryDate_2.Maxlength = 0
		Me._txtPODeliveryDate_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_2.MultiLine = False
		Me._txtPODeliveryDate_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_2.TabStop = True
		Me._txtPODeliveryDate_2.Visible = True
		Me._txtPODeliveryDate_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_2.Name = "_txtPODeliveryDate_2"
		Me._txtPOVendor_2.AutoSize = False
		Me._txtPOVendor_2.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_2.Location = New System.Drawing.Point(184, 64)
		Me._txtPOVendor_2.ReadOnly = True
		Me._txtPOVendor_2.TabIndex = 12
		Me._txtPOVendor_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_2.AcceptsReturn = True
		Me._txtPOVendor_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_2.CausesValidation = True
		Me._txtPOVendor_2.Enabled = True
		Me._txtPOVendor_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_2.HideSelection = True
		Me._txtPOVendor_2.Maxlength = 0
		Me._txtPOVendor_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_2.MultiLine = False
		Me._txtPOVendor_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_2.TabStop = True
		Me._txtPOVendor_2.Visible = True
		Me._txtPOVendor_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_2.Name = "_txtPOVendor_2"
		Me._txtPODate_2.AutoSize = False
		Me._txtPODate_2.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_2.Location = New System.Drawing.Point(96, 64)
		Me._txtPODate_2.ReadOnly = True
		Me._txtPODate_2.TabIndex = 11
		Me._txtPODate_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_2.AcceptsReturn = True
		Me._txtPODate_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_2.CausesValidation = True
		Me._txtPODate_2.Enabled = True
		Me._txtPODate_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_2.HideSelection = True
		Me._txtPODate_2.Maxlength = 0
		Me._txtPODate_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_2.MultiLine = False
		Me._txtPODate_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_2.TabStop = True
		Me._txtPODate_2.Visible = True
		Me._txtPODate_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_2.Name = "_txtPODate_2"
		Me._txtPONumber_2.AutoSize = False
		Me._txtPONumber_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_2.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_2.Location = New System.Drawing.Point(16, 64)
		Me._txtPONumber_2.ReadOnly = True
		Me._txtPONumber_2.TabIndex = 10
		Me._txtPONumber_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_2.AcceptsReturn = True
		Me._txtPONumber_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_2.CausesValidation = True
		Me._txtPONumber_2.Enabled = True
		Me._txtPONumber_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_2.HideSelection = True
		Me._txtPONumber_2.Maxlength = 0
		Me._txtPONumber_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_2.MultiLine = False
		Me._txtPONumber_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_2.TabStop = True
		Me._txtPONumber_2.Visible = True
		Me._txtPONumber_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_2.Name = "_txtPONumber_2"
		Me._txtPOAmount_1.AutoSize = False
		Me._txtPOAmount_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_1.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_1.Location = New System.Drawing.Point(480, 48)
		Me._txtPOAmount_1.ReadOnly = True
		Me._txtPOAmount_1.TabIndex = 9
		Me._txtPOAmount_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_1.AcceptsReturn = True
		Me._txtPOAmount_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_1.CausesValidation = True
		Me._txtPOAmount_1.Enabled = True
		Me._txtPOAmount_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_1.HideSelection = True
		Me._txtPOAmount_1.Maxlength = 0
		Me._txtPOAmount_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_1.MultiLine = False
		Me._txtPOAmount_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_1.TabStop = True
		Me._txtPOAmount_1.Visible = True
		Me._txtPOAmount_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_1.Name = "_txtPOAmount_1"
		Me._txtPODeliveryDate_1.AutoSize = False
		Me._txtPODeliveryDate_1.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_1.Location = New System.Drawing.Point(408, 48)
		Me._txtPODeliveryDate_1.ReadOnly = True
		Me._txtPODeliveryDate_1.TabIndex = 8
		Me._txtPODeliveryDate_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_1.AcceptsReturn = True
		Me._txtPODeliveryDate_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_1.CausesValidation = True
		Me._txtPODeliveryDate_1.Enabled = True
		Me._txtPODeliveryDate_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_1.HideSelection = True
		Me._txtPODeliveryDate_1.Maxlength = 0
		Me._txtPODeliveryDate_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_1.MultiLine = False
		Me._txtPODeliveryDate_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_1.TabStop = True
		Me._txtPODeliveryDate_1.Visible = True
		Me._txtPODeliveryDate_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_1.Name = "_txtPODeliveryDate_1"
		Me._txtPOVendor_1.AutoSize = False
		Me._txtPOVendor_1.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_1.Location = New System.Drawing.Point(184, 48)
		Me._txtPOVendor_1.ReadOnly = True
		Me._txtPOVendor_1.TabIndex = 7
		Me._txtPOVendor_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_1.AcceptsReturn = True
		Me._txtPOVendor_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_1.CausesValidation = True
		Me._txtPOVendor_1.Enabled = True
		Me._txtPOVendor_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_1.HideSelection = True
		Me._txtPOVendor_1.Maxlength = 0
		Me._txtPOVendor_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_1.MultiLine = False
		Me._txtPOVendor_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_1.TabStop = True
		Me._txtPOVendor_1.Visible = True
		Me._txtPOVendor_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_1.Name = "_txtPOVendor_1"
		Me._txtPODate_1.AutoSize = False
		Me._txtPODate_1.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_1.Location = New System.Drawing.Point(96, 48)
		Me._txtPODate_1.ReadOnly = True
		Me._txtPODate_1.TabIndex = 6
		Me._txtPODate_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_1.AcceptsReturn = True
		Me._txtPODate_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_1.CausesValidation = True
		Me._txtPODate_1.Enabled = True
		Me._txtPODate_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_1.HideSelection = True
		Me._txtPODate_1.Maxlength = 0
		Me._txtPODate_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_1.MultiLine = False
		Me._txtPODate_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_1.TabStop = True
		Me._txtPODate_1.Visible = True
		Me._txtPODate_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_1.Name = "_txtPODate_1"
		Me._txtPONumber_1.AutoSize = False
		Me._txtPONumber_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_1.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_1.Location = New System.Drawing.Point(16, 48)
		Me._txtPONumber_1.ReadOnly = True
		Me._txtPONumber_1.TabIndex = 5
		Me._txtPONumber_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_1.AcceptsReturn = True
		Me._txtPONumber_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_1.CausesValidation = True
		Me._txtPONumber_1.Enabled = True
		Me._txtPONumber_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_1.HideSelection = True
		Me._txtPONumber_1.Maxlength = 0
		Me._txtPONumber_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_1.MultiLine = False
		Me._txtPONumber_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_1.TabStop = True
		Me._txtPONumber_1.Visible = True
		Me._txtPONumber_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_1.Name = "_txtPONumber_1"
		Me._txtPOAmount_0.AutoSize = False
		Me._txtPOAmount_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPOAmount_0.Size = New System.Drawing.Size(97, 19)
		Me._txtPOAmount_0.Location = New System.Drawing.Point(480, 32)
		Me._txtPOAmount_0.ReadOnly = True
		Me._txtPOAmount_0.TabIndex = 4
		Me._txtPOAmount_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOAmount_0.AcceptsReturn = True
		Me._txtPOAmount_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOAmount_0.CausesValidation = True
		Me._txtPOAmount_0.Enabled = True
		Me._txtPOAmount_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOAmount_0.HideSelection = True
		Me._txtPOAmount_0.Maxlength = 0
		Me._txtPOAmount_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOAmount_0.MultiLine = False
		Me._txtPOAmount_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOAmount_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOAmount_0.TabStop = True
		Me._txtPOAmount_0.Visible = True
		Me._txtPOAmount_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOAmount_0.Name = "_txtPOAmount_0"
		Me._txtPODeliveryDate_0.AutoSize = False
		Me._txtPODeliveryDate_0.Size = New System.Drawing.Size(73, 19)
		Me._txtPODeliveryDate_0.Location = New System.Drawing.Point(408, 32)
		Me._txtPODeliveryDate_0.ReadOnly = True
		Me._txtPODeliveryDate_0.TabIndex = 3
		Me._txtPODeliveryDate_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODeliveryDate_0.AcceptsReturn = True
		Me._txtPODeliveryDate_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODeliveryDate_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODeliveryDate_0.CausesValidation = True
		Me._txtPODeliveryDate_0.Enabled = True
		Me._txtPODeliveryDate_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODeliveryDate_0.HideSelection = True
		Me._txtPODeliveryDate_0.Maxlength = 0
		Me._txtPODeliveryDate_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODeliveryDate_0.MultiLine = False
		Me._txtPODeliveryDate_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODeliveryDate_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODeliveryDate_0.TabStop = True
		Me._txtPODeliveryDate_0.Visible = True
		Me._txtPODeliveryDate_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODeliveryDate_0.Name = "_txtPODeliveryDate_0"
		Me._txtPOVendor_0.AutoSize = False
		Me._txtPOVendor_0.Size = New System.Drawing.Size(225, 19)
		Me._txtPOVendor_0.Location = New System.Drawing.Point(184, 32)
		Me._txtPOVendor_0.ReadOnly = True
		Me._txtPOVendor_0.TabIndex = 2
		Me._txtPOVendor_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPOVendor_0.AcceptsReturn = True
		Me._txtPOVendor_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPOVendor_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtPOVendor_0.CausesValidation = True
		Me._txtPOVendor_0.Enabled = True
		Me._txtPOVendor_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPOVendor_0.HideSelection = True
		Me._txtPOVendor_0.Maxlength = 0
		Me._txtPOVendor_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPOVendor_0.MultiLine = False
		Me._txtPOVendor_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPOVendor_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPOVendor_0.TabStop = True
		Me._txtPOVendor_0.Visible = True
		Me._txtPOVendor_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPOVendor_0.Name = "_txtPOVendor_0"
		Me._txtPODate_0.AutoSize = False
		Me._txtPODate_0.Size = New System.Drawing.Size(65, 19)
		Me._txtPODate_0.Location = New System.Drawing.Point(96, 32)
		Me._txtPODate_0.ReadOnly = True
		Me._txtPODate_0.TabIndex = 1
		Me._txtPODate_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPODate_0.AcceptsReturn = True
		Me._txtPODate_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtPODate_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtPODate_0.CausesValidation = True
		Me._txtPODate_0.Enabled = True
		Me._txtPODate_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPODate_0.HideSelection = True
		Me._txtPODate_0.Maxlength = 0
		Me._txtPODate_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPODate_0.MultiLine = False
		Me._txtPODate_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPODate_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPODate_0.TabStop = True
		Me._txtPODate_0.Visible = True
		Me._txtPODate_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPODate_0.Name = "_txtPODate_0"
		Me._txtPONumber_0.AutoSize = False
		Me._txtPONumber_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me._txtPONumber_0.Size = New System.Drawing.Size(57, 19)
		Me._txtPONumber_0.Location = New System.Drawing.Point(16, 32)
		Me._txtPONumber_0.ReadOnly = True
		Me._txtPONumber_0.TabIndex = 0
		Me._txtPONumber_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._txtPONumber_0.AcceptsReturn = True
		Me._txtPONumber_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtPONumber_0.CausesValidation = True
		Me._txtPONumber_0.Enabled = True
		Me._txtPONumber_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtPONumber_0.HideSelection = True
		Me._txtPONumber_0.Maxlength = 0
		Me._txtPONumber_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtPONumber_0.MultiLine = False
		Me._txtPONumber_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtPONumber_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtPONumber_0.TabStop = True
		Me._txtPONumber_0.Visible = True
		Me._txtPONumber_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._txtPONumber_0.Name = "_txtPONumber_0"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label5.Text = "Amount"
		Me.Label5.Size = New System.Drawing.Size(49, 17)
		Me.Label5.Location = New System.Drawing.Point(528, 16)
		Me.Label5.TabIndex = 55
		Me.Label5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label4.Text = "Delivery Date"
		Me.Label4.Size = New System.Drawing.Size(65, 17)
		Me.Label4.Location = New System.Drawing.Point(408, 16)
		Me.Label4.TabIndex = 54
		Me.Label4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label3.Text = "Vendor"
		Me.Label3.Size = New System.Drawing.Size(41, 17)
		Me.Label3.Location = New System.Drawing.Point(184, 16)
		Me.Label3.TabIndex = 53
		Me.Label3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label2.Text = "Date"
		Me.Label2.Size = New System.Drawing.Size(33, 17)
		Me.Label2.Location = New System.Drawing.Point(96, 16)
		Me.Label2.TabIndex = 52
		Me.Label2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label1.Text = "PO Number"
		Me.Label1.Size = New System.Drawing.Size(57, 17)
		Me.Label1.Location = New System.Drawing.Point(16, 16)
		Me.Label1.TabIndex = 51
		Me.Label1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Controls.Add(cmdPODetails)
		Me.Controls.Add(_txtSpace2_9)
		Me.Controls.Add(_txtSpace1_9)
		Me.Controls.Add(_txtSpace2_8)
		Me.Controls.Add(_txtSpace1_8)
		Me.Controls.Add(_txtSpace2_7)
		Me.Controls.Add(_txtSpace1_7)
		Me.Controls.Add(_txtSpace2_6)
		Me.Controls.Add(_txtSpace1_6)
		Me.Controls.Add(_txtSpace2_5)
		Me.Controls.Add(_txtSpace1_5)
		Me.Controls.Add(_txtSpace2_4)
		Me.Controls.Add(_txtSpace1_4)
		Me.Controls.Add(_txtSpace2_3)
		Me.Controls.Add(_txtSpace1_3)
		Me.Controls.Add(_txtSpace2_2)
		Me.Controls.Add(_txtSpace1_2)
		Me.Controls.Add(_txtSpace2_1)
		Me.Controls.Add(_txtSpace1_1)
		Me.Controls.Add(_txtSpace2_0)
		Me.Controls.Add(_txtSpace1_0)
		Me.Controls.Add(cmdExit)
		Me.Controls.Add(vscPOScroll)
		Me.Controls.Add(_txtPOAmount_9)
		Me.Controls.Add(_txtPODeliveryDate_9)
		Me.Controls.Add(_txtPOVendor_9)
		Me.Controls.Add(_txtPODate_9)
		Me.Controls.Add(_txtPONumber_9)
		Me.Controls.Add(_txtPOAmount_8)
		Me.Controls.Add(_txtPODeliveryDate_8)
		Me.Controls.Add(_txtPOVendor_8)
		Me.Controls.Add(_txtPODate_8)
		Me.Controls.Add(_txtPONumber_8)
		Me.Controls.Add(_txtPOAmount_7)
		Me.Controls.Add(_txtPODeliveryDate_7)
		Me.Controls.Add(_txtPOVendor_7)
		Me.Controls.Add(_txtPODate_7)
		Me.Controls.Add(_txtPONumber_7)
		Me.Controls.Add(_txtPOAmount_6)
		Me.Controls.Add(_txtPODeliveryDate_6)
		Me.Controls.Add(_txtPOVendor_6)
		Me.Controls.Add(_txtPODate_6)
		Me.Controls.Add(_txtPONumber_6)
		Me.Controls.Add(_txtPOAmount_5)
		Me.Controls.Add(_txtPODeliveryDate_5)
		Me.Controls.Add(_txtPOVendor_5)
		Me.Controls.Add(_txtPODate_5)
		Me.Controls.Add(_txtPONumber_5)
		Me.Controls.Add(_txtPOAmount_4)
		Me.Controls.Add(_txtPODeliveryDate_4)
		Me.Controls.Add(_txtPOVendor_4)
		Me.Controls.Add(_txtPODate_4)
		Me.Controls.Add(_txtPONumber_4)
		Me.Controls.Add(_txtPOAmount_3)
		Me.Controls.Add(_txtPODeliveryDate_3)
		Me.Controls.Add(_txtPOVendor_3)
		Me.Controls.Add(_txtPODate_3)
		Me.Controls.Add(_txtPONumber_3)
		Me.Controls.Add(_txtPOAmount_2)
		Me.Controls.Add(_txtPODeliveryDate_2)
		Me.Controls.Add(_txtPOVendor_2)
		Me.Controls.Add(_txtPODate_2)
		Me.Controls.Add(_txtPONumber_2)
		Me.Controls.Add(_txtPOAmount_1)
		Me.Controls.Add(_txtPODeliveryDate_1)
		Me.Controls.Add(_txtPOVendor_1)
		Me.Controls.Add(_txtPODate_1)
		Me.Controls.Add(_txtPONumber_1)
		Me.Controls.Add(_txtPOAmount_0)
		Me.Controls.Add(_txtPODeliveryDate_0)
		Me.Controls.Add(_txtPOVendor_0)
		Me.Controls.Add(_txtPODate_0)
		Me.Controls.Add(_txtPONumber_0)
		Me.Controls.Add(Label5)
		Me.Controls.Add(Label4)
		Me.Controls.Add(Label3)
		Me.Controls.Add(Label2)
		Me.Controls.Add(Label1)
		Me.txtPOAmount.SetIndex(_txtPOAmount_9, CType(9, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_8, CType(8, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_7, CType(7, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_6, CType(6, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_5, CType(5, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_4, CType(4, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_3, CType(3, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_2, CType(2, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_1, CType(1, Short))
		Me.txtPOAmount.SetIndex(_txtPOAmount_0, CType(0, Short))
		Me.txtPODate.SetIndex(_txtPODate_9, CType(9, Short))
		Me.txtPODate.SetIndex(_txtPODate_8, CType(8, Short))
		Me.txtPODate.SetIndex(_txtPODate_7, CType(7, Short))
		Me.txtPODate.SetIndex(_txtPODate_6, CType(6, Short))
		Me.txtPODate.SetIndex(_txtPODate_5, CType(5, Short))
		Me.txtPODate.SetIndex(_txtPODate_4, CType(4, Short))
		Me.txtPODate.SetIndex(_txtPODate_3, CType(3, Short))
		Me.txtPODate.SetIndex(_txtPODate_2, CType(2, Short))
		Me.txtPODate.SetIndex(_txtPODate_1, CType(1, Short))
		Me.txtPODate.SetIndex(_txtPODate_0, CType(0, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_9, CType(9, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_8, CType(8, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_7, CType(7, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_6, CType(6, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_5, CType(5, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_4, CType(4, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_3, CType(3, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_2, CType(2, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_1, CType(1, Short))
		Me.txtPODeliveryDate.SetIndex(_txtPODeliveryDate_0, CType(0, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_9, CType(9, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_8, CType(8, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_7, CType(7, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_6, CType(6, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_5, CType(5, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_4, CType(4, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_3, CType(3, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_2, CType(2, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_1, CType(1, Short))
		Me.txtPONumber.SetIndex(_txtPONumber_0, CType(0, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_9, CType(9, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_8, CType(8, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_7, CType(7, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_6, CType(6, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_5, CType(5, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_4, CType(4, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_3, CType(3, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_2, CType(2, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_1, CType(1, Short))
		Me.txtPOVendor.SetIndex(_txtPOVendor_0, CType(0, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_9, CType(9, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_8, CType(8, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_7, CType(7, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_6, CType(6, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_5, CType(5, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_4, CType(4, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_3, CType(3, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_2, CType(2, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_1, CType(1, Short))
		Me.txtSpace1.SetIndex(_txtSpace1_0, CType(0, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_9, CType(9, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_8, CType(8, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_7, CType(7, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_6, CType(6, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_5, CType(5, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_4, CType(4, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_3, CType(3, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_2, CType(2, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_1, CType(1, Short))
		Me.txtSpace2.SetIndex(_txtSpace2_0, CType(0, Short))
		CType(Me.txtSpace2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtSpace1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtPOVendor, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtPONumber, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtPODeliveryDate, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtPODate, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.txtPOAmount, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class