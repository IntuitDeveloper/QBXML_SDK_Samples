This sample is a simple VB.NET desktop application that is used for Data extensions by using QBFC2 COM dll. 

Running the sample
------------------

Before running DataExtSample.exe, make sure that .NET runtime is installed on the machine, 
and QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open DataExtSample.sln in Microsoft Visual Studio .NET and build the solution.
QBFC2Assembly.dll was generated with 'tlbimp' .NET Type Library to Assembly Convertor.

