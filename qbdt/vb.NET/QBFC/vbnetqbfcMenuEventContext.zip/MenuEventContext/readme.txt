This sample is a simple VB.NET desktop application that is used for adding or removing Menu items by using QBFC2 COM dll. 

Running the sample
------------------

Before running MenuEventContext.exe, make sure that .NET runtime is installed on the machine, 
and QuickBooks is running with a company opened. 
Register the exe with regasm.exe
e.g. C:\Windows\Microsoft.NET\Framework64\v4.0.30319>RegAsm.exe "C:\Program Files\Intuit\IDN\QBSDK15.0\samples\qbdt\vb.NET\QBFC\MenuEventContext\MenuEventContext.exe"

Building the sample
------------------
Please install latest QBSDK.
Open MenuEventContext.sln in Microsoft Visual Studio .NET and build the solution.
QBFC2Assembly.dll was generated with 'tlbimp' .NET Type Library to Assembly Convertor.
