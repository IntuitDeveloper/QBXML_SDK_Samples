AddInvoice is VB.Net sample code which shows how the same invoice can be added using qbXML
built with the MSXML6 DOM parser and QBFC.  It is intended to be used with the sample product
based company file and expects that QuickBooks 2003 Pro or above is running with that company
file open.  The sample isn't very interesting in its functionality, the sample was created so that
developers could look at the code and compare the two methods of adding an invoice.