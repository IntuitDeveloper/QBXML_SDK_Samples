
This sample is a simple VB.NET desktop application that adds deposits into QuickBooks using qbXML 
built with the MSXML6 DOM parser and QBFC.
Running the sample
------------------
Before running DepositAdd.exe, make sure that .NET runtime is installed on the machine,
and QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open DepositAdd.sln in Microsoft Visual Studio .NET and build the solution.
