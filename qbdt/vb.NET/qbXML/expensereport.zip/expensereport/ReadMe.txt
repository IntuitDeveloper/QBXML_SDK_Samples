
This sample is a simple VB.NET desktop application that displays expense report using qbXML 
built with the MSXML6 DOM parser and QBFC.
Running the sample
------------------
Before running ExpenseReport.exe, make sure that .NET runtime is installed on the machine,
and QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open ExpenseReport.sln in Microsoft Visual Studio .NET and build the solution.
