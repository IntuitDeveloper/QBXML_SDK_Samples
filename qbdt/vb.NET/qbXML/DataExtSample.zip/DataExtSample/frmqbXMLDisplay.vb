Option Strict Off
Option Explicit On
Friend Class frmqbXMLDisplay
	Inherits System.Windows.Forms.Form
	Private Sub cmdCloseWindow_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCloseWindow.Click
		Me.Close()
	End Sub
End Class