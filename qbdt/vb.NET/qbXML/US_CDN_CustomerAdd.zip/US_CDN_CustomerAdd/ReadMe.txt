
This sample is a simple VB.NET desktop application that adds new Quickbook's customer using qbXML 
built with the MSXML6 DOM parser and QBFC.
This sample adds new US and Canadian customers.
Running the sample
------------------
Before running US_CDN_CustomerAdd.exe, make sure that .NET runtime is installed on the machine,
and QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open US_CDN_CustomerAdd.sln in Microsoft Visual Studio .NET and build the solution.
