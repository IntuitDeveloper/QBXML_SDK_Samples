/**
 * QBWebConnectorSvc.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package com.intuit.developer;

public interface QBWebConnectorSvc extends javax.xml.rpc.Service {
    public java.lang.String getQBWebConnectorSvcSoapAddress();

    public com.intuit.developer.QBWebConnectorSvcSoap getQBWebConnectorSvcSoap() throws javax.xml.rpc.ServiceException;

    public com.intuit.developer.QBWebConnectorSvcSoap getQBWebConnectorSvcSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
