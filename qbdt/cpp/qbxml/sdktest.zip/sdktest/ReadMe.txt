
This sample is a simple C++ desktop application that process the xml request and displays the response using qbXMLRP2 
built with the MSXML6 DOM parser.
Running the sample
------------------
Before running SDKTest.exe, make sure that .NET runtime is installed on the machine,
and QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open SDKTest.sln in Microsoft Visual Studio and build the solution.
