//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AddCustomerJob.rc
//
#define IDS_PROJNAME                    100
#define IDR_AddCustomerJob              100
#define IDD_QBCOMPANYFILEDLG            102
#define IDD_QBADDCUSTOMERJOBDLG         103
#define IDC_CompanyFile                 204
#define IDB_BITMAP_QBBANNER             204
#define IDC_Next                        205
#define IDB_BITMAP_CUSTOMER             205
#define IDC_Exit                        206
#define IDC_AddNewCustomer              207
#define IDC_COMBO_CustList              210
#define IDC_COMBO_TypeList              212
#define IDC_EDIT_NewType                213
#define IDC_EDIT_Name                   214
#define IDC_EDIT_Phone                  215
#define IDC_EDIT_CompanyName            216
#define IDC_EDIT_Email                  217
#define IDC_Browse                      220

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         221
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
