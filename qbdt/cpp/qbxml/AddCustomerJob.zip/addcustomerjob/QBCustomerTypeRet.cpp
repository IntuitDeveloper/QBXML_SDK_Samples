/*---------------------------------------------------------------------------
 * FILE: QBCustomerTypeRet.cpp
 *
 * Description:
 * ctor and dtor only
 *
 * Created On: 11/11/2001
 * Updated to SDK 2.0: 08/08/2002
 *
 * Copyright � 2002-2013 Intuit Inc. All rights reserved.
 * Use is subject to the terms specified at:
 *     http://developer.intuit.com/legal/devsite_tos.html
 *
 */
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "QBCustomerTypeRet.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QBCustomerTypeRet::QBCustomerTypeRet()
{

}

QBCustomerTypeRet::~QBCustomerTypeRet()
{

}
