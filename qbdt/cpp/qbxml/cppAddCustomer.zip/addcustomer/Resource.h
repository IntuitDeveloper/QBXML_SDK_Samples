//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AddCustomer.rc
//
#define IDS_PROJNAME                    100
#define IDR_AddCustomer                 100
#define IDD_ADDCUSTDLG                  101
#define IDS_XMLVALIDATOR_DESC           102
#define IDR_XMLValidator                103
#define IDD_VALIDATORDLG                104
#define IDD_DISPLAYDLG                  105
#define IDC_COM_FILE                    201
#define IDC_CUST_NAME                   202
#define IDC_PHONE                       203
#define IDC_Submit                      204
#define IDC_View_Req                    205
#define IDC_View_Res                    206
#define IDC_Exit                        207
#define IDC_FIRSTNAME                   208
#define IDB_QBBANNER                    208
#define IDC_LASTNAME                    209
#define IDB_CUSTOMERS                   209
#define IDC_ValidateReq                 211
#define IDC_EDIT1                       213
#define IDC_RequestXML                  213
#define IDC_XML                         213
#define IDC_Browse                      214
#define IDC_VALIDATE                    215
#define IDC_Schema                      217
#define IDC_QBBANNER                    219
#define IDC_SCHEMALABEL                 220
#define IDC_DONE                        221

// Next default values for new objects

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         222
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
