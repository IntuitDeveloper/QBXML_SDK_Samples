This sample is a simple C++ desktop application that adds the customer using qbXMLRP2
built with the MSXML6 DOM parser.
Running the sample
------------------
Before running AddNewCustomer.exe, make sure that .NET runtime is installed on the machine,
and QuickBooks is running with a company opened.

Building the sample
------------------
Please install latest QBSDK.
Open AddCustomer.sln in Microsoft Visual Studio and build the solution.