
This sample is a simple C++ desktop application that Implements callback handler for QuickBooks events. This is required for the MenuSubscribe application. 
MenuSubscribe registers its menu extensions using this EventHandler.
built with the MSXML6 DOM parser.
Running the sample
------------------
Before running EventHandler.exe, make sure that QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open EventHandler.sln in Microsoft Visual Studio and build the solution.
