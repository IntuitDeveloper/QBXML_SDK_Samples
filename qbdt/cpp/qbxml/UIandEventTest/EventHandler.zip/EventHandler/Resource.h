//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EventHandler.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_EVENTHANDLER                102
#define IDS_QBSDKCALLBACK_DESC          103
#define IDR_QBSDKCallback               104
#define IDR_MAINFRAME                   128
#define IDR_EVENTHTYPE                  129
#define IDD_MAIN_FORM                   130
#define IDD_SETTINGS                    131
#define IDC_EVENT_XML                   1000
#define IDC_HEADER                      1001
#define IDC_OUTPUT_PATH                 1002
#define IDC_LAUNCH_NO                   1004
#define IDC_LAUNCH_YES                  1005
#define IDC_BROWSE                      1006
#define IDC_RECOVERY_ALERT              1007
#define ID_FILE_REGISTER                32771
#define ID_FILE_UNREGISTER              32772
#define IDC_EDIT_SETTINGS               32773
#define ID_EDIT_SETTINGS                32774
#define IDS_NO_XML                      61204

#define WM_RECOVERY_ALERT               WM_APP+1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
