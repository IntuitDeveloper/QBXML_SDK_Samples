
This sample is a simple C++ desktop application that Opens form windows in QuickBooks for new and existing transactions and list items.
built with the MSXML6 DOM parser.
Running the sample
------------------
Before running InvokeUI.exe, make sure that QuickBooks is running with a company opened.
Building the sample
------------------
Please install latest QBSDK.
Open InvokeUI.sln in Microsoft Visual Studio and build the solution.
