//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuSubscribe.rc
//
#define IDR_MANIFEST                    1
#define IDD_MENUSUBSCRIBE_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_STATUS                      1000
#define IDC_ADD_SUBSCRIPTION            1000
#define IDC_REQUEST                     1001
#define IDC_CHECK1                      1001
#define IDC_RESPONSE                    1002
#define IDC_ADD_TO                      1003
#define IDC_SHOW_XML                    1004
#define IDC_RICHEDIT21                  1009
#define IDC_MENU_BASE                   2000
#define IDC_MENU1_TEXT                  2000
#define IDC_MENU1_VISIBLE_IF            2001
#define IDC_MENU1_VISIBLE               2002
#define IDC_MENU1_ENABLED_IF            2003
#define IDC_MENU1_ENABLED               2004
#define IDC_MENU2_TEXT                  2010
#define IDC_MENU2_VISIBLE_IF            2011
#define IDC_MENU2_VISIBLE               2012
#define IDC_MENU2_ENABLED_IF            2013
#define IDC_MENU2_ENABLED               2014
#define IDC_MENU3_TEXT                  2020
#define IDC_MENU3_VISIBLE_IF            2021
#define IDC_MENU3_VISIBLE               2022
#define IDC_MENU3_ENABLED_IF            2023
#define IDC_MENU3_ENABLED               2024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
