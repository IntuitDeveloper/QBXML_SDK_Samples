This sample is a simple C++ desktop application that add the customer by using QBFC2 COM dll. 

Running the sample
------------------

Before running CustomerAdd.exe, make sure that QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open CustomerAdd.sln in Microsoft Visual Studio and build the solution.
