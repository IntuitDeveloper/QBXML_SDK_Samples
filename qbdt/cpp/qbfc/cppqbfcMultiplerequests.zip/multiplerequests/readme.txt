This sample is a simple C++ desktop application that requests the items by using QBFC2 COM dll. 

Running the sample
------------------

Before running MultipleRequests.exe, make sure that QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open MultipleRequests.sln in Microsoft Visual Studio and build the solution.
