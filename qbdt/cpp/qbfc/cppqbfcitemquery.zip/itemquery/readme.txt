This sample is a simple C++ desktop application that queries the items by using QBFC2 COM dll. 

Running the sample
------------------

Before running ItemQuery.exe, make sure that QuickBooks is running with a company opened. 

Building the sample
------------------
Please install latest QBSDK.
Open ItemQuery.sln in Microsoft Visual Studio and build the solution.
